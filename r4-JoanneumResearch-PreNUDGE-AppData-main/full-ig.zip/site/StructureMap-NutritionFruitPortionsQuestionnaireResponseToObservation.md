# HL7.AT.FHIR.PRENUDGE.APPDATA.R4\Nutrition Fruit Portions Q to O - FHIR® v4.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Nutrition Fruit Portions Q to O**

## StructureMap: Nutrition Fruit Portions Q to O 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.hl7.at/prenudge/appdata/r4/StructureMap/NutritionFruitPortionsQuestionnaireResponseToObservation | *Version*:0.1.0 | |
| Active as of 2026-10-21 | *Responsible:*[The PreNUDGE Consortium](https://prenudge.at) | *Computable Name*:NutritionFruitPortionsQuestionnaireResponseToObservation |

 
Nutrition Fruit Portions Q to O 

IG © 2026+
[The PreNUDGE Consortium](https://prenudge.at). Package hl7.at.fhir.prenudge.appdata.r4#0.1.0 based on
[FHIR® 4.0.1](http://hl7.org/fhir/R4/). Generated
2026-10-21

Links:
[Table of Contents](toc.md)|
[QA Report](qa.md)

## Resource Content

```json
{
  "resourceType" : "StructureMap",
  "id" : "NutritionFruitPortionsQuestionnaireResponseToObservation",
  "url" : "https://fhir.hl7.at/prenudge/appdata/r4/StructureMap/NutritionFruitPortionsQuestionnaireResponseToObservation",
  "version" : "0.1.0",
  "name" : "NutritionFruitPortionsQuestionnaireResponseToObservation",
  "title" : "Nutrition Fruit Portions Q to O",
  "status" : "active",
  "date" : "2026-10-21T09:39:19+00:00",
  "publisher" : "The PreNUDGE Consortium",
  "contact" : [{
    "name" : "The PreNUDGE Consortium",
    "telecom" : [{
      "system" : "url",
      "value" : "https://prenudge.at"
    }]
  },
  {
    "name" : "The PreNUDGE Consortium",
    "telecom" : [{
      "system" : "url",
      "value" : "https://prenudge.at",
      "use" : "work"
    }]
  }],
  "description" : "Nutrition Fruit Portions Q to O",
  "structure" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/QuestionnaireResponse",
    "mode" : "source",
    "alias" : "QR"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/Observation",
    "mode" : "target",
    "alias" : "Obs"
  }],
  "import" : ["http://hl7.org/fhir/StructureMap/*",
  "https://fhir.hl7.at/prenudge/appdata/r4/StructureMap/QuestionnaireResponseToObservationBase"],
  "group" : [{
    "name" : "NutritionFruitPortionsQuestionnaireResponseToObservation",
    "typeMode" : "none",
    "input" : [{
      "name" : "src",
      "type" : "QR",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "type" : "Obs",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "Base",
      "source" : [{
        "context" : "src"
      }],
      "dependent" : [{
        "name" : "SetObservationBase",
        "variable" : ["src", "tgt"]
      }]
    },
    {
      "name" : "SetProfile",
      "source" : [{
        "context" : "src"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "meta",
        "variable" : "meta",
        "transform" : "create",
        "parameter" : [{
          "valueString" : "Meta"
        }]
      },
      {
        "context" : "meta",
        "contextType" : "variable",
        "element" : "profile",
        "transform" : "copy",
        "parameter" : [{
          "valueString" : "https://fhir.hl7.at/prenudge/appdata/r4/StructureDefinition/at-prenudge-nutrition-fruitportions-observation"
        }]
      }]
    },
    {
      "name" : "SetCode",
      "source" : [{
        "context" : "src"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "code",
        "transform" : "cc",
        "parameter" : [{
          "valueString" : "http://loinc.org"
        },
        {
          "valueString" : "80457-5"
        },
        {
          "valueString" : "Fruit servings 24 hour Estimated"
        }]
      }]
    },
    {
      "name" : "ProcessDH1Absence",
      "source" : [{
        "context" : "src",
        "element" : "item",
        "variable" : "item",
        "condition" : "linkId = 'DH1'"
      }],
      "dependent" : [{
        "name" : "MapFruitFrequencyAbsence",
        "variable" : ["item", "tgt"]
      }]
    },
    {
      "name" : "ProcessDH2",
      "source" : [{
        "context" : "src",
        "element" : "item",
        "variable" : "item",
        "condition" : "linkId = 'DH2'"
      }],
      "dependent" : [{
        "name" : "MapFruitPortions",
        "variable" : ["item", "tgt"]
      }]
    }]
  },
  {
    "name" : "MapFruitFrequencyAbsence",
    "typeMode" : "none",
    "input" : [{
      "name" : "src",
      "type" : "QR",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "type" : "Obs",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "ProcessAbsenceAnswer",
      "source" : [{
        "context" : "src",
        "element" : "answer",
        "variable" : "answer"
      }],
      "rule" : [{
        "name" : "MapUnknown",
        "source" : [{
          "context" : "answer",
          "element" : "valueCoding",
          "variable" : "coding",
          "condition" : "coding.code = 'meta-unknown'"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "dataAbsentReason",
          "transform" : "cc",
          "parameter" : [{
            "valueString" : "http://terminology.hl7.org/CodeSystem/data-absent-reason"
          },
          {
            "valueString" : "asked-unknown"
          },
          {
            "valueString" : "Asked But Unknown"
          }]
        }]
      },
      {
        "name" : "MapNotStated",
        "source" : [{
          "context" : "answer",
          "element" : "valueCoding",
          "variable" : "coding",
          "condition" : "coding.code = 'meta-not-stated'"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "dataAbsentReason",
          "transform" : "cc",
          "parameter" : [{
            "valueString" : "http://terminology.hl7.org/CodeSystem/data-absent-reason"
          },
          {
            "valueString" : "asked-declined"
          },
          {
            "valueString" : "Asked But Declined"
          }]
        }]
      }]
    }]
  },
  {
    "name" : "MapFruitPortions",
    "typeMode" : "none",
    "input" : [{
      "name" : "src",
      "type" : "QR",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "type" : "Obs",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "ProcessAnswer",
      "source" : [{
        "context" : "src",
        "element" : "answer",
        "variable" : "answer"
      }],
      "rule" : [{
        "name" : "ExtractValue",
        "source" : [{
          "context" : "answer",
          "element" : "valueInteger",
          "variable" : "intObj"
        }],
        "rule" : [{
          "name" : "SetQuantity",
          "source" : [{
            "context" : "intObj",
            "element" : "value",
            "variable" : "numVal"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "value",
            "variable" : "qty",
            "transform" : "create",
            "parameter" : [{
              "valueString" : "Quantity"
            }]
          },
          {
            "context" : "qty",
            "contextType" : "variable",
            "element" : "value",
            "transform" : "copy",
            "parameter" : [{
              "valueId" : "numVal"
            }]
          },
          {
            "context" : "qty",
            "contextType" : "variable",
            "element" : "unit",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "Portionen"
            }]
          },
          {
            "context" : "qty",
            "contextType" : "variable",
            "element" : "system",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "http://unitsofmeasure.org"
            }]
          },
          {
            "context" : "qty",
            "contextType" : "variable",
            "element" : "code",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "{serving}"
            }]
          }]
        }]
      }]
    }]
  }]
}

```
