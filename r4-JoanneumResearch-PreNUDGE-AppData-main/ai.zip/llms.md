# hl7.at.fhir.prenudge.appdata.r4#0.1.0: PreNUDGE FHIR® IG for Data Provider / Data from Apps (R4)

## Pages

* [HL7.AT.FHIR.PRENUDGE.APPDATA.R4\Home - FHIR® v4.0.1](index.md)
* [HL7.AT.FHIR.PRENUDGE.APPDATA.R4\Artifacts Summary - FHIR® v4.0.1](artifacts.md)
* [HL7.AT.FHIR.PRENUDGE.APPDATA.R4\Workflow - FHIR® v4.0.1](workflow.md)
* [HL7.AT.FHIR.PRENUDGE.APPDATA.R4\Downloads - FHIR® v4.0.1](downloads.md)
* [HL7.AT.FHIR.PRENUDGE.APPDATA.R4\Background - FHIR® v4.0.1](background.md)
* [HL7.AT.FHIR.PRENUDGE.APPDATA.R4\About - FHIR® v4.0.1](about.md)

## Resources

### CodeSystems

* [RAND SF-36 answer options in german](CodeSystem-rand-sf36-answers.md)

### ValueSets

* [SNOMED CT AlcoholUse-Frequency](ValueSet-at-prenudge-alcoholuse-valueset-frequency.md)
* [AtPrenudgeValueSetMethodManualAutomated](ValueSet-at-prenudge-observation-valueset-method-manual-automated.md)

### Resource Profiles

* [AT PreNUDGE Observation Alcohol Use](StructureDefinition-at-prenudge-alcoholuse-observation.md)
* [AT PreNUDGE Observation Blood Glucose (only in mg/dL)](StructureDefinition-at-prenudge-bloodglucose-observation.md)
* [AT PreNUDGE Observation](StructureDefinition-at-prenudge-observation.md)
* [AT PreNUDGE Questionnaire](StructureDefinition-at-prenudge-questionnaire.md)
* [AT PreNUDGE Questionnaire Response](StructureDefinition-at-prenudge-questionnaireresponse.md)
* [AT PreNUDGE Observation Step Count](StructureDefinition-at-prenudge-stepcount-observation.md)

### ImplementationGuides

* [PreNUDGE FHIR® IG for Data Provider / Data from Apps (R4)](index.md)

### Questionnaires

* [Alkoholkonsum-Frequenz (letztes Jahr)](Questionnaire-AtPrenudgeQuestionnaireAlcoholUse.md)
* [Blutzucker](Questionnaire-BloodGlucoseQuestionnaire.md)
* [Quality of life by RAND 36-Item Health Survey 1.0 (SF-36)](Questionnaire-QolQuestionnaire.md)
* [Schrittanzahl (täglich)](Questionnaire-StepCountQuestionnaire.md)

### Examples

* [example (Patient)](Patient-example.md)
* [AlcoholResponseDaily (QuestionnaireResponse)](QuestionnaireResponse-AlcoholResponseDaily.md)
* [AlcoholResponseNever (QuestionnaireResponse)](QuestionnaireResponse-AlcoholResponseNever.md)
* [BloodGlucoseQuestionnaireResponse1 (QuestionnaireResponse)](QuestionnaireResponse-BloodGlucoseQuestionnaireResponse1.md)
* [BloodGlucoseQuestionnaireResponse2 (QuestionnaireResponse)](QuestionnaireResponse-BloodGlucoseQuestionnaireResponse2.md)
* [StepCountResponseActive (QuestionnaireResponse)](QuestionnaireResponse-StepCountResponseActive.md)
* [StepCountResponseExtreme (QuestionnaireResponse)](QuestionnaireResponse-StepCountResponseExtreme.md)
