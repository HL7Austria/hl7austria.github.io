# hl7.at.fhir.prenudge.appdata.r4#0.1.0: PreNUDGE FHIR® IG for Data Provider / Data from Apps (R4)

## Pages

* [HL7.AT.FHIR.PRENUDGE.APPDATA.R4\Home - FHIR® v4.0.1](index.md)
* [HL7.AT.FHIR.PRENUDGE.APPDATA.R4\Background - FHIR® v4.0.1](background.md)
* [HL7.AT.FHIR.PRENUDGE.APPDATA.R4\About - FHIR® v4.0.1](about.md)
* [HL7.AT.FHIR.PRENUDGE.APPDATA.R4\Artifacts Summary - FHIR® v4.0.1](artifacts.md)
* [HL7.AT.FHIR.PRENUDGE.APPDATA.R4\Use Cases - FHIR® v4.0.1](use_cases.md)
* [HL7.AT.FHIR.PRENUDGE.APPDATA.R4\Downloads - FHIR® v4.0.1](downloads.md)

## Resources

### ValueSets

* [SNOMED CT AlcoholUse-Frequency](ValueSet-at-prenudge-alcoholuse-valueset-frequency.md)

### Resource Profiles

* [MyPatient](StructureDefinition-MyPatient.md)
* [AT PreNUDGE Observation Alcohol Use](StructureDefinition-at-prenudge-alcoholuse-observation.md)
* [AT PreNUDGE Observation Step Count](StructureDefinition-at-prenudge-stepcount-observation.md)

### ImplementationGuides

* [PreNUDGE FHIR® IG for Data Provider / Data from Apps (R4)](index.md)

### Questionnaires

* [Alkoholkonsum-Frequenz (letztes Jahr)](Questionnaire-AtPrenudgeQuestionnaireAlcoholUse.md)
* [Schrittanzahl (täglich)](Questionnaire-StepCountQuestionnaire.md)

### Examples

* [PatientExample (Patient)](Patient-PatientExample.md)
