# hl7.at.fhir.prenudge.appdata.r4#0.1.0: PreNUDGE FHIR® IG for Data Provider / Data from Apps (R4)

## Pages

* [HL7.AT.FHIR.PRENUDGE.APPDATA.R4\Home - FHIR® v4.0.1](index.md)
* [HL7.AT.FHIR.PRENUDGE.APPDATA.R4\Artifacts Summary - FHIR® v4.0.1](artifacts.md)
* [HL7.AT.FHIR.PRENUDGE.APPDATA.R4\Downloads - FHIR® v4.0.1](downloads.md)
* [HL7.AT.FHIR.PRENUDGE.APPDATA.R4\About - FHIR® v4.0.1](about.md)
* [HL7.AT.FHIR.PRENUDGE.APPDATA.R4\Background - FHIR® v4.0.1](background.md)
* [HL7.AT.FHIR.PRENUDGE.APPDATA.R4\Workflow - FHIR® v4.0.1](workflow.md)

## Resources

### CodeSystems

* [AT PreNUDGE WHOQOL-BREF Answer Scales](CodeSystem-whoqol-bref-scale.md)

### ValueSets

* [AT PreNUDGE Alcohol Use Frequency](ValueSet-prenudge-alcoholuse-frequency.md)
* [AT PreNUDGE Blood Glucose Meal Context](ValueSet-prenudge-bloodglucose-mealcontext.md)
* [AT PreNUDGE Observation Methods](ValueSet-prenudge-observation-method.md)
* [AT PreNUDGE Other Observations Codes](ValueSet-prenudge-other-observations-codes.md)
* [AT PreNUDGE Other Observations Units](ValueSet-prenudge-other-observations-units.md)
* [AT PreNUDGE WHOQOL-BREF Score Type ValueSet](ValueSet-prenudge-whoqol-bref-score-type.md)

### Resource Profiles

* [AT PreNUDGE Observation Alcohol Use](StructureDefinition-at-prenudge-alcoholuse-observation.md)
* [AT PreNUDGE Observation Blood Glucose (only in mg/dL)](StructureDefinition-at-prenudge-bloodglucose-observation.md)
* [AT PreNUDGE Observation Other not Quantities](StructureDefinition-at-prenudge-observation-other-not-quantities.md)
* [AT PreNUDGE Observation Other Quantities](StructureDefinition-at-prenudge-observation-other-quantities.md)
* [AT PreNUDGE Observation](StructureDefinition-at-prenudge-observation.md)
* [AT PreNUDGE Questionnaire](StructureDefinition-at-prenudge-questionnaire.md)
* [AT PreNUDGE Questionnaire Response](StructureDefinition-at-prenudge-questionnaireresponse.md)
* [AT PreNUDGE Observation Step Count](StructureDefinition-at-prenudge-stepcount-observation.md)
* [AT PreNUDGE Observation WHOQOL-BREF Score](StructureDefinition-at-prenudge-whoqol-bref-score-observation.md)

### ConceptMaps

* [AT PreNUDGE Code-to-Unit Mapping](ConceptMap-AtPrenudgeCodeUnitMap.md)

### ImplementationGuides

* [PreNUDGE FHIR® IG for Data Provider / Data from Apps (R4)](index.md)

### Questionnaires

* [Alkoholkonsum im letzten Jahr](Questionnaire-AlcoholUseQuestionnaire.md)
* [Blutzucker bei der letzten Messung](Questionnaire-BloodGlucoseQuestionnaire.md)
* [EHIS-PAQ: Zu-Fuß-Gehen](Questionnaire-StepCountEhisPaqQuestionnaire.md)
* [Schrittzahl am heutigen Tag](Questionnaire-StepCountQuantityQuestionnaire.md)
* [WHOQOL-BREF Lebensstil Selbsteinschätzung](Questionnaire-WhoQolBrefQuestionnaire.md)

### StructureMaps

* [Alcohol Use Q mapping frequency to O drinks per day](StructureMap-AlcoholQuestionnaireResponseToObservation.md)
* [Blood Glucose Q to O](StructureMap-BloodGlucoseQuestionnaireResponseToObservation.md)
* [Shared base for Q to O](StructureMap-QuestionnaireResponseToObservationBase.md)
* [Step Count Q to O](StructureMap-StepCountQuestionnaireResponseToObservation.md)
* [WHOQOL-BREF Q score to O score](StructureMap-WHOQOLBrefQuestionnaireResponseToObservation.md)

### Examples

* [alcoholuse-moderate-example (Observation)](Observation-alcoholuse-moderate-example.md)
* [alcoholuse-never-example (Observation)](Observation-alcoholuse-never-example.md)
* [alcoholuse-occasional-example (Observation)](Observation-alcoholuse-occasional-example.md)
* [bloodglucose-elevated-example (Observation)](Observation-bloodglucose-elevated-example.md)
* [bloodglucose-low-example (Observation)](Observation-bloodglucose-low-example.md)
* [bloodglucose-normal-example (Observation)](Observation-bloodglucose-normal-example.md)
* [stepcount-high-example (Observation)](Observation-stepcount-high-example.md)
* [stepcount-normal-example (Observation)](Observation-stepcount-normal-example.md)
* [stepcount-sedentary-example (Observation)](Observation-stepcount-sedentary-example.md)
* [whoqol-bref-score-example (Observation)](Observation-whoqol-bref-score-example.md)
* [example (Patient)](Patient-example.md)
* [AlcoholResponseDaily (QuestionnaireResponse)](QuestionnaireResponse-AlcoholResponseDaily.md)
* [AlcoholResponseNever (QuestionnaireResponse)](QuestionnaireResponse-AlcoholResponseNever.md)
* [bloodglucose-response-elevated-example (QuestionnaireResponse)](QuestionnaireResponse-bloodglucose-response-elevated-example.md)
* [bloodglucose-response-normal-example (QuestionnaireResponse)](QuestionnaireResponse-bloodglucose-response-normal-example.md)
* [stepcount-ehispaq-high (QuestionnaireResponse)](QuestionnaireResponse-stepcount-ehispaq-high.md)
* [stepcount-ehispaq-normal (QuestionnaireResponse)](QuestionnaireResponse-stepcount-ehispaq-normal.md)
* [stepcount-quantity-response-high-example (QuestionnaireResponse)](QuestionnaireResponse-stepcount-quantity-response-high-example.md)
* [stepcount-quantity-response-normal-example (QuestionnaireResponse)](QuestionnaireResponse-stepcount-quantity-response-normal-example.md)
* [whoqol-bref-response-example (QuestionnaireResponse)](QuestionnaireResponse-whoqol-bref-response-example.md)
