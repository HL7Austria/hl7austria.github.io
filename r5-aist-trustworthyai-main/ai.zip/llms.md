# fhir.ig.eu.aitransparency#0.1.0: null

## Pages

* [Home](index.md)
* [Examples](examples.md)
* [Dependencies](dependencies.md)
* [Terminology](terminology.md)
* [Extensions](extensions.md)
* [Profiles](profiles.md)
* [Artifacts Summary](artifacts.md)
* [Intellectual Property](ip-statements.md)

## Resources

### CodeSystems

* [EHDS Data Category Code System](CodeSystem-ehds-data-category-cs.md)
* [EHDS Secondary-Use Purpose Code System](CodeSystem-ehds-secondary-use-purpose-cs.md)
* [EHDS Usage Category Code System](CodeSystem-ehds-usage-category-cs.md)
* [EU AI Artifact Type Code System](CodeSystem-eu-ai-artifact-type-cs.md)
* [EU AI Audit Entity Role Code System](CodeSystem-eu-ai-audit-entity-role.md)
* [EU AI Case-Specific Indication Code System](CodeSystem-eu-ai-case-specific-indication-cs.md)
* [EU AI Clinical Validation Status Code System](CodeSystem-eu-ai-clinical-validation-status-cs.md)
* [EU AI Contact Purpose Code System](CodeSystem-eu-ai-contact-purpose-cs.md)
* [EU AI Data Quality Code System](CodeSystem-eu-ai-data-quality-cs.md)
* [EU AI Human Oversight Code System](CodeSystem-eu-ai-human-oversight-cs.md)
* [EU AI Identifier Type Code System](CodeSystem-eu-ai-identifier-type-cs.md)
* [EU AI Involvement Code System](CodeSystem-eu-ai-involvement-cs.md)
* [EU AI Performance Metric Code System](CodeSystem-eu-ai-performance-metric-cs.md)
* [EU AI System Property Code System](CodeSystem-eu-ai-system-property-cs.md)
* [GDPR Article 6 Legal Basis Code System](CodeSystem-gdpr-art6-codesystem.md)
* [GDPR Article 9 Condition Code System](CodeSystem-gdpr-art9-codesystem.md)

### ValueSets

* [EHDS Data Category Value Set](ValueSet-ehds-data-category-vs.md)
* [EHDS Secondary-Use Purpose Value Set](ValueSet-ehds-secondary-use-purpose-vs.md)
* [EHDS Usage Category Value Set](ValueSet-ehds-usage-category-vs.md)
* [EU AI Audit Entity Role Value Set](ValueSet-eu-ai-audit-entity-role-vs.md)
* [EU AI Case-Specific Indication Value Set](ValueSet-eu-ai-case-specific-indication-vs.md)
* [EU AI Clinical Validation Status Value Set](ValueSet-eu-ai-clinical-validation-status-vs.md)
* [EU AI Data Quality Value Set](ValueSet-eu-ai-data-quality-vs.md)
* [EU AI Human Oversight Action Value Set](ValueSet-eu-ai-human-oversight-action-vs.md)
* [EU AI Involvement Value Set](ValueSet-eu-ai-involvement-vs.md)
* [EU AI Performance Metric Value Set](ValueSet-eu-ai-performance-metric-vs.md)
* [GDPR Article 6 Legal Basis Value Set](ValueSet-gdpr-art6-legal-basis-vs.md)
* [GDPR Article 9 Condition Value Set](ValueSet-gdpr-art9-condition-vs.md)

### Resource Profiles

* [EU AI System Device](StructureDefinition-eu-ai-device.md)
* [EU AI Human Oversight Assessment](StructureDefinition-eu-ai-human-oversight.md)
* [EU AI Execution Audit Event](StructureDefinition-eu-ai-machine-execution-audit-event.md)
* [EU AI Act Model Card](StructureDefinition-eu-ai-model-card.md)
* [EU AI Generated Observation](StructureDefinition-eu-ai-observation.md)
* [EU AI Responsible Organization](StructureDefinition-eu-ai-organization.md)
* [EU AI Patient Explanation Communication](StructureDefinition-eu-ai-patient-explanation.md)
* [EU AI Practitioner Role](StructureDefinition-eu-ai-practitionerrole.md)
* [EU AI Provenance](StructureDefinition-eu-ai-provenance.md)

### Extensions

* [AI Clinical Validation Status](StructureDefinition-ai-clinical-validation-status.md)
* [AI Performance Metrics](StructureDefinition-ai-performance-metrics.md)
* [AI Retention Information](StructureDefinition-ai-retention-information.md)
* [AI System-Specific Training Status](StructureDefinition-ai-system-training-status.md)
* [AI Training Data Metadata](StructureDefinition-ai-training-data.md)
* [Automated Decision-Making Flag](StructureDefinition-automated-decision-flag.md)
* [Case-Specific Indication](StructureDefinition-case-specific-indication.md)
* [EHDS Data Permit](StructureDefinition-ehds-data-permit.md)
* [EHDS Secondary Use Purpose](StructureDefinition-ehds-secondary-use-purpose.md)
* [EHDS Usage Category](StructureDefinition-ehds-usage-category.md)
* [EU Conformity Declaration Reference](StructureDefinition-eu-ai-conformity-reference.md)
* [EU AI DPIA Reference](StructureDefinition-eu-ai-dpia-reference.md)
* [EU AI Log Integrity Signature](StructureDefinition-eu-ai-log-integrity.md)
* [Model Card Reference](StructureDefinition-ext-model-card.md)
* [Patient AI Info Provided Flag](StructureDefinition-patient-ai-info-provided-flag.md)
* [Third-Country Data Transfer](StructureDefinition-third-country-data-transfer.md)

### Devices

* [fd450f5e-749e-48b8-8ea8-23b8ed2b9592](Device-fd450f5e-749e-48b8-8ea8-23b8ed2b9592.md)

### DocumentReferences

* [029e523f-6c49-4021-b909-674ebfc08c49](DocumentReference-029e523f-6c49-4021-b909-674ebfc08c49.md)
* [42fa4d86-32b8-4452-abc9-b0ad93cab5fc](DocumentReference-42fa4d86-32b8-4452-abc9-b0ad93cab5fc.md)

### ImplementationGuides

* [EUAITransparencyIG](index.md)

### Observations

* [2159aa84-4d4c-4146-9ef7-19362414e19c](Observation-2159aa84-4d4c-4146-9ef7-19362414e19c.md)
* [59f36b5b-48c8-44ad-9b63-539db5057277](Observation-59f36b5b-48c8-44ad-9b63-539db5057277.md)
* [c8832b3e-4437-436b-8ed4-8a2e22ce9d2a](Observation-c8832b3e-4437-436b-8ed4-8a2e22ce9d2a.md)

### Organizations

* [MIRA](Organization-0263776a-d93e-41a5-aaed-8a8496a87a22.md)

### Examples

* [sc-02-validation-human-oversight-001 (ArtifactAssessment)](ArtifactAssessment-sc-02-validation-human-oversight-001.md)
* [sc-03-override-human-oversight-001 (ArtifactAssessment)](ArtifactAssessment-sc-03-override-human-oversight-001.md)
* [sc-04-correction-exp-human-oversight-001 (ArtifactAssessment)](ArtifactAssessment-sc-04-correction-exp-human-oversight-001.md)
* [sc-01-ai-only-audit-event-ai-execution-001 (AuditEvent)](AuditEvent-sc-01-ai-only-audit-event-ai-execution-001.md)
* [sc-02-validation-audit-event-ai-execution-001 (AuditEvent)](AuditEvent-sc-02-validation-audit-event-ai-execution-001.md)
* [sc-03-override-audit-event-ai-execution-001 (AuditEvent)](AuditEvent-sc-03-override-audit-event-ai-execution-001.md)
* [sc-04-correction-exp-audit-event-ai-execution-001 (AuditEvent)](AuditEvent-sc-04-correction-exp-audit-event-ai-execution-001.md)
* [sc-04-correction-exp-patient-explanation-001 (Communication)](Communication-sc-04-correction-exp-patient-explanation-001.md)
* [device-riskassist-ai (Device)](Device-device-riskassist-ai.md)
* [eu-conformity-declaration (DocumentReference)](DocumentReference-eu-conformity-declaration.md)
* [modelcard-riskassist-ai (DocumentReference)](DocumentReference-modelcard-riskassist-ai.md)
* [encounter-001 (Encounter)](Encounter-encounter-001.md)
* [sc-01-ai-only-ai-observation-risk-001 (Observation)](Observation-sc-01-ai-only-ai-observation-risk-001.md)
* [sc-01-ai-only-observation-blood-pressure-001 (Observation)](Observation-sc-01-ai-only-observation-blood-pressure-001.md)
* [sc-01-ai-only-observation-consciousness-status-001 (Observation)](Observation-sc-01-ai-only-observation-consciousness-status-001.md)
* [sc-01-ai-only-observation-heart-rate-001 (Observation)](Observation-sc-01-ai-only-observation-heart-rate-001.md)
* [sc-01-ai-only-observation-oxygen-saturation-001 (Observation)](Observation-sc-01-ai-only-observation-oxygen-saturation-001.md)
* [sc-01-ai-only-observation-respiratory-rate-001 (Observation)](Observation-sc-01-ai-only-observation-respiratory-rate-001.md)
* [sc-01-ai-only-observation-temperature-001 (Observation)](Observation-sc-01-ai-only-observation-temperature-001.md)
* [sc-02-validation-ai-observation-risk-001 (Observation)](Observation-sc-02-validation-ai-observation-risk-001.md)
* [sc-02-validation-observation-blood-pressure-001 (Observation)](Observation-sc-02-validation-observation-blood-pressure-001.md)
* [sc-02-validation-observation-consciousness-status-001 (Observation)](Observation-sc-02-validation-observation-consciousness-status-001.md)
* [sc-02-validation-observation-heart-rate-001 (Observation)](Observation-sc-02-validation-observation-heart-rate-001.md)
* [sc-02-validation-observation-oxygen-saturation-001 (Observation)](Observation-sc-02-validation-observation-oxygen-saturation-001.md)
* [sc-02-validation-observation-respiratory-rate-001 (Observation)](Observation-sc-02-validation-observation-respiratory-rate-001.md)
* [sc-02-validation-observation-temperature-001 (Observation)](Observation-sc-02-validation-observation-temperature-001.md)
* [sc-03-override-ai-observation-risk-001 (Observation)](Observation-sc-03-override-ai-observation-risk-001.md)
* [sc-03-override-observation-blood-pressure-001 (Observation)](Observation-sc-03-override-observation-blood-pressure-001.md)
* [sc-03-override-observation-consciousness-status-001 (Observation)](Observation-sc-03-override-observation-consciousness-status-001.md)
* [sc-03-override-observation-heart-rate-001 (Observation)](Observation-sc-03-override-observation-heart-rate-001.md)
* [sc-03-override-observation-oxygen-saturation-001 (Observation)](Observation-sc-03-override-observation-oxygen-saturation-001.md)
* [sc-03-override-observation-respiratory-rate-001 (Observation)](Observation-sc-03-override-observation-respiratory-rate-001.md)
* [sc-03-override-observation-temperature-001 (Observation)](Observation-sc-03-override-observation-temperature-001.md)
* [sc-04-correction-exp-ai-observation-risk-001 (Observation)](Observation-sc-04-correction-exp-ai-observation-risk-001.md)
* [sc-04-correction-exp-corrected-clinical-observation-001 (Observation)](Observation-sc-04-correction-exp-corrected-clinical-observation-001.md)
* [sc-04-correction-exp-observation-blood-pressure-001 (Observation)](Observation-sc-04-correction-exp-observation-blood-pressure-001.md)
* [sc-04-correction-exp-observation-consciousness-status-001 (Observation)](Observation-sc-04-correction-exp-observation-consciousness-status-001.md)
* [sc-04-correction-exp-observation-heart-rate-001 (Observation)](Observation-sc-04-correction-exp-observation-heart-rate-001.md)
* [sc-04-correction-exp-observation-oxygen-saturation-001 (Observation)](Observation-sc-04-correction-exp-observation-oxygen-saturation-001.md)
* [sc-04-correction-exp-observation-respiratory-rate-001 (Observation)](Observation-sc-04-correction-exp-observation-respiratory-rate-001.md)
* [sc-04-correction-exp-observation-temperature-001 (Observation)](Observation-sc-04-correction-exp-observation-temperature-001.md)
* [Example Hospital (Organization)](Organization-organization-examplehospital.md)
* [ExampleMed AI GmbH (Organization)](Organization-organization-examplemed.md)
* [patient-001 (Patient)](Patient-patient-001.md)
* [practitioner-001 (Practitioner)](Practitioner-practitioner-001.md)
* [practitionerrole-reviewer-001 (PractitionerRole)](PractitionerRole-practitionerrole-reviewer-001.md)
* [example-secondary-use-provenance (Provenance)](Provenance-example-secondary-use-provenance.md)
* [sc-01-ai-only-provenance-ai-output-001 (Provenance)](Provenance-sc-01-ai-only-provenance-ai-output-001.md)
* [sc-02-validation-provenance-ai-output-001 (Provenance)](Provenance-sc-02-validation-provenance-ai-output-001.md)
* [sc-03-override-provenance-ai-output-001 (Provenance)](Provenance-sc-03-override-provenance-ai-output-001.md)
* [sc-04-correction-exp-provenance-ai-output-001 (Provenance)](Provenance-sc-04-correction-exp-provenance-ai-output-001.md)
