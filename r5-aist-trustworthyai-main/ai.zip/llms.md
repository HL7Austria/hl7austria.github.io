# fhir.ig.eu.aitransparency#0.1.0: null

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [EU AI Act Custom Codes](CodeSystem-EUAIActCodeSystem.md)
* [GDPR Art 6 Legal Basis](CodeSystem-gdpr-art6-codesystem.md)
* [GDPR Art 9 Exceptions](CodeSystem-gdpr-art9-codesystem.md)

### ValueSets

* [EHDS Data Category ValueSet (Final Regulation 2025/327)](ValueSet-ehds-data-category-vs.md)
* [EHDS Usage Category ValueSet](ValueSet-ehds-usage-category-vs.md)
* [AI Data Quality ValueSet](ValueSet-eu-ai-data-quality-vs.md)
* [Human Intervention Type ValueSet](ValueSet-eu-ai-intervention-vs.md)
* [AI Performance Metric ValueSet](ValueSet-eu-ai-performance-metric-vs.md)
* [EU AI Case-Specific Indication ValueSet](ValueSet-eu-case-specific-indication-vs.md)
* [GDPR Art 6 Legal Basis for AI](ValueSet-gdpr-art6-legal-basis-vs.md)
* [GDPR Art 9 Exception for AI Health Data](ValueSet-gdpr-art9-exception-vs.md)

### Resource Profiles

* [EU AI & EHDS Consent Profile](StructureDefinition-eu-ai-consent.md)
* [EU AI Act Compliant Device](StructureDefinition-eu-ai-device.md)
* [EU AI Act Human Oversight (HL)](StructureDefinition-eu-ai-human-oversight.md)
* [EU AI Act Machine Execution Audit Event](StructureDefinition-eu-ai-machine-execution-audit-event.md)
* [EU AI Act Model Card](StructureDefinition-eu-ai-model-card.md)
* [EU AI Act Observation (Validated Result)](StructureDefinition-eu-ai-observation.md)
* [EU AI Responsible Organization](StructureDefinition-eu-ai-organization.md)
* [EU AI Act Patient Right to Explanation](StructureDefinition-eu-ai-patient-explanation.md)
* [EU AI Act Human Overseer (PractitionerRole)](StructureDefinition-eu-ai-practitionerrole.md)
* [EU AI Act Provenance (Human-in-the-Loop)](StructureDefinition-eu-ai-provenance.md)

### Extensions

* [AI Performance Metrics](StructureDefinition-ai-performance-metrics.md)
* [AI Privacy Metadata](StructureDefinition-ai-privacy-metadata.md)
* [AI System Specific Training](StructureDefinition-ai-system-training-status.md)
* [AI Training Data Metadata](StructureDefinition-ai-training-data.md)
* [Case-Specific Indication](StructureDefinition-case-specific-indication.md)
* [EHDS Data Permit](StructureDefinition-ehds-data-permit.md)
* [EHDS Usage Category](StructureDefinition-ehds-usage-category.md)
* [EU AI Act Explanation Requested Flag](StructureDefinition-eu-ai-explanation-requested.md)
* [EU AI Act Log Integrity Signature](StructureDefinition-eu-ai-log-integrity.md)
* [Model Card Reference](StructureDefinition-ext-model-card.md)
* [Patient AI Info Provided Flag](StructureDefinition-patient-ai-info-provided.md)
* [Third-Country Data Transfer](StructureDefinition-third-country-data-transfer.md)

### ImplementationGuides

* [EUAITransparencyIG](index.md)

### Examples

* [oversight-dr-thorne-override (ArtifactAssessment)](ArtifactAssessment-oversight-dr-thorne-override.md)
* [audit-ai-execution (AuditEvent)](AuditEvent-audit-ai-execution.md)
* [comm-patient-explanation (Communication)](Communication-comm-patient-explanation.md)
* [consent-vance-ai (Consent)](Consent-consent-vance-ai.md)
* [device-aurascan-ai (Device)](Device-device-aurascan-ai.md)
* [doc-ai-heatmap (DocumentReference)](DocumentReference-doc-ai-heatmap.md)
* [doc-patient-explanation (DocumentReference)](DocumentReference-doc-patient-explanation.md)
* [modelcard-aurascan (DocumentReference)](DocumentReference-modelcard-aurascan.md)
* [input-ct-thorax (ImagingStudy)](ImagingStudy-input-ct-thorax.md)
* [observation-ai-nodule (Observation)](Observation-observation-ai-nodule.md)
* [Aetheria HealthTech Systems Corp. (Organization)](Organization-org-aetheria-health.md)
* [St. Chronos Medical Center (Organization)](Organization-org-chronos-medical.md)
* [patient-elias-vance (Patient)](Patient-patient-elias-vance.md)
* [doctor-aris-thorne (Practitioner)](Practitioner-doctor-aris-thorne.md)
* [role-dr-thorne (PractitionerRole)](PractitionerRole-role-dr-thorne.md)
* [prov-ai-lineage (Provenance)](Provenance-prov-ai-lineage.md)
