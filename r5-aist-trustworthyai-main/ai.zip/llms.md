# fhir.ig.eu.aitransparency#0.1.0: null

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [EU AI Transparency Custom Codes](CodeSystem-EUAIActCodeSystem.md)
* [EHDS Secondary Use Purpose CodeSystem](CodeSystem-ehds-purpose-codesystem.md)
* [GDPR Article 6 Legal Basis CodeSystem](CodeSystem-gdpr-art6-codesystem.md)
* [GDPR Article 9 Exception CodeSystem](CodeSystem-gdpr-art9-codesystem.md)

### ValueSets

* [EHDS Data Category ValueSet](ValueSet-ehds-data-category-vs.md)
* [EHDS Secondary Use Purpose ValueSet](ValueSet-ehds-secondary-use-purpose-vs.md)
* [EHDS Usage Category ValueSet](ValueSet-ehds-usage-category-vs.md)
* [AI Clinical Validation Status ValueSet](ValueSet-eu-ai-clinical-validation-status-vs.md)
* [AI Data Quality ValueSet](ValueSet-eu-ai-data-quality-vs.md)
* [Human Intervention Type ValueSet](ValueSet-eu-ai-intervention-vs.md)
* [AI Performance Metric ValueSet](ValueSet-eu-ai-performance-metric-vs.md)
* [EU AI Case-Specific Indication ValueSet](ValueSet-eu-case-specific-indication-vs.md)
* [GDPR Article 6 Legal Basis ValueSet](ValueSet-gdpr-art6-legal-basis-vs.md)
* [GDPR Article 9 Exception ValueSet](ValueSet-gdpr-art9-exception-vs.md)

### Resource Profiles

* [EU AI Consent and Processing Context](StructureDefinition-eu-ai-consent.md)
* [EU AI System Device](StructureDefinition-eu-ai-device.md)
* [EU AI Human Oversight Assessment](StructureDefinition-eu-ai-human-oversight.md)
* [EU AI Execution Audit Event](StructureDefinition-eu-ai-machine-execution-audit-event.md)
* [EU AI Act Model Card](StructureDefinition-eu-ai-model-card.md)
* [EU AI Generated Observation](StructureDefinition-eu-ai-observation.md)
* [EU AI Responsible Organization](StructureDefinition-eu-ai-organization.md)
* [EU AI Patient Explanation Communication](StructureDefinition-eu-ai-patient-explanation.md)
* [EU AI Practitioner Role](StructureDefinition-eu-ai-practitionerrole.md)
* [EU AI Provenance](StructureDefinition-eu-ai-provenance.md)

### Extensions

* [AI Clinical Validation Status](StructureDefinition-ai-clinical-validation-status.md)
* [AI Performance Metrics](StructureDefinition-ai-performance-metrics.md)
* [AI Privacy Metadata](StructureDefinition-ai-privacy-metadata.md)
* [AI System Specific Training](StructureDefinition-ai-system-training-status.md)
* [AI Training Data Metadata](StructureDefinition-ai-training-data.md)
* [Automated Decision-Making Flag](StructureDefinition-automated-decision-flag.md)
* [Case-Specific Indication](StructureDefinition-case-specific-indication.md)
* [EHDS Data Permit](StructureDefinition-ehds-data-permit.md)
* [EHDS Secondary Use Purpose](StructureDefinition-ehds-secondary-use-purpose.md)
* [EHDS Usage Category](StructureDefinition-ehds-usage-category.md)
* [EU AI Act Explanation Requested Flag](StructureDefinition-eu-ai-explanation-requested.md)
* [EU AI Act Log Integrity Signature](StructureDefinition-eu-ai-log-integrity.md)
* [Model Card Reference](StructureDefinition-ext-model-card.md)
* [Patient AI Info Provided Flag](StructureDefinition-patient-ai-info-provided.md)
* [Third-Country Data Transfer](StructureDefinition-third-country-data-transfer.md)

### ImplementationGuides

* [EUAITransparencyIG](index.md)

### Examples

* [sc-02-validation-human-oversight-001 (ArtifactAssessment)](ArtifactAssessment-sc-02-validation-human-oversight-001.md)
* [sc-02-validation-audit-event-ai-execution-001 (AuditEvent)](AuditEvent-sc-02-validation-audit-event-ai-execution-001.md)
* [Communication-sc-02-patient-explanation-001 (Communication)](Communication-Communication-sc-02-patient-explanation-001.md)
* [sc-02-validation-consent-ai-use-001 (Consent)](Consent-sc-02-validation-consent-ai-use-001.md)
* [device-riskassist-ai (Device)](Device-device-riskassist-ai.md)
* [modelcard-riskassist-ai (DocumentReference)](DocumentReference-modelcard-riskassist-ai.md)
* [encounter-001 (Encounter)](Encounter-encounter-001.md)
* [sc-02-validation-ai-observation-risk-001 (Observation)](Observation-sc-02-validation-ai-observation-risk-001.md)
* [sc-02-validation-observation-blood-pressure-001 (Observation)](Observation-sc-02-validation-observation-blood-pressure-001.md)
* [sc-02-validation-observation-consciousness-status-001 (Observation)](Observation-sc-02-validation-observation-consciousness-status-001.md)
* [sc-02-validation-observation-heart-rate-001 (Observation)](Observation-sc-02-validation-observation-heart-rate-001.md)
* [sc-02-validation-observation-oxygen-saturation-001 (Observation)](Observation-sc-02-validation-observation-oxygen-saturation-001.md)
* [sc-02-validation-observation-respiratory-rate-001 (Observation)](Observation-sc-02-validation-observation-respiratory-rate-001.md)
* [sc-02-validation-observation-temperature-001 (Observation)](Observation-sc-02-validation-observation-temperature-001.md)
* [Example Hospital (Organization)](Organization-organization-examplehospital.md)
* [ExampleMed AI GmbH (Organization)](Organization-organization-examplemed.md)
* [patient-001 (Patient)](Patient-patient-001.md)
* [practitioner-001 (Practitioner)](Practitioner-practitioner-001.md)
* [practitionerrole-reviewer-001 (PractitionerRole)](PractitionerRole-practitionerrole-reviewer-001.md)
* [sc-02-validation-provenance-ai-output-001 (Provenance)](Provenance-sc-02-validation-provenance-ai-output-001.md)
