# EU AI Audit Entity Role Value Set - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **EU AI Audit Entity Role Value Set**

## ValueSet: EU AI Audit Entity Role Value Set 

| | |
| :--- | :--- |
| *Official URL*:http://example.org/fhir/eu-ai-transparency/ValueSet/eu-ai-audit-entity-role-vs | *Version*:0.1.0 |
| Draft as of 2026-09-07 | *Computable Name*:EUAIAuditEntityRoleValueSet |

 
Roles of entities involved in an AI execution audit event. 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R5/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "eu-ai-audit-entity-role-vs",
  "url" : "http://example.org/fhir/eu-ai-transparency/ValueSet/eu-ai-audit-entity-role-vs",
  "version" : "0.1.0",
  "name" : "EUAIAuditEntityRoleValueSet",
  "title" : "EU AI Audit Entity Role Value Set",
  "status" : "draft",
  "date" : "2026-09-07T08:39:53+00:00",
  "publisher" : "Selina Adlberger",
  "description" : "Roles of entities involved in an AI execution audit event.",
  "compose" : {
    "include" : [{
      "system" : "http://example.org/fhir/eu-ai-transparency/CodeSystem/eu-ai-audit-entity-role"
    }]
  }
}

```
