# Trust AI Case-Specific Indication Value Set - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Trust AI Case-Specific Indication Value Set**

## ValueSet: Trust AI Case-Specific Indication Value Set 

| | |
| :--- | :--- |
| *Official URL*:http://example.org/fhir/trust-ai-transparency/ValueSet/trust-ai-case-specific-indication-vs | *Version*:0.1.0 |
| Active as of 2026-10-02 | *Computable Name*:TrustAICaseSpecificIndicationVS |

 
Clinical purposes for applying an AI system in an individual care context. 

 **References** 

* [Case-Specific Indication](StructureDefinition-case-specific-indication.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R5/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "trust-ai-case-specific-indication-vs",
  "url" : "http://example.org/fhir/trust-ai-transparency/ValueSet/trust-ai-case-specific-indication-vs",
  "version" : "0.1.0",
  "name" : "TrustAICaseSpecificIndicationVS",
  "title" : "Trust AI Case-Specific Indication Value Set",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-02T06:10:43+00:00",
  "publisher" : "Selina Adlberger",
  "description" : "Clinical purposes for applying an AI system in an individual care context.",
  "compose" : {
    "include" : [{
      "system" : "http://example.org/fhir/trust-ai-transparency/CodeSystem/trust-ai-case-specific-indication-cs"
    }]
  }
}

```
