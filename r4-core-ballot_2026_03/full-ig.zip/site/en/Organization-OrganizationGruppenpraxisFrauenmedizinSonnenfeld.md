# OrganizationGruppenpraxisFrauenmedizinSonnenfeld - HL7® Austria FHIR® Core Implementation Guide v2.1.0

## Example Organization: OrganizationGruppenpraxisFrauenmedizinSonnenfeld

Die Gruppenpraxis Frauenmedizin Sonnenfeld OG ist eine fiktive ärztliche Wahlarzt-Gruppenpraxis für Frauenheilkunde und Geburtshilfe in der Steiermark. Sie wird von Dr. Anna Leitner und Dr. Thomas Hofer gemeinschaftlich geführt. Es besteht kein Kassenvertrag mit einem österreichischen gesetzlichen Krankenversicherungsträger. Ärztliche Leistungen werden privat verrechnet; eine allfällige Kostenerstattung kann nach den geltenden Bestimmungen beim zuständigen Krankenversicherungsträger beantragt werden. Die freiberufliche Hebamme Sarah Berger, BSc, bietet im Rahmen einer Kooperation Hebammenberatung in den Räumlichkeiten der Gruppenpraxis an und ist keine Gesellschafterin der OG.



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "OrganizationGruppenpraxisFrauenmedizinSonnenfeld",
  "meta" : {
    "profile" : ["https://fhir.hl7.at/core/r4/StructureDefinition/at-core-organization"]
  },
  "identifier" : [{
    "system" : "urn:publicid:gv.at:baseid+XFN",
    "value" : "999998x"
  }],
  "active" : true,
  "type" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
      "code" : "prov",
      "display" : "Healthcare Provider"
    }],
    "text" : "Ärztliche Gruppenpraxis für Frauenheilkunde und Geburtshilfe (OG)"
  }],
  "name" : "Gruppenpraxis Frauenmedizin Sonnenfeld OG",
  "alias" : ["Frauenmedizin Sonnenfeld"],
  "telecom" : [{
    "system" : "phone",
    "value" : "+43 732 555 410",
    "use" : "work"
  },
  {
    "system" : "email",
    "value" : "ordination@frauenmedizin-sonnenfeld.example",
    "use" : "work"
  }],
  "address" : [{
    "use" : "work",
    "type" : "physical",
    "line" : ["Sonnenfeldgasse 12, 1. Stock"],
    "_line" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
        "valueString" : "Sonnenfeldgasse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
        "valueString" : "12"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-additionalLocator",
        "valueString" : "1. Stock"
      }]
    }],
    "city" : "Sonnenfeld",
    "state" : "Steiermark",
    "postalCode" : "8000",
    "country" : "AUT"
  }]
}

```
