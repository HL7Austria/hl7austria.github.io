# hl7.at.fhir.core.r5#2.1.0: HL7® Austria FHIR® Core Implementation Guide

## Pages

* [HL7.AT.FHIR.CORE.R5\Home - FHIR® v5.0.0](index.md)
* [HL7.AT.FHIR.CORE.R5\Artifacts Summary - FHIR® v5.0.0](artifacts.md)

## Resources

### CodeSystems

* [CodeSystem for Austrian Funktionscodes Excerpt](CodeSystem-at-funktionscode.md)

### ValueSets

* [ValueSet for Austrian Funktionscodes Excerpt](ValueSet-at-funktionscode-vs.md)

### Complex-type Profiles

* [HL7® AT Core Address Profile](StructureDefinition-at-core-address.md)
* [HL7® AT Core ExtendedContactDetail Profile](StructureDefinition-at-core-extendedContactDetail.md)

### Resource Profiles

* [HL7® AT Core HealthcareService Profile](StructureDefinition-at-core-HealthcareService.md)
* [HL7® AT Core Location Profile](StructureDefinition-at-core-location.md)
* [HL7® AT Core Organization Profile](StructureDefinition-at-core-organization.md)
* [HL7® AT Core Patient Profile](StructureDefinition-at-core-patient.md)
* [HL7® AT Core Practitioner Profile](StructureDefinition-at-core-practitioner.md)
* [HL7® AT Core PractitionerRole Profile](StructureDefinition-at-core-practitionerRole.md)
* [HL7® AT Core ValueSet Profile](StructureDefinition-at-core-valueset.md)

### Extensions

* [Address Additional Information](StructureDefinition-at-core-ext-address-additionalInformation.md)
* [Address Municipality Code](StructureDefinition-at-core-ext-address-municipalityCode.md)
* [Administrative Gender Addition](StructureDefinition-at-core-ext-gender-administrativeGenderAddition.md)
* [Patient Religion](StructureDefinition-at-core-ext-patient-religion.md)
* [System OID](StructureDefinition-at-core-ext-valueset-systemoid.md)

### ImplementationGuides

* [HL7® Austria FHIR® Core Implementation Guide](index.md)

### Examples

* [Rheumatology Service (HealthcareService)](HealthcareService-ExampleHealthcareService.md)
* [Campus Graz (Location)](Location-HL7ATCoreLocationGraz.md)
* [Campus Linz (Location)](Location-HL7ATCoreLocationLinz.md)
* [Amadeus Spital (Organization)](Organization-HL7ATCoreOrganizationExample01.md)
* [Landeskrankenhaus Hall in Tirol (Organization)](Organization-HL7ATCoreOrganizationExample02-MultipleVPNR.md)
* [HL7ATCorePatientExample01 (Patient)](Patient-HL7ATCorePatientExample01.md)
* [HL7ATCorePatientExample02-deceasedTime (Patient)](Patient-HL7ATCorePatientExample02-deceasedTime.md)
* [HL7ATCorePatientExample03-deceasedBoolean (Patient)](Patient-HL7ATCorePatientExample03-deceasedBoolean.md)
* [HL7ATCorePatientExample04-Full (Patient)](Patient-HL7ATCorePatientExample04-Full.md)
* [HL7ATCorePatientExample05-FullElga (Patient)](Patient-HL7ATCorePatientExample05-FullElga.md)
* [HL7ATCorePatientExample06-GenderExtension (Patient)](Patient-HL7ATCorePatientExample06-GenderExtension.md)
* [HL7ATCorePatientExample07-MunicipalityCode (Patient)](Patient-HL7ATCorePatientExample07-MunicipalityCode.md)
* [HL7ATCorePractitionerExample01 (Practitioner)](Practitioner-HL7ATCorePractitionerExample01.md)
* [HL7ATCorePractitionerRoleExample01 (PractitionerRole)](PractitionerRole-HL7ATCorePractitionerRoleExample01.md)
