# Überblick Anwendungsfälle - ELGA e-Diagnose R4 (Draft) v0.1.0

## Überblick Anwendungsfälle

### Fachliche Anwendungsfälle

Die fachlichen Anwendungsfälle sind hier nachzulesen: TODO Link ergänzen

#### Anwendungsfalldiagramm

Das folgende Anwendungsfalldiagramm zeigt die zentralen Anwendungsfälle der e-Diagnose und die Interaktion der verschiedenen Akteure.

![](ediag_uc_diagramm.drawio.png)

### Technischen Anwendungsfälle

Die nachfolgenden Kapitel beschreiben die fachlichen Anwendungsfälle der e-Diagnose in Form technischer Use Cases. Die zugehörigen Sequenzdiagramme stellen die beteiligten Akteure, Schnittstellen und Prozessabläufe dar.

Die e-Diagnose dient der Verwaltung von Diagnosen, Prozeduren sowie Allergien und Intoleranzen für ELGA-Teilnehmer. Die Fachanwendung ermöglicht das Laden, Erfassen, Bearbeiten, Stornieren und Löschen der entsprechenden Daten. Darüber hinaus unterstützt sie die Verwaltung dieser Informationen in einer Gesamtansicht.

Vor der Durchführung von Änderungen werden die aktuellen Datenbestände geladen. Anschließend können Listen bearbeitet sowie fachliche Einzelressourcen (z. B. Condition, Procedure, AllergyIntolerance) erfasst, geändert, storniert oder gelöscht werden.

Die folgende Darstellung gibt einen Überblick über die in der e-Diagnose verwalteten Kategorien sowie deren Zuordnung auf der jeweiligen Listen- und Einzelressourcenebene.

Die nachfolgend beschriebenen Sub-Use-Cases definieren die erforderlichen Interaktionen und Transaktionen zur Umsetzung dieser fachlichen Funktionen. Sie basieren auf den folgenden Interaktionsarten:

* [Lesen](uc_ediag_01_lesen.md)
* [Schreiben](uc_ediag_02_schreiben.md)
* [Teilnehmerrechte ausüben](uc_ediag_03_teilnehmer.md)

