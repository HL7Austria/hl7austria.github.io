# hl7.at.fhir.elga.ediag.r4#0.1.0: ELGA e-Diagnose R4 (Draft)(en)

## Pages

* [Home](index.md)
* [Teilnehmerrechte ausüben](uc_ediag_03_teilnehmer.md)
* [Herausforderungen](challenges.md)
* [Patient Journey](patient_journey.md)
* [Copyright](copyright.md)
* [Überblick Anwendungsfälle](use_cases.md)
* [Artifacts Summary](artifacts.md)
* [Lesen](uc_ediag_01_lesen.md)
* [Transaktionen](transaction.md)
* [Impressum](imprint.md)
* [Download](download.md)
* [Autoren und Mitwirkende](contributors.md)
* [Akteure](actors.md)
* [Workflowmanagement](workflowmanagement.md)
* [Hintergrund](background.md)
* [Designentscheidungen](design_choices.md)
* [Umfang und Inhalt](scope_and_content.md)
* [Publikationsinformationen](publication_info.md)
* [Schreiben](uc_ediag_02_schreiben.md)
* [Dependencies](dependencies.md)

## Resources

### CodeSystems

* [Business Identifier Codes](CodeSystem-at-ediag-codesystem-business-identifier.md)
* [Reaktionszeit Codes](CodeSystem-at-ediag-codesystem-reaction-time-cs.md)

### ValueSets

* [AT e-Diagnose AllergyIntolerance Code](ValueSet-at-ediag-allergyintolerance-code.md)
* [AT e-Diagnose Condition Code](ValueSet-at-ediag-condition-code.md)
* [ELGA AT e-Diagnose List Entry Code Value Set](ValueSet-at-ediag-list-code-vs.md)
* [ELGA List Empty Reason Value Set](ValueSet-at-ediag-list-emptyreason-vs.md)
* [AT e-Diagnose Procedure Code](ValueSet-at-ediag-procedure-code.md)
* [AT e-Diagnose Reaction Time Value Set](ValueSet-at-ediag-reaction-time-vs.md)

### Resource Profiles

* [AT ELGA e-Diagnose AllergyIntolerance](StructureDefinition-at-elga-ediag-allergyintolerance.md)
* [AT ELGA e-Diagnose Condition](StructureDefinition-at-elga-ediag-condition.md)
* [AT ELGA e-Diagnose List](StructureDefinition-at-elga-ediag-list.md)
* [AT ELGA e-Diagnose Procedure](StructureDefinition-at-elga-ediag-procedure.md)

### Extensions

* [AT ELGA Entered In Error](StructureDefinition-at-elga-ediag-ext-entered-in-error.md)
* [AT ELGA Reaktionszeit](StructureDefinition-at-elga-ediag-reaction-time.md)
* [AT ELGA Reported (Fremdangabe)](StructureDefinition-at-elga-ediag-reported.md)

### ImplementationGuides

* [ELGA e-Diagnose R4 (Draft)](ImplementationGuide-hl7.at.fhir.elga.ediag.r4.md)

### OperationDefinitions

* [e-Diagnose Operation $delete](OperationDefinition-at-ediag-operation-diagnose-delete.md)
* [e-Diagnose Operation $entered-in-error](OperationDefinition-at-ediag-operation-diagnose-entered-in-error.md)
* [e-Diagnose Operation $delete-history-version](OperationDefinition-at-ediag-operation-list-delete-history-version.md)
* [e-Diagnose Operation $write](OperationDefinition-at-ediag-operation-list-write.md)

### Examples

* [AllergyEntry01 (AllergyIntolerance)](AllergyIntolerance-AllergyEntry01.md)
* [ConditionSearchSet01 (Bundle)](Bundle-ConditionSearchSet01.md)
* [ConditionSearchSet02 (Bundle)](Bundle-ConditionSearchSet02.md)
* [ConditionSearchSet03 (Bundle)](Bundle-ConditionSearchSet03.md)
* [ConditionEnteredInError (Condition)](Condition-ConditionEnteredInError.md)
* [ConditionEntry01 (Condition)](Condition-ConditionEntry01.md)
* [ConditionEntry02 (Condition)](Condition-ConditionEntry02.md)
* [ConditionEntry03 (Condition)](Condition-ConditionEntry03.md)
* [ConditionEntry04 (Condition)](Condition-ConditionEntry04.md)
* [ConditionEntry05 (Condition)](Condition-ConditionEntry05.md)
* [DeviceExample (Device)](Device-DeviceExample.md)
* [AllergyList01 (List)](List-AllergyList01.md)
* [AllergyListEmpty (List)](List-AllergyListEmpty.md)
* [ConditionList01 (List)](List-ConditionList01.md)
* [ConditionList02 (List)](List-ConditionList02.md)
* [ConditionList03 (List)](List-ConditionList03.md)
* [ConditionListEmpty (List)](List-ConditionListEmpty.md)
* [ProcedureList01 (List)](List-ProcedureList01.md)
* [ProcedureListEmpty (List)](List-ProcedureListEmpty.md)
* [PatientExample (Patient)](Patient-PatientExample.md)
* [PractitionerExample (Practitioner)](Practitioner-PractitionerExample.md)
* [ProcedureEntry01 (Procedure)](Procedure-ProcedureEntry01.md)
