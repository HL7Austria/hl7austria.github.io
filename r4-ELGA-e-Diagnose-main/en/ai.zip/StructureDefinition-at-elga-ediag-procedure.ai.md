# AT ELGA e-Diagnose Procedure - ELGA e-Diagnose R4 (Draft) v0.1.0

## Resource Profile: AT ELGA e-Diagnose Procedure 

 
Das AT e-Diagnose Procedure-Profil leitet sich vom Procedure-Profil ab und passt dieses für die Anforderungen der e-Diagnose an. 

### Defintion

Eine Prozedur beschreibt eine durchgeführte medizinische Maßnahme, Intervention oder einen operativen Eingriff. Sie dokumentiert zusammenfassend das Stattfinden einer Maßnahme.

**Usages:**

* Refer to this Profile: [AT ELGA e-Diagnose List](StructureDefinition-at-elga-ediag-list.md)
* Examples for this Profile: [Procedure/ProcedureEntry01](Procedure-ProcedureEntry01.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/hl7.at.fhir.elga.ediag.r4|current/StructureDefinition/StructureDefinition-at-elga-ediag-procedure.json)

### Formal Views of Profile Content

 [Description Differentials, Snapshots, and other representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-at-elga-ediag-procedure.csv), [Excel](../StructureDefinition-at-elga-ediag-procedure.xlsx), [Schematron](../StructureDefinition-at-elga-ediag-procedure.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "at-elga-ediag-procedure",
  "url" : "https://fhir.hl7.at/elga/ediag/r4/StructureDefinition/at-elga-ediag-procedure",
  "version" : "0.1.0",
  "name" : "AtEdiagProcedure",
  "title" : "AT ELGA e-Diagnose Procedure",
  "status" : "active",
  "date" : "2026-09-30T14:46:14+00:00",
  "publisher" : "ELGA GmbH",
  "contact" : [{
    "name" : "ELGA GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "http://elga.gv.at"
    }]
  },
  {
    "name" : "ELGA GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://elga.gv.at",
      "use" : "work"
    }]
  }],
  "description" : "Das AT e-Diagnose Procedure-Profil leitet sich vom Procedure-Profil ab und passt dieses für die Anforderungen der e-Diagnose an.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Procedure",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Procedure",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Procedure",
      "path" : "Procedure",
      "short" : "AT e-Diagnose Procedure"
    },
    {
      "id" : "Procedure.extension",
      "path" : "Procedure.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "Procedure.extension:reported",
      "path" : "Procedure.extension",
      "sliceName" : "reported",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://fhir.hl7.at/elga/ediag/r4/StructureDefinition/at-elga-ediag-reported"]
      }]
    },
    {
      "id" : "Procedure.extension:entered-in-error",
      "path" : "Procedure.extension",
      "sliceName" : "entered-in-error",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://fhir.hl7.at/elga/ediag/r4/StructureDefinition/at-elga-ediag-ext-entered-in-error"]
      }]
    },
    {
      "id" : "Procedure.identifier",
      "path" : "Procedure.identifier",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "system"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "Procedure.identifier:businessIdentifier",
      "path" : "Procedure.identifier",
      "sliceName" : "businessIdentifier",
      "short" : "Identifier innerhalb der e-Diagnose für einen Eintrag.",
      "definition" : "Dieser Identifier wird von der Fachanwendung e-Diagnose vergeben, sollte dieser durch den Client nicht gesetzt werden. Ein Client kann diesen Identifier nutzen, um einzelne Einträge im Zuge einer Bearbeitung miteinander zu verknüpfen.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Procedure.identifier:businessIdentifier.system",
      "path" : "Procedure.identifier.system",
      "min" : 1,
      "patternUri" : "https://fhir.hl7.at/elga/ediag/r4/CodeSystem/at-ediag-codesystem-business-identifier"
    },
    {
      "id" : "Procedure.identifier:businessIdentifier.value",
      "path" : "Procedure.identifier.value",
      "min" : 1
    },
    {
      "id" : "Procedure.instantiatesCanonical",
      "path" : "Procedure.instantiatesCanonical",
      "short" : "Verweis auf eine standardisierte FHIR-Ressource, ein Template oder einen Leitfaden, der beschreibt, wie die Prozedur durchgeführt werden soll.",
      "max" : "0"
    },
    {
      "id" : "Procedure.instantiatesUri",
      "path" : "Procedure.instantiatesUri",
      "short" : "Verweis auf ein externes Dokument.",
      "max" : "0"
    },
    {
      "id" : "Procedure.basedOn",
      "path" : "Procedure.basedOn",
      "short" : "Verweis auf eine Anforderung.",
      "max" : "0"
    },
    {
      "id" : "Procedure.partOf",
      "path" : "Procedure.partOf",
      "short" : "Verweis der Ressource auf eine andere, übergeordnete Ressource.",
      "max" : "0"
    },
    {
      "id" : "Procedure.status",
      "path" : "Procedure.status",
      "short" : "Nur tatsächlich durchgeführte (completed) Prozeduren werden in der e-Diagnose dokumentiert.",
      "fixedCode" : "completed",
      "mustSupport" : true
    },
    {
      "id" : "Procedure.statusReason",
      "path" : "Procedure.statusReason",
      "short" : "Begründung für den Status der Prozedur nicht relevant.",
      "max" : "0"
    },
    {
      "id" : "Procedure.category",
      "path" : "Procedure.category",
      "short" : "Kategorisierung nach Verfahren.",
      "max" : "0"
    },
    {
      "id" : "Procedure.code",
      "path" : "Procedure.code",
      "short" : "Prozedurencode der durchgeführten Prozedur; Freitext ist nicht zulässig.",
      "min" : 1,
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.hl7.at/elga/ediag/r4/ValueSet/at-ediag-procedure-code"
      }
    },
    {
      "id" : "Procedure.code.text",
      "path" : "Procedure.code.text",
      "max" : "0"
    },
    {
      "id" : "Procedure.subject",
      "path" : "Procedure.subject",
      "short" : "Person, auf die sich die Prozedur bezieht.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.at/fhir/HL7ATCoreProfiles/4.0.1/StructureDefinition/at-core-patient"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Procedure.encounter",
      "path" : "Procedure.encounter",
      "short" : "Behandlungskontakt.",
      "max" : "0"
    },
    {
      "id" : "Procedure.performed[x]",
      "path" : "Procedure.performed[x]",
      "short" : "Zeitpunkt der Durchführung.",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "Procedure.recorder",
      "path" : "Procedure.recorder",
      "short" : "GDA, der die Prozedur eingetragen bzw. dokumentiert hat.",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.at/fhir/HL7ATCoreProfiles/4.0.1/StructureDefinition/at-core-practitioner",
        "http://hl7.at/fhir/HL7ATCoreProfiles/4.0.1/StructureDefinition/at-core-practitionerRole"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Procedure.asserter",
      "path" : "Procedure.asserter",
      "short" : "Quelle der Information zur Prozedur (z. B. behandelnde Person, Patient oder Dritter).",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.at/fhir/HL7ATCoreProfiles/4.0.1/StructureDefinition/at-core-practitioner",
        "http://hl7.at/fhir/HL7ATCoreProfiles/4.0.1/StructureDefinition/at-core-practitionerRole",
        "http://hl7.at/fhir/HL7ATCoreProfiles/4.0.1/StructureDefinition/at-core-patient",
        "http://hl7.org/fhir/StructureDefinition/RelatedPerson"]
      }]
    },
    {
      "id" : "Procedure.performer",
      "path" : "Procedure.performer",
      "short" : "Person, die die Prozedur durchgeführt hat.",
      "max" : "0"
    },
    {
      "id" : "Procedure.location",
      "path" : "Procedure.location",
      "short" : "Durchführungsort.",
      "max" : "0"
    },
    {
      "id" : "Procedure.reasonCode",
      "path" : "Procedure.reasonCode",
      "short" : "Code des medizinischen Grundes für die Durchführung der Prozedur.",
      "max" : "0"
    },
    {
      "id" : "Procedure.reasonReference",
      "path" : "Procedure.reasonReference",
      "short" : "Begründung für die Durchführung der Prozedur; Verweis auf eine andere Ressource wie z.B. Condition oder Observation.",
      "max" : "0"
    },
    {
      "id" : "Procedure.bodySite",
      "path" : "Procedure.bodySite",
      "short" : "Betroffene Körperstelle.",
      "max" : "0"
    },
    {
      "id" : "Procedure.outcome",
      "path" : "Procedure.outcome",
      "short" : "Ergebnis der Prozedur.",
      "max" : "0"
    },
    {
      "id" : "Procedure.report",
      "path" : "Procedure.report",
      "short" : "Verweis auf ELGA-Befunde als medizinische Evidenz."
    },
    {
      "id" : "Procedure.complication",
      "path" : "Procedure.complication",
      "short" : "Komplikation während dem Eingriff.",
      "max" : "0"
    },
    {
      "id" : "Procedure.complicationDetail",
      "path" : "Procedure.complicationDetail",
      "short" : "Diagnose, die durch die durchgeführte Prozedur entstanden ist.",
      "max" : "0"
    },
    {
      "id" : "Procedure.followUp",
      "path" : "Procedure.followUp",
      "short" : "Nachkontrolle (Code).",
      "max" : "0"
    },
    {
      "id" : "Procedure.note",
      "path" : "Procedure.note",
      "short" : "Freitext zur Prozedur als Zusatzinformation.",
      "max" : "1"
    },
    {
      "id" : "Procedure.note.author[x]",
      "path" : "Procedure.note.author[x]",
      "max" : "0"
    },
    {
      "id" : "Procedure.note.time",
      "path" : "Procedure.note.time",
      "max" : "0"
    },
    {
      "id" : "Procedure.focalDevice",
      "path" : "Procedure.focalDevice",
      "short" : "Gerät, das zur Durchführung der Prozedur verwendet wurde.",
      "max" : "0"
    },
    {
      "id" : "Procedure.usedReference",
      "path" : "Procedure.usedReference",
      "short" : "Verweis auf während der Prozedur verwendete Materialien, z. B. Medikamente.",
      "max" : "0"
    },
    {
      "id" : "Procedure.usedCode",
      "path" : "Procedure.usedCode",
      "short" : "Code der während der Prozedur verwendeten Materialien.",
      "max" : "0"
    }]
  }
}

```
