# HL7.AT.FHIR.ELGA.EDIAG.R4\Hintergrund - FHIR® v4.0.1

* [**Table of Contents**](toc.md)
* **Hintergrund**

## Hintergrund

Die strukturierte Dokumentation und der Austausch von Conditions, Procedures und AllergiesIntolerances sind eine wesentliche Grundlage für die medizinische Versorgung. Die eDiagnose soll diese Informationen übergreifend in ELGA verfügbar machen und damit eine gesamthafte Übersicht über den Gesundheitszustand sowie die weitere Behandlung unterstützen. Zudem soll sie die Grundlage für die Austrian Patient Summary (APS) schaffen.

### Fachliches Umfeld & Datenkategorien

Die IPS unterscheidet mehrere Datenkategorien. Diese werden im Rahmen der Konzeption der eDiagnose berücksichtigt, insbesondere im Hinblick auf die spätere Verwendung der Daten für die APS.

| | | |
| :--- | :--- | :--- |
| **Problem List** | Conditions | Diagnosen-Summary-Liste |
| **History of Past Problems** | Conditions | Diagnosen-Summary-Einträge |
| **History of Procedures** | Procedures | Prozeduren-Summary-Einträge |
| **Allergies and Intolerances** | AllergiesIntolerances | Allergie- und Intoleranzen-Summary-Einträge |

![](summary_listen_dokumentstruktur.png)

