# hl7.at.fhir.elga.ediag.r4#0.1.0: ELGA e-Diagnose R4 (Draft)

## Pages

* [HL7.AT.FHIR.ELGA.EDIAG.R4\Home - FHIR® v4.0.1](index.md)
* [HL7.AT.FHIR.ELGA.EDIAG.R4\Umfang und Inhalt - FHIR® v4.0.1](scope_and_content.md)
* [HL7.AT.FHIR.ELGA.EDIAG.R4\Patient Journey - FHIR® v4.0.1](patient_journey.md)
* [HL7.AT.FHIR.ELGA.EDIAG.R4\Akteure - FHIR® v4.0.1](actors.md)
* [HL7.AT.FHIR.ELGA.EDIAG.R4\Interaktionen mit fachlichen Einzelressourcen - FHIR® v4.0.1](uc_ediag_06_int_res.md)
* [HL7.AT.FHIR.ELGA.EDIAG.R4\Herausforderungen - FHIR® v4.0.1](challenges.md)
* [HL7.AT.FHIR.ELGA.EDIAG.R4\Workflowmanagement - FHIR® v4.0.1](workflowmanagement.md)
* [HL7.AT.FHIR.ELGA.EDIAG.R4\Hintergrund - FHIR® v4.0.1](background.md)
* [HL7.AT.FHIR.ELGA.EDIAG.R4\Interaktionen mit Listenressourcen - FHIR® v4.0.1](uc_ediag_06_int_list.md)
* [HL7.AT.FHIR.ELGA.EDIAG.R4\Technische Use Cases - FHIR® v4.0.1](technische_use_cases.md)
* [HL7.AT.FHIR.ELGA.EDIAG.R4\Artifacts Summary - FHIR® v4.0.1](artifacts.md)
* [HL7.AT.FHIR.ELGA.EDIAG.R4\Transaktionen - FHIR® v4.0.1](transaction.md)

## Resources

### CodeSystems

* [AT e-Diagnose Diagnose Typ](CodeSystem-at-ediag-codesystem-diagnose-type.md)
* [Reaktionszeit Codes](CodeSystem-at-ediag-codesystem-reaction-time-cs.md)

### ValueSets

* [AT e-Diagnose AllergyIntolerance Value Set](ValueSet-at-ediag-allergyintolerance-codes.md)
* [AT e-Diagnose Diagnosen Value Set](ValueSet-at-ediag-diagnosen-codes.md)
* [AT e-Diagnose Diagnosis Type Value Set](ValueSet-at-ediag-diagnosen-type.md)
* [ELGA AT e-Diagnose List Entry Code Value Set](ValueSet-at-ediag-list-code-vs.md)
* [AT e-Diagnose Procedure Status Value Set](ValueSet-at-ediag-procedure-status.md)
* [AT e-Diagnose Procedures Value Set](ValueSet-at-ediag-prozeduren-codes.md)
* [AT e-Diagnose Reaction Time Value Set](ValueSet-at-ediag-reaction-time-vs.md)

### Resource Profiles

* [AT ELGA e-Diagnose AllergyIntolerance](StructureDefinition-at-elga-ediag-allergyintolerance.md)
* [AT ELGA e-Diagnose Collection Bundle](StructureDefinition-at-elga-ediag-bundle-liste-cl.md)
* [AT ELGA e-Diagnose Transaction Bundle](StructureDefinition-at-elga-ediag-bundle-liste-tx.md)
* [AT ELGA e-Diagnose Condition](StructureDefinition-at-elga-ediag-condition.md)
* [AT ELGA e-Diagnose List](StructureDefinition-at-elga-ediag-list.md)
* [AT ELGA e-Diagnose Procedure](StructureDefinition-at-elga-ediag-procedure.md)

### Extensions

* [AT ELGA Reaktionszeit](StructureDefinition-at-elga-ediag-reaction-time.md)
* [AT ELGA Reported (Fremdangabe)](StructureDefinition-at-elga-ediag-reported.md)

### ImplementationGuides

* [ELGA e-Diagnose R4 (Draft)](index.md)

### OperationDefinitions

* [e-Diagnose Operation für List-Read](OperationDefinition-at-ediag-operation-listread.md)
* [e-Diagnose Operation für List-Write](OperationDefinition-at-ediag-operation-listwrite.md)

### Examples

* [AllergyExample (AllergyIntolerance)](AllergyIntolerance-AllergyExample.md)
* [At-Ediag-Journey-01-Bundle-Liste-Cl (Bundle)](Bundle-At-Ediag-Journey-01-Bundle-Liste-Cl.md)
* [At-Ediag-Journey-01-Bundle-Liste-Tx (Bundle)](Bundle-At-Ediag-Journey-01-Bundle-Liste-Tx.md)
* [DiagnoseCurrentlyRelevantExample (Condition)](Condition-DiagnoseCurrentlyRelevantExample.md)
* [DiagnoseNotCurrentlyRelevantExample (Condition)](Condition-DiagnoseNotCurrentlyRelevantExample.md)
* [DeviceExample (Device)](Device-DeviceExample.md)
* [ListExample01 (List)](List-ListExample01.md)
* [ListExample02 (List)](List-ListExample02.md)
* [PatientExample (Patient)](Patient-PatientExample.md)
* [PractitionerExample (Practitioner)](Practitioner-PractitionerExample.md)
* [ProcedureExample (Procedure)](Procedure-ProcedureExample.md)
