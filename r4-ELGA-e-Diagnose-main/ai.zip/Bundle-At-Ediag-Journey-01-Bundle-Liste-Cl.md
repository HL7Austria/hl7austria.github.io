# HL7.AT.FHIR.ELGA.EDIAG.R4\Beispiel Journey 01 Collection Bundle - FHIR® v4.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Beispiel Journey 01 Collection Bundle**

## Example Bundle: Beispiel Journey 01 Collection Bundle



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "At-Ediag-Journey-01-Bundle-Liste-Cl",
  "meta" : {
    "profile" : ["https://fhir.hl7.at/elga/ediag/r4/StructureDefinition/at-elga-ediag-bundle-liste-cl"]
  },
  "type" : "collection",
  "timestamp" : "2026-03-01T08:00:00+00:00",
  "entry" : [{
    "fullUrl" : "urn:uuid:3b2f7c16-1c47-4c08-a4ef-9b4d8c7c5f11",
    "resource" : {
      "resourceType" : "List",
      "id" : "ListExample01",
      "meta" : {
        "profile" : ["https://fhir.hl7.at/elga/ediag/r4/StructureDefinition/at-elga-ediag-list"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"List_ListExample01\"> </a><p class=\"res-header-id\"><b>Generated Narrative: List ListExample01</b></p><a name=\"ListExample01\"> </a><a name=\"hcListExample01\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-at-elga-ediag-list.html\">AT ELGA e-Diagnose List</a></p></div><table class=\"clstu\"><tr><td>Date: 2026-03-01 08:00:00+0000 </td><td>Mode: Working List </td><td>Status: Current </td><td>Code: Problem list - Reported </td></tr><tr><td>Subject: <a href=\"Patient-PatientExample.html\">Max Mustermann  Male, DoB: 1900-01-01 ( Social Security number: 1234010100)</a>Source: </td></tr></table><table class=\"grid\"><tr style=\"backgound-color: #eeeeee\"><td><b>Items</b></td></tr></table></div>"
      },
      "identifier" : [{
        "value" : "123"
      }],
      "status" : "current",
      "mode" : "working",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11450-4"
        }]
      },
      "subject" : {
        "reference" : "Patient/PatientExample"
      },
      "date" : "2026-03-01T08:00:00+00:00",
      "source" : {
        "reference" : "Practitioner/PractitionerExample"
      },
      "emptyReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
          "code" : "notstarted"
        }]
      }
    }
  }]
}

```
