# HL7.AT.FHIR.ELGA.EDIAG.R4\Beispiel Journey 01 Transaction Bundle - FHIR® v4.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Beispiel Journey 01 Transaction Bundle**

## Example Bundle: Beispiel Journey 01 Transaction Bundle



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "At-Ediag-Journey-01-Bundle-Liste-Tx",
  "meta" : {
    "profile" : ["https://fhir.hl7.at/elga/ediag/r4/StructureDefinition/at-elga-ediag-bundle-liste-tx"]
  },
  "type" : "transaction",
  "timestamp" : "2026-03-01T08:10:00+00:00",
  "entry" : [{
    "fullUrl" : "urn:uuid:3b2f7c16-1c47-4c08-a4ef-9b4d8c7c5f12",
    "resource" : {
      "resourceType" : "List",
      "id" : "ListExample02",
      "meta" : {
        "profile" : ["https://fhir.hl7.at/elga/ediag/r4/StructureDefinition/at-elga-ediag-list"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"List_ListExample02\"> </a><p class=\"res-header-id\"><b>Generated Narrative: List ListExample02</b></p><a name=\"ListExample02\"> </a><a name=\"hcListExample02\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-at-elga-ediag-list.html\">AT ELGA e-Diagnose List</a></p></div><table class=\"clstu\"><tr><td>Date: 2026-03-01 00:00:00+0000 </td><td>Mode: Working List </td><td>Status: Current </td><td>Code: Problem list - Reported </td></tr><tr><td>Subject: <a href=\"Patient-PatientExample.html\">Max Mustermann  Male, DoB: 1900-01-01 ( Social Security number: 1234010100)</a>Source: </td></tr></table><table class=\"grid\"><tr style=\"backgound-color: #eeeeee\"><td><b>Items</b></td><td>Flag</td></tr><tr><td><a href=\"Condition-DiagnoseCurrentlyRelevantExample.html\">Condition Hypothyroidism</a></td><td>Neuer Planeintrag</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:list-02"
      }],
      "status" : "current",
      "mode" : "working",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11450-4"
        }]
      },
      "subject" : {
        "reference" : "Patient/PatientExample"
      },
      "date" : "2026-03-01T00:00:00+00:00",
      "source" : {
        "reference" : "Practitioner/PractitionerExample"
      },
      "entry" : [{
        "flag" : {
          "coding" : [{
            "system" : "https://fhir.hl7.at/elga/core/r4/CodeSystem/ElgaListEntryFlagCS",
            "code" : "new"
          }]
        },
        "item" : {
          "reference" : "Condition/DiagnoseCurrentlyRelevantExample"
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "List"
    }
  },
  {
    "fullUrl" : "urn:uuid:9c1f1d2a-aaaa-bbbb-cccc-123456789abc",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "DiagnoseCurrentlyRelevantExample",
      "meta" : {
        "profile" : ["https://fhir.hl7.at/elga/ediag/r4/StructureDefinition/at-elga-ediag-condition"],
        "tag" : [{
          "system" : "https://fhir.hl7.at/elga/ediag/r4/CodeSystem/at-ediag-codesystem-diagnose-type",
          "code" : "relevant",
          "display" : "currently relevant"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_DiagnoseCurrentlyRelevantExample\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition DiagnoseCurrentlyRelevantExample</b></p><a name=\"DiagnoseCurrentlyRelevantExample\"> </a><a name=\"hcDiagnoseCurrentlyRelevantExample\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-at-elga-ediag-condition.html\">AT ELGA e-Diagnose Condition</a></p><p style=\"margin-bottom: 0px\">Tag: <a href=\"CodeSystem-at-ediag-codesystem-diagnose-type.html\">currently relevant (Details: AT e-Diagnose Diagnose Typ code relevant = 'currently relevant')</a></p></div><p><b>AT ELGA Reported (Fremdangabe)</b>: false</p><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 40930008}\">Hypothyroidism</span></p><p><b>subject</b>: <a href=\"Patient-PatientExample.html\">Max Mustermann  Male, DoB: 1900-01-01 ( Social Security number: 1234010100)</a></p><p><b>onset</b>: 2024-06-01</p><p><b>recordedDate</b>: 2026-03-01 00:00:00+0000</p><p><b>recorder</b>: <a href=\"Practitioner-PractitionerExample.html\">Practitioner Melanie Musterärztin </a></p><p><b>asserter</b>: <a href=\"Practitioner-PractitionerExample.html\">Practitioner Melanie Musterärztin </a></p><p><b>note</b>: </p><blockquote><div><p>Patient berichtet über bekannte Schilddrüsenerkrankung seit 2024, aktuell gut eingestellt.</p>\n</div></blockquote></div>"
      },
      "extension" : [{
        "url" : "https://fhir.hl7.at/elga/ediag/r4/StructureDefinition/at-elga-ediag-reported",
        "valueBoolean" : false
      }],
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "40930008",
          "display" : "Hypothyroidism"
        }]
      },
      "subject" : {
        "reference" : "Patient/PatientExample"
      },
      "onsetDateTime" : "2024-06-01",
      "recordedDate" : "2026-03-01T00:00:00+00:00",
      "recorder" : {
        "reference" : "Practitioner/PractitionerExample"
      },
      "asserter" : {
        "reference" : "Practitioner/PractitionerExample"
      },
      "note" : [{
        "text" : "Patient berichtet über bekannte Schilddrüsenerkrankung seit 2024, aktuell gut eingestellt."
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Condition"
    }
  }]
}

```
