# HL7.AT.FHIR.ELGA.EDIAG.R4\Artifacts Summary - FHIR® v4.0.1

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

## Artifacts Summary

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Behavior: Operation Definitions 

These are custom operations that can be supported by and/or invoked by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [e-Diagnose Operation $delete](OperationDefinition-at-ediag-operation-diagnose-delete.md) | Die `$delete`-Operation löscht eine bestimmte Diagnose aus der e-Diagnose Fachanwendung. |
| [e-Diagnose Operation $delete-history-version](OperationDefinition-at-ediag-operation-list-delete-history-version.md) | Die `$delete-history-version`-Operation löscht eine bestimmte Version einer Summary-Liste aus der e-Diagnose Fachanwendung. |
| [e-Diagnose Operation $entered-in-error](OperationDefinition-at-ediag-operation-diagnose-entered-in-error.md) | Die `$entered-in-error`-Operation storniert eine bestimmte Diagnose in der e-Diagnose Fachanwendung. |
| [e-Diagnose Operation $write](OperationDefinition-at-ediag-operation-list-write.md) | Die `$write`-Operation wird aufgerufen, wenn eine Summary-Liste geschrieben wird. |

### Structures: Resource Profiles 

These define constraints on FHIR resources for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [AT ELGA e-Diagnose AllergyIntolerance](StructureDefinition-at-elga-ediag-allergyintolerance.md) | Das AT e-Diagnose AllergyIntolerance-Profil leitet sich vom AllergyIntolerance-Profil ab und passt dieses für die Anforderungen der e-Diagnose an. |
| [AT ELGA e-Diagnose Condition](StructureDefinition-at-elga-ediag-condition.md) | Das AT e-Diagnose Condition-Profil leitet sich vom Condition-Profil ab und passt dieses für die Anforderungen der e-Diagnose an. |
| [AT ELGA e-Diagnose List](StructureDefinition-at-elga-ediag-list.md) | Das AT e-Diagnose List-Profil dient der strukturierten Listung von Einträgen. |
| [AT ELGA e-Diagnose Procedure](StructureDefinition-at-elga-ediag-procedure.md) | Das AT e-Diagnose Procedure-Profil leitet sich vom Procedure-Profil ab und passt dieses für die Anforderungen der e-Diagnose an. |

### Structures: Extension Definitions 

These define constraints on FHIR data types for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [AT ELGA Entered In Error](StructureDefinition-at-elga-ediag-ext-entered-in-error.md) | Kennzeichnet, ob eine Information fehlerhaft eingegeben wurde. |
| [AT ELGA Reaktionszeit](StructureDefinition-at-elga-ediag-reaction-time.md) | Zeitlicher Verlauf der Manifestation (<6h, 6-24h, >24h, unknown) |
| [AT ELGA Reported (Fremdangabe)](StructureDefinition-at-elga-ediag-reported.md) | Kennzeichnet, ob eine Information fremdberichtet ist (z. B. vom Patienten oder Dritten). |

### Terminology: Value Sets 

These define sets of codes used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [AT e-Diagnose AllergyIntolerance Value Set](ValueSet-at-ediag-allergyintolerance-codes.md) | ValueSet mit Codes für Substanzen und Stoffe, die als Auslöser von Allergien oder Intoleranzen erfasst werden. |
| [AT e-Diagnose Diagnosen Value Set](ValueSet-at-ediag-diagnosen-codes.md) | Value-Set für die Codierung von Diagnosen. |
| [AT e-Diagnose Procedure Code](ValueSet-at-ediag-procedure-code.md) | Dieses Value-Set bildet die Prozeduren ab, die in der e-Diagnose dokumentiert werden können. |
| [AT e-Diagnose Reaction Time Value Set](ValueSet-at-ediag-reaction-time-vs.md) | ValueSet mit zulässigen Ausprägungen der Reaktionszeit einer allergischen Reaktion. |
| [ELGA AT e-Diagnose List Entry Code Value Set](ValueSet-at-ediag-list-code-vs.md) | ValueSet mit zulässigen Codes für das Flag eines List-Entries in ELGA. |
| [ELGA List Empty Reason Value Set](ValueSet-at-ediag-list-emptyreason-vs.md) | ValueSet für zulässige Ausprägungen des Elements emptyReason einer Liste. |

### Terminology: Code Systems 

These define new code systems used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Reaktionszeit Codes](CodeSystem-at-ediag-codesystem-reaction-time-cs.md) | Zeitlicher Verlauf der Manifestation |

### Example: Example Instances 

These are example instances that show what data produced and consumed by systems conforming with this implementation guide might look like.

| | |
| :--- | :--- |
| [Allergie Summary-Liste mit einem Summary-Eintrag](List-AllergyList01.md) | Beispiel einer Summary-Liste mit einem Eintrag, der auf eine Allergie verweist. |
| [Allergy-Summary-Liste (notstarted)](List-AllergyListEmpty.md) | Initiale Summary-Liste ohne Summary-Einträge (Allergy). |
| [Beispiel Device](Device-DeviceExample.md) | Beispielinstanz eines Devices dass die Fachanwendung initial erstellt |
| [Beispiel Patient](Patient-PatientExample.md) | Beispielinstanz eines Patienten |
| [Beispiel Practitioner](Practitioner-PractitionerExample.md) | Beispielinstanz eines Arztes |
| [Beispielinstanz einer Allergie für die Summary-Liste](AllergyIntolerance-AllergyEntry01.md) | Beispiel einer bestätigten Allergie |
| [Beispielinstanz einer Diagnose für die Gesamtliste](Condition-ConditionEntry02.md) | Beispiel Diagnose, aktuelle Beschwerden des Patienten |
| [Beispielinstanz einer Diagnose für die Gesamtliste](Condition-ConditionEntry04.md) | Beispiel Diagnose, aktuelle Beschwerden des Patienten |
| [Beispielinstanz einer Diagnose für die Gesamtliste](Condition-ConditionEntry05.md) | Beispiel Diagnose, aktuelle Beschwerden des Patienten |
| [Beispielinstanz einer Diagnose für die Summary](Condition-ConditionEntry03.md) | Beispiel Diagnose, aktuelle Beschwerden des Patienten |
| [Beispielinstanz einer Diagnose für die Summary-Liste](Condition-ConditionEntry01.md) | Beispiel einer dauerhaften Diagnose |
| [Beispielinstanz einer Prozedur für die Summary-Liste](Procedure-ProcedureEntry01.md) | Beispiel einer Prozedur |
| [Beispielinstanz einer stornierten Diagnose](Condition-ConditionEnteredInError.md) | Beispiel einer Diagnose nach Durchführung der $entered-in-error-Operation durch einen GDA |
| [Condition Summary-Liste (Erster Arztbesuch)](List-ConditionList01.md) | Beispiel der Condition-Summary-Liste nach dem ersten Arztbesuch. |
| [Condition Summary-Liste (Zweiter Arztbesuch - fehlerhafter Eintrag)](List-ConditionList02.md) | Beispiel einer Summary-Liste während des zweiten Arztbesuchs. Eine neue Diagnose wurde erfasst.Zusätzlich ist ein Eintrag enthalten, der irrtümlich erfasst wurde. |
| [Condition Summary-Liste (Zweiter Arztbesuch - korrigiert)](List-ConditionList03.md) | Beispiel einer Summary-Liste nachdem ein Eintrag storniert wurde. |
| [Condition-Summary-Liste (notstarted)](List-ConditionListEmpty.md) | Initiale Summary-Liste ohne Summary-Einträge (Condition). |
| [Procedure Summary-Liste mit einem Summary-Eintrag](List-ProcedureList01.md) | Beispiel einer Summary-Liste mit einem Eintrag, der auf eine Prozedur verweist. |
| [Procedure-Summary-Liste (notstarted)](List-ProcedureListEmpty.md) | Initiale Summary-Liste ohne Summary-Einträge (Procedure). |
| [SearchSet-Bundle der Diagnosen eines Patienten](Bundle-ConditionSearchSet01.md) | Beispiel eines SearchSet-Bundles mit mehreren Condition-Ressourcen eines Patienten |
| [SearchSet-Bundle der Diagnosen eines Patienten](Bundle-ConditionSearchSet02.md) | Beispiel eines SearchSet-Bundles mit mehreren Condition-Ressourcen eines Patienten |
| [SearchSet-Bundle der Diagnosen eines Patienten](Bundle-ConditionSearchSet03.md) | Beispiel eines SearchSet-Bundles mit mehreren Condition-Ressourcen eines Patienten |

