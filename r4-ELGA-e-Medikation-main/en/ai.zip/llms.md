# hl7.at.fhir.elga.emed.r4#0.1.0: ELGA e-Medikation (R4) DRAFT(en)

## Pages

* [Home](index.md)
* [​Technische Use Cases für Geplante Abgabe schreiben (UC_eMed_04)](Sub_UC_eMed_04.md)
* [Herausforderungen](challenges.md)
* [Patient Journey](patient_journey.md)
* [​Technische Use Cases für Durchgeführte Abgabe schreiben (UC_eMed_05)](Sub_UC_eMed_05.md)
* [​Technische Use Cases für Medikationsplan schreiben (UC_eMed_02)](Sub_UC_eMed_02.md)
* [Transaktionen](interactions.md)
* [Use Cases Übersicht (fachlich und technisch)](overview_sub_use_case.md)
* [Artifacts Summary](artifacts.md)
* [Dosierungen](dosages.md)
* [​Technische Use Cases für Medikationsplan lesen (UC_eMed_01)](Sub_UC_eMed_01.md)
* [Akteure](actors.md)
* [Workflowmanagement](workflowmanagement.md)
* [Hintergrund](background.md)
* [Designentscheidungen](design_choices.md)
* [Umfang und Inhalt](scope_and_content.md)
* [​Technische Use Cases für Geplante und Durchgeführte Abgaben lesen (UC_eMed_03)](Sub_UC_eMed_03.md)
* [Medikation](medication.md)
* [Overview Use Case](overview_use_case.md)

## Resources

### CodeSystems

* [ELGA Dosage Category Status CodeSystem](CodeSystem-AtElgaEmedCodeSystemDosageCategory.md)
* [ELGA e-Med MedicationRequest Planeintrag StatusReason CodeSystem](CodeSystem-AtElgaEmedCodeSystemPlaneintragStatusReasonCS.md)
* [ELGA List.entry.flag CodeSystem](CodeSystem-ElgaListEntryFlagCS.md)
* [ELGA e-Med MedicationRequest Kategorie CodeSystem](CodeSystem-MedicationRequestCategoryCS.md)
* [MedikationRezeptart](CodeSystem-medikationrezeptart.md)

### ValueSets

* [ELGA Dosage Category Status ValueSet](ValueSet-AtElgaEmedValueSetATC.md)
* [ELGA Dosage Category Status ValueSet](ValueSet-AtElgaEmedValueSetDosageCategory.md)
* [ELGA e-Med Medikationsplaneintrag StatusReason Value Set](ValueSet-AtElgaEmedValueSetPlaneintragStatusReasonVS.md)
* [ELGA e-Med Durchgeführte Abgabe Status Value Set](ValueSet-DurchgefuehrteAbgabeStatusVS.md)
* [ELGA e-Med Durchgeführte Abgabe Typ Value Set](ValueSet-DurchgefuehrteAbgabeTypVS.md)
* [ELGA List Empty Reason Value Set](ValueSet-ElgaListEmptyReasonVS.md)
* [ELGA List.entry.flag Value Set](ValueSet-ElgaListEntryFlagVS.md)
* [ELGA List Status ValueSet](ValueSet-ElgaListStatusVS.md)
* [ELGA Dosierung Timing When ValueSet für Tageszeitenschema](ValueSet-ElgaTimingWhenStandardAdministrationVS.md)
* [ELGA e-Med Geplante Abgabe Status ValueSet](ValueSet-GeplanteAbgabeStatusVS.md)
* [ELGA e-Med MedicationRequest Kategorie ValueSet](ValueSet-MedicationRequestCategoryVS.md)
* [ELGA e-Med Medikationsplaneintrag Status Value Set](ValueSet-PlaneintragStatusVS.md)
* [ELGA_MedikationRezeptart](ValueSet-elga-medikationrezeptart.md)

### Complex-type Profiles

* [AT ELGA e-Medikation Dosage Dosierung](StructureDefinition-at-elga-emed-dosage-dosierung.md)
* [AtElgaEmedDosageFreeTextAdministration](StructureDefinition-at-elga-emed-dosage-freetext-administration.md)
* [AtElgaEmedDosageFrequencyAdministration](StructureDefinition-at-elga-emed-dosage-frequency-administration.md)
* [AtElgaEmedDosageOtherAdministration](StructureDefinition-at-elga-emed-dosage-other-administration.md)
* [AtElgaEmedDosageStandardAdministration](StructureDefinition-at-elga-emed-dosage-standard-administration.md)
* [AtElgaEmedDosageTimedAdministration](StructureDefinition-at-elga-emed-dosage-timed-administration.md)
* [AT ELGA e-Medikation Timing](StructureDefinition-at-elga-emed-timing.md)

### Resource Profiles

* [AT ELGA e-Medikation Transaction Bundle durchgeführte Abgaben](StructureDefinition-at-elga-emed-bundle-durchgefuehrteabgaben-tx.md)
* [AT ELGA e-Medikation Transaction Bundle geplante Abgaben](StructureDefinition-at-elga-emed-bundle-geplanteabgaben-tx.md)
* [AT ELGA e-Medikation Medikationsplan-Bundle Medikationsplan](StructureDefinition-at-elga-emed-bundle-medikationsplan.md)
* [AT ELGA e-Medikation Transaction Bundle Medikationsplan](StructureDefinition-at-elga-emed-bundle-medikationsplantx.md)
* [At ELGA e-Medikation Device Fachanwendung](StructureDefinition-at-elga-emed-device-fachanwendung.md)
* [AT ELGA e-Medikation List Medikationsplan](StructureDefinition-at-elga-emed-list-medikationsplan.md)
* [AT ELGA e-Medikation Medication Magistrale Medikation](StructureDefinition-at-elga-emed-medication-magistrale-zubereitung.md)
* [AT ELGA e-Medikation Medication Medikation](StructureDefinition-at-elga-emed-medication-standard-medikation.md)
* [AT ELGA e-Medikation MedicationDispense Durchgeführte Abgabe](StructureDefinition-at-elga-emed-medicationdispense-durchgefuehrteabgabe.md)
* [At ELGA e-Medikation MedicationRequest Base](StructureDefinition-at-elga-emed-medicationrequest-base.md)
* [At ELGA e-Medikation MedicationRequest Geplante Abgabe](StructureDefinition-at-elga-emed-medicationrequest-geplanteabgabe.md)
* [At ELGA e-Medikation MedicationRequest Planeintrag](StructureDefinition-at-elga-emed-medicationrequest-planeintrag.md)
* [At ELGA e-Medikation Substance Wirkstoff](StructureDefinition-at-elga-emed-substance-wirkstoff.md)

### Extensions

* [AT ELGA e-Medikation Extension Dosierungskategorie](StructureDefinition-at-elga-emed-extension-dosage-category.md)
* [AT ELGA e-Medikation Extension Group Identifier](StructureDefinition-at-elga-emed-extension-group-identifier.md)
* [AT ELGA e-Medikation Extension Patient Modified](StructureDefinition-at-elga-emed-extension-patient-modified.md)

### ImplementationGuides

* [ELGA e-Medikation (R4) DRAFT](ImplementationGuide-hl7.at.fhir.elga.emed.r4.md)

### OperationDefinitions

* [e-Med Operation für Plan-Read](OperationDefinition-AtElgaEmed.List.PlanRead.md)
* [e-Med Operation für Plan-Write](OperationDefinition-AtElgaEmed.List.PlanWrite.md)
* [eMed Operation für GroupIdentifier-Create](OperationDefinition-at-emed-operation-groupidentifier-create.md)
* [eMed Operation für GroupIdentifier Prescription Search](OperationDefinition-at-emed-operation-groupidentifier-prescription-search.md)

### SearchParameters

* [Medication Code](SearchParameter-at-elga-emed-searchparameter-list-mr-medication-code.md)

### Examples

* [At-Emed-Journey-01-01-01-Bundle-Medikationsplan (Bundle)](Bundle-At-Emed-Journey-01-01-01-Bundle-Medikationsplan.md)
* [At-Emed-Journey-01-02-Bundle-Medikationsplan-Tx (Bundle)](Bundle-At-Emed-Journey-01-02-Bundle-Medikationsplan-Tx.md)
* [At-Emed-Journey-01-02-Bundle-plan-read-response (Bundle)](Bundle-At-Emed-Journey-01-02-Bundle-plan-read-response.md)
* [At-Emed-Journey-01-02-Bundle-plan-write-response (Bundle)](Bundle-At-Emed-Journey-01-02-Bundle-plan-write-response.md)
* [At-Emed-Journey-01-03-Bundle-Geplante-Abgaben-Tx (Bundle)](Bundle-At-Emed-Journey-01-03-Bundle-Geplante-Abgaben-Tx.md)
* [At-Emed-Journey-02-01-Bundle-Durchgefuehrte-Abgaben-Tx (Bundle)](Bundle-At-Emed-Journey-02-01-Bundle-Durchgefuehrte-Abgaben-Tx.md)
* [At-Emed-Journey-03-01-Bundle-Durchgefuehrte-Abgaben-Tx (Bundle)](Bundle-At-Emed-Journey-03-01-Bundle-Durchgefuehrte-Abgaben-Tx.md)
* [At-Emed-Journey-05-01-Bundle-Medikationsplan-Tx (Bundle)](Bundle-At-Emed-Journey-05-01-Bundle-Medikationsplan-Tx.md)
* [At-Emed-Journey-06-02-Bundle-Medikationsplan-Tx (Bundle)](Bundle-At-Emed-Journey-06-02-Bundle-Medikationsplan-Tx.md)
* [At-Emed-Journey-07-02-Bundle-Medikationsplan-Tx (Bundle)](Bundle-At-Emed-Journey-07-02-Bundle-Medikationsplan-Tx.md)
* [At-Emed-Journey-07-03-Bundle-Geplante-Abgaben-Tx (Bundle)](Bundle-At-Emed-Journey-07-03-Bundle-Geplante-Abgaben-Tx.md)
* [at-emed-journey-01-01-02-bundle-geplanteAbgaben (Bundle)](Bundle-at-emed-journey-01-01-02-bundle-geplanteAbgaben.md)
* [at-emed-journey-01-01-03-bundle-durchgefuehrte-abgaben (Bundle)](Bundle-at-emed-journey-01-01-03-bundle-durchgefuehrte-abgaben.md)
* [At-Emed-Example-Device-01 (Device)](Device-At-Emed-Example-Device-01.md)
* [At-Emed-Journey-05-01-List-Medikationsplan (List)](List-At-Emed-Journey-05-01-List-Medikationsplan.md)
* [At-Emed-Journey-06-02-List-Medikationsplan (List)](List-At-Emed-Journey-06-02-List-Medikationsplan.md)
* [At-Emed-Journey-07-02-List-Medikationsplan (List)](List-At-Emed-Journey-07-02-List-Medikationsplan.md)
* [At-Emed-Example-Medication-Magistral-01 (Medication)](Medication-At-Emed-Example-Medication-Magistral-01.md)
* [at-emed-journey-medication-ramipril (Medication)](Medication-at-emed-journey-medication-ramipril.md)
* [At-Emed-Journey-02-01-Md-Durchgefuehrte-Abgabe-01 (MedicationDispense)](MedicationDispense-At-Emed-Journey-02-01-Md-Durchgefuehrte-Abgabe-01.md)
* [At-Emed-Journey-02-01-Md-Durchgefuehrte-Abgabe-02 (MedicationDispense)](MedicationDispense-At-Emed-Journey-02-01-Md-Durchgefuehrte-Abgabe-02.md)
* [At-Emed-Journey-03-01-Md-Durchgefuehrte-Abgabe-02 (MedicationDispense)](MedicationDispense-At-Emed-Journey-03-01-Md-Durchgefuehrte-Abgabe-02.md)
* [At-Emed-Example-Mr-Dosierung-Timed (MedicationRequest)](MedicationRequest-At-Emed-Example-Mr-Dosierung-Timed.md)
* [At-Emed-Journey-01-03-Mr-Geplante-Abgabe-01 (MedicationRequest)](MedicationRequest-At-Emed-Journey-01-03-Mr-Geplante-Abgabe-01.md)
* [At-Emed-Journey-01-03-Mr-Geplante-Abgabe-02 (MedicationRequest)](MedicationRequest-At-Emed-Journey-01-03-Mr-Geplante-Abgabe-02.md)
* [At-Emed-Journey-05-01-Mr-Planeintrag-01 (MedicationRequest)](MedicationRequest-At-Emed-Journey-05-01-Mr-Planeintrag-01.md)
* [At-Emed-Journey-06-02-Mr-Planeintrag-01 (MedicationRequest)](MedicationRequest-At-Emed-Journey-06-02-Mr-Planeintrag-01.md)
* [At-Emed-Journey-06-02-Mr-Planeintrag-03 (MedicationRequest)](MedicationRequest-At-Emed-Journey-06-02-Mr-Planeintrag-03.md)
* [At-Emed-Journey-07-02-Mr-Planeintrag-02 (MedicationRequest)](MedicationRequest-At-Emed-Journey-07-02-Mr-Planeintrag-02.md)
* [At-Emed-Journey-07-02-Mr-Planeintrag-03 (MedicationRequest)](MedicationRequest-At-Emed-Journey-07-02-Mr-Planeintrag-03.md)
* [At-Emed-Journey-07-03-Mr-Geplante-Abgabe-03 (MedicationRequest)](MedicationRequest-At-Emed-Journey-07-03-Mr-Geplante-Abgabe-03.md)
* [AtEmedExampleDosageStandardAdministration1 (MedicationRequest)](MedicationRequest-AtEmedExampleDosageStandardAdministration1.md)
* [AtEmedExampleDosageStandardAdministration2 (MedicationRequest)](MedicationRequest-AtEmedExampleDosageStandardAdministration2.md)
* [AtEmedExampleDosageStandardAdministration3 (MedicationRequest)](MedicationRequest-AtEmedExampleDosageStandardAdministration3.md)
* [At-Emed-Example-Organization-01 (Organization)](Organization-At-Emed-Example-Organization-01.md)
* [Amadeus Apotheke (Organization)](Organization-At-Emed-Example-Organization-02.md)
* [Amadeus Apotheke (Organization)](Organization-At-Emed-Example-Organization-03.md)
* [At-Emed-Example-Organization-04 (Organization)](Organization-At-Emed-Example-Organization-04.md)
* [Journey-01-01-Request-Body-01 (Parameters)](Parameters-Journey-01-01-Request-Body-01.md)
* [At-Emed-Example-Patient-01 (Patient)](Patient-At-Emed-Example-Patient-01.md)
* [At-Emed-Example-Practitioner-01 (Practitioner)](Practitioner-At-Emed-Example-Practitioner-01.md)
* [At-Emed-Example-Practitioner-02 (Practitioner)](Practitioner-At-Emed-Example-Practitioner-02.md)
* [At-Emed-Example-Practitioner-03 (Practitioner)](Practitioner-At-Emed-Example-Practitioner-03.md)
* [At-Emed-Example-Practitioner-04 (Practitioner)](Practitioner-At-Emed-Example-Practitioner-04.md)
* [At-Emed-Example-PractitionerRole-01 (PractitionerRole)](PractitionerRole-At-Emed-Example-PractitionerRole-01.md)
* [At-Emed-Example-PractitionerRole-02 (PractitionerRole)](PractitionerRole-At-Emed-Example-PractitionerRole-02.md)
* [At-Emed-Example-PractitionerRole-03 (PractitionerRole)](PractitionerRole-At-Emed-Example-PractitionerRole-03.md)
* [At-Emed-Example-PractitionerRole-04 (PractitionerRole)](PractitionerRole-At-Emed-Example-PractitionerRole-04.md)
* [At-Emed-Example-Substance-Clotrimazol (Substance)](Substance-At-Emed-Example-Substance-Clotrimazol.md)
* [At-Emed-Example-Substance-Hydrocortison (Substance)](Substance-At-Emed-Example-Substance-Hydrocortison.md)
