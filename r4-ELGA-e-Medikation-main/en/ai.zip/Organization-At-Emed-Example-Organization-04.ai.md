# Beispiel Organisation Urlaubsvertretung - ELGA e-Medikation (R4) DRAFT v0.1.0

## Example Organization: Beispiel Organisation Urlaubsvertretung

Profile: [HL7® AT Core Organization Profile](http://hl7.at/fhir/HL7ATCoreProfiles/4.0.1/2.0.0/StructureDefinition-at-core-organization.html)

Unnamed Organization

-------

| | |
| :--- | :--- |
| Contact Detail | * [office@musterpraxis.at](mailto:office@musterpraxis.at)
* [+436500987654321](tel:+436500987654321)
* Urlaubsvertreter-Straße 8 Stiege 2 St. Wolfgang Salzburg 5350 AUT (work)
 |



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "At-Emed-Example-Organization-04",
  "meta" : {
    "profile" : ["http://hl7.at/fhir/HL7ATCoreProfiles/4.0.1/StructureDefinition/at-core-organization"]
  },
  "telecom" : [{
    "system" : "email",
    "value" : "office@musterpraxis.at",
    "use" : "work"
  },
  {
    "system" : "phone",
    "value" : "+436500987654321",
    "use" : "work"
  }],
  "address" : [{
    "use" : "work",
    "type" : "both",
    "line" : ["Urlaubsvertreter-Straße 8 Stiege 2"],
    "_line" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
        "valueString" : "Urlaubsvertreter-Straße"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
        "valueString" : "8"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-additionalLocator",
        "valueString" : "Stiege 2"
      },
      {
        "url" : "http://hl7.at/fhir/HL7ATCoreProfiles/4.0.1/StructureDefinition/at-core-ext-address-additionalInformation",
        "valueString" : "Barrierefreier Zugang"
      }]
    }],
    "city" : "St. Wolfgang",
    "state" : "Salzburg",
    "postalCode" : "5350",
    "country" : "AUT"
  }]
}

```
