# ​Technische Use Cases für Geplante Abgabe schreiben (UC_eMed_04) - ELGA e-Medikation (R4) DRAFT v0.1.0

## ​Technische Use Cases für Geplante Abgabe schreiben (UC_eMed_04)

Dieser technische Use Case beschreibt den schreibenden Zugriff [berechtigter Akteure](actors.md#rollen-und-berechtigungen) auf [Geplanten Abgaben](StructureDefinition-at-elga-emed-medicationrequest-geplanteabgabe.md) eines ELGA-Teilnehmers.

Für ELGA-Teilnehmer (bzw. deren Vertretungen) erfolgt der schreibende Zugriff im Rahmen der Ausübung von Teilnehmerrechten ausschließlich über das ELGA-Zugangsportal. Für GDA erfolgt der schreibende Zugriff über die e-Medikation-Schnittstelle des jeweiligen GDA-Systems.

Der schreibende Zugriff umfasst folgende Bearbeitungen:

* **GDA** können **Geplante Abgaben**: 
* [erstellen](Sub_UC_eMed_04.md#sub_uc_emed_04_01---geplante-abgabe-erstellen-prescription-write) und
* [stornieren](Sub_UC_eMed_04.md#sub_uc_emed_08_04---geplante-abgabe-stornieren-prescription-discard)
 
* **ELGA-Teilnehmer** und deren Vertretungen können **Geplante Abgaben**: 
* [löschen](Sub_UC_eMed_04.md#sub_uc_emed_08_05---geplante-abgabe-löschen-durch-elga-teilnehmer-prescription-delete)
 
* **Automatisch** durch die **Fachanwendung** umgesetzt werden: 
* [Beenden](Sub_UC_eMed_04.md#sub_uc_emed_08_02---geplante-abgabe-Stornierenbeenden-durch-fachanwendung)
* [Canceln](Sub_UC_eMed_04.md#sub_uc_emed_08_03---geplante-abgabe-gecancelt-durch-fachanwendung)
* [Ablauf](Sub_UC_eMed_04.md#sub_uc_emed_08_03---geplante-abgabe-abgelaufen-durch-fachanwendung) von **Geplanten Abgaben**.
 

ℹ️ Die fachlichen Anforderungen dieses Use Cases werden beschrieben in:
*  [UC_eMed_04 Geplante Abgabe schreiben](Sub_UC_eMed_04.md) 
Es gelten die dort festgelegten Vorbedingungen. Alle Zugriffe werden protokolliert.

### Sub_UC_eMed_04_01 - Geplante Abgabe erstellen (Prescription-Write)

Der GDA kann basierend auf der **aktuellen Version** eines bestehenden **Medikationsplaneintrags** eine oder mehrere [Geplante Abgaben](StructureDefinition-at-elga-emed-medicationrequest-geplanteabgabe.md) erstellen. Für jedes zu rezeptierende Arzneimittel wird eine eigene **Geplante Abgabe** erstellt, um die medizinische Inhalte des e-Rezepts zu dokumentieren.

Falls für eine **Geplante Abgabe** noch kein Medikationsplaneintrag existiert, muss dieser zuerst erstellt werden (siehe [Sub_UC_eMed_02_02 - Planeintrag in Medikationsplan hinzufügen](Sub_UC_eMed_02.md#sub_uc_emed_02_02---planeintrag-in-medikationsplan-hinzufügen)). Unter gewissen Voraussetzungen kann ein bestehender Medikationsplaneintrag angepasst werden (siehe [Sub_UC_eMed_02_03 - Planeintrag im Medikationsplan ändern](Sub_UC_eMed_02.md#sub_uc_emed_02_03---planeintrag-im-medikationsplan-ändern)). Die medizinischen Inhalte von Planeintrag und **Geplanter Abgabe** (wie Arzneimittel und Dosierung) dürfen sich **nicht unterscheiden**.

Wird der zugehörige Planeintrag nach der Erstellung einer **Geplanten Abgabe** geändert, kann die **Geplante Abgabe** weiterhin gültig bleiben oder gegebenenfalls storniert werden (siehe [Sub_UC_eMed_08_04 - Geplante Abgabe stornieren ($prescription-discard)](Sub_UC_eMed_04.md#sub_uc_emed_08_04---geplante-abgabe-stornieren-prescription-discard)).

Medikationsplaneinträge können mehrfach rezeptiert werden und daher auch zu mehreren **Geplanten Abgaben** führen. <!– Können von einer Planeintragsversion gleichzeitig mehrere Geplante Abgaben aktiv sein? oder gilt nicht eher: Es können zu einem Planeintrag mehrere aktive **Geplante Abgaben** existieren, aber nur eine je Planeintragversion.

Die Anzahl der **Geplanten Abgaben**, die mit demselben **e-Med Groupidentifier** gespeichert werden können, ist durch das Limit für die Anzahl der Medikamente je (e-)Rezept begrenzt.

#### Ablauf

Der GDA führt ein **POST** [$plan-read](OperationDefinition-AtElgaEmed.List.Planread.md) aus und erhält von der Fachanwendung im [Medikationsplan-Bundle](StructureDefinition-at-elga-emed-bundle-medikationsplan.md) alle für die Erstellung der **Geplanten Abgaben** relevanten Ressourcen.

Basierend auf den enthaltenen Planeinträgen erstellt der GDA neue **Gelplante Abgaben** wie folgt:

* ****MedicationRequest**-Ressource(n) erstellen:** [Geplante Abgaben](StructureDefinition-at-elga-emed-medicationrequest-geplanteabgabe.md)(StructureDefinition-at-elga-emed-medicationrequest-planeintrag.html): 
* **Geplanter Einnahmezeitraum**: (**extension:effectiveDosePeriod**): Beginn: aktuelles Datum oder Datum in der Zukunft, Ende: Datum in der Zukunft oder unbefristet. 
* **Status** muss **active** sein (siehe [Status des MedicationRequests in der geplanten Abgabe](workflowmanagement.md#status-des-medicationrequests-in-der-geplanten-abgabe))
* **Kategorie** (**category:mrcategory**): "Geplante Abgabe", zur Unterscheidung von Planeinträgen
* [**Rezeptart**](https://termgit.elga.gv.at/ValueSet-elga-medikationrezeptart.html) (**category:recipetype**): muss verpflichtend ausgewählt werden
* **Medikation**: muss **identisch** sein mit der des Planeintrags. Enthält der Planeintrag ausschließlich Wirkstoffe, sind diese auch in der **Geplanten Abgabe** in der gleichen Form zu dokumentieren, anderenfalls muss der Planeintrag zuvor angepasst werden (z.B. Austausch der Wirkstoffe mit einem entsprechenden Arzneimittel der ASP-Liste (inkl. PZN)).  
* **Informationen zur Erstellung**: aktuelles Datum (**authoredOn**) und aktueller GDA als Ersteller (**requester**)
* **Referenz auf den zugrundeliegenden Planeintrag** (**basedOn**): wird **nicht versioniert**, verweist somit immer auf den aktuellen Planeintrag, auch wenn dieser zwischenzeitlich geändert wurde.
* **Dosierung** (**dosageInstruction**): muss **identisch** sein mit der des Planeintrags.
* **e-Med GroupIdentifier** (**groupIdentifier**): 
* Alle zeitgleich erstellten **Geplante Abgaben**, die zum selben (e-)Rezept gehören, müssen den selben **e-Med Groupidentifier** tragen und **im selben [Geplante Abgaben-Transaction Bundle](StructureDefinition-at-elga-emed-bundle-geplanteabgaben-tx.md)** übermittelt werden. Der **e-Med GroupIdentifier** ermöglicht zusammengehörige **Geplante Abgaben** und **Durchgeführte Abgaben** gemeinsam abzurufen und kann über unterschiedliche Varianten bezogen werden (siehe [Sub_UC_eMed_04_02 - e-Med GroupIdentifier beziehen](Sub_UC_eMed_04.md#sub_uc_emed_04_02---e-med-groupidentifier-beziehen)). Er bleibt grundsätzlich solange gültig, solange die **Geplante Abgabe = active** ist.
* Fehlt im übermittelten [Geplante Abgaben-Transaction Bundle](StructureDefinition-at-elga-emed-bundle-geplanteabgaben-tx.md) bei allen **Geplanten Abgaben** der **e-Med GroupIdentifier**, ergänzt ihn die Fachanwendung.
 
* **Gültigkeitszeitraum zur Einlösung** (**dispenseRequest.validityPeriod**) und
* **Anzahl möglicher weiterer Einlösungen** (**dispenseRequest.numberOfRepeatsAllowed**) sind abhängig von der ausgewählten Rezeptart (siehe [Gültigkeit von Geplanten Abgaben basierend auf der Rezeptart](workflowmanagement.md#gültigkeit-von-geplanten-abgaben-basierend-auf-der-rezeptart))
* **Bereitzustellende Menge** (**dispenseRequest.quantity**): Verpflichtende Angabe der Menge (Anzahl Packungen), die bei jeder Abgabe bereitgestellt werden soll.
 

Alle zusammengehörenden, erstellten **Geplanten Abgaben** werden in einem eigenen [Geplante Abgaben-Transaction Bundle](StructureDefinition-at-elga-emed-bundle-geplanteabgaben-tx.md) mittels **POST** [$prescription-write](Sub_UC_eMed_04.md#custom-operations) an die Fachanwendung übermittelt. 

#### Relevante Elemente (MedicationRequest)

```
AtElgaEmedMedicationRequestGeplanteAbgabe
    effectiveDosePeriod: Einnahmezeitraum
    status: active 
    category[mrcategory]: 2 "Geplante Abgabe"               //Kategorie zur Unterscheidung der MedicationRequests
    category[recipetype]: KASSEN | PRIVAT | SUBST          // Verpflichtende Angabe der Rezeptart
    medicationReference.reference: Medikation gemäß Planeintrag // Contained Medication
    authoredOn: Datum der Erstellung der Geplanten Abgabe
    requester: veranwortlicher GDA 
    basedOn: id des zugehörigen Medikationsplaneintrags     // referenziert aktuelle Version 
    groupIdentifier: e-Med GroupIdentifier                  // optionale Rezeptklammer 
    dosageInstruction: gemäß Planeintrag 
    dispenseRequest.validityPeriod: Gültigkeitszeitraum     // abhängig von Rezeptart 
    dispenseRequest.numberOfRepeatsAllowed: Anzahl weiterer Einlösungen // abhängig von Rezeptart
    dispenseRequest.quantity: Abzugebende Menge (Packungen) je Abgabe

```

##### Custom Operations

 Offene Punkte: 
$prescription-write: in Arbeit. 

### Sub_UC_eMed_04_02 - e-Med GroupIdentifier beziehen

Der Ablauf zur Erstellung von **Geplanten Abgaben** und der Bezug des **e-Med GroupIdentifiers** kann unterschiedlich erfolgen. Exemplarisch werden drei Varianten angeführt.

##### Variante A: Vorab-Ermittlung des e-Med GroupIdentifiers (GroupIdentifier-Create)

Der **e-Med GroupIdentifier** ("Rezeptklammer") wird via **POST** **$groupidentifier-create**  vorab von der Fachanwendung bezogen, in den **Geplanten Abgaben** ergänzt und zur Erstellung des e-Rezepts an die e-Rezept-Anwendung mitgegeben, um dieses mit den **Geplanten Abgaben** zu verknüpfen. Der Trigger zu Erstellung des e-Rezepts und [Prescription-Write](Sub_UC_eMed_04.md#sub_uc_emed_04_01---geplante-abgabe-erstellen-prescription-write) können parallel erfolgen (siehe Normalfall).

Liefert e-Rezept einen Fehler zurück, können mittels POST **$prescription-discard** bereits in der e-Medikation erstellte **Geplante Abgaben** verworfen werden (siehe [Sub_UC_eMed_08_04 - Geplante Abgabe stornieren ($prescription-discard)](Sub_UC_eMed_04.md#sub_uc_emed_08_04---geplante-abgabe-stornieren-prescription-discard)). Liefert die e-Medikation Fachanwendung einen Fehler zurück, kann nach Fehlerkorrektur erneut ein **Prescription-Write** erfolgen oder ein bereits durch den **e-Med groupIdentifer** verknüpftes e-Rezept wieder von den **Geplanten Abgaben** "entkoppelt" werden (siehe [Variante A: Fehlerfall](Sub_UC_eMed_04.md#variante-a-fehlerfall)).

###### Variante A: Normalfall

![](plantuml/UC_eMed_04_01_a_normal.svg)

###### Variante A: Fehlerfall

![](plantuml/UC_eMed_04_01_a_fehler.svg)

##### Variante B: Sequentielles Erstellen von Geplanter Abgabe und e-Rezept

Alternativ kann der **e-Med GroupIdentifier** durch die Fachanwendung automatisch ergänzt werden, wenn dieser beim **Prescription-Write** nicht in den **Geplanten Abgaben** im Transaction Bundle enthalten ist. Dadurch bleibt das Verhalten konsistent zur bestehenden e-Medikations-Implementierung. Hierfür müssen die **Geplanten Abgaben**, die zu einem (e-)Rezept gehören, gemeinsam in einem [Geplante Abgaben-Transaction Bundle](StructureDefinition-at-elga-emed-bundle-geplanteabgaben-tx.md) mit mittels **POST** [$prescription-write](Sub_UC_eMed_04.md#custom-operations) an die e-Medikation Fachanwendung übermittelt werden. Der Server ergänzt den **e-Med GroupIdentifier** während der Transaktionsverarbeitung und gibt die persistierten Ressourcen einschließlich des erzeugten **e-Med GroupIdentifiers** in der Response an den Client zurückgegeben. Im Anschluss kann der Trigger zur Erstellung des e-Rezepts inkl. **e-Med GroupIdentifier** erfolgen.

![](plantuml/UC_eMed_04_01_b.svg)

##### Variante C: Nachträgliche Verknüpfung des e-Rezepts mit dem e-Med GroupIdentifier

Der Trigger zu Erstellung des e-Rezepts und [Prescription-Write](Sub_UC_eMed_04.md#sub_uc_emed_04_01---geplante-abgabe-erstellen-prescription-write) können parallel erfolgen (Variante A), allerdings noch ohne **e-Med GroupIdentifier**. Die e-Medikation Fachanwendung ergänzt diesen und liefert ihn an den Client zurück (wie in Variante B), der Client führt im Anschluss eine nachträgliche Verknüfung des bereits erstellten e-Rezepts mit den **Geplanten Abgaben** mittels **e-Med GroupIdentifier** durch.

![](plantuml/UC_eMed_04_01_c.svg)

##### Custom Operations

 Offene Punkte: 
$groupidentifier-create: in Arbeit. 

### Sub_UC_eMed_08_04 - Geplante Abgabe stornieren (Prescription-Discard)

Ein GDA kann eine selbsterfasste [Geplante Abgaben](StructureDefinition-at-elga-emed-medicationrequest-geplanteabgabe.md) aufgrund eines Fehlers stornieren, solange noch keine Abgaben durchgeführt (dh. noch keine zugehörige **Durchgeführten Abgaben** erstellt) wurden.

* Ausnahme: Alle zugehörigen **Durchgeführten Abgaben** werden zuvor storniert 

Um eine **Geplante Abgabe** zu stornieren, führt der GDA die Operation [$prescription-discard​](interactions.md#prescription-discard) aus:

* Der Status der **Geplante Abgaben** wird auf ****entered-in-error**** gesetzt (siehe [Status des MedicationRequests in der geplanten Abgabe](workflowmanagement.md#status-des-medicationrequests-in-der-geplanten-abgabe)),
* das Datum in **authoredOn** wird aktualisiert.

#### Relevante Elemente (MedicationRequest)

```
AtElgaEmedMedicationRequestGeplanteAbgabe
    status: entered-in-error 
    authoredOn: Datum des Verwerfens der Geplanten Abgabe
    requester: veranwortlicher GDA für das Verwerfen der Geplanten Abgabe 

```

##### Custom Operations

 Offene Punkte: 
$prescription-discard: in Arbeit. 

### Sub_UC_eMed_08_02 - Geplante Abgabe beenden (durch Fachanwendung)

Wurden alle möglichen Einlösungen einer **Geplanten Abgabe** planmäßig durchgeführt (siehe [Sub_UC_eMed_05_01 - Durchgeführte Abgabe erfassen](Sub_UC_eMed_05.md#Sub_UC_eMed_05_01---durchgeführte-abgabe-erfassen)), setzt die Fachanwendung die **Geplante Abgabe** **automatisch** auf den Status ****completed**** (siehe [Status des MedicationRequests in der geplanten Abgabe](workflowmanagement.md#status-des-medicationrequests-in-der-geplanten-abgabe)). Die **Geplante Abgabe** ist damit abgeschlossen.

Sonderfall: Wenn die letzte **Durchgeführte Abgabe** danach verworfen wird (Status **entered-in-error**), wird der Status der **Geplanten Abgabe** durch die Fachanwendung wieder auf **active** gesetzt.

Die Fachanwendung erkennt anhand von **MedicationRequest.numberOfRepeatsAllowed**, ob weitere Einlösungen erlaubt sind (z.B. bei einem Privatrezept). Ist nur eine einmalige Einlösung möglich (z.B. Kassenrezept), setzt die Fachanwendung die **Geplanten Abgabe** sofort auf den Status **completed**.

Ermöglicht die **Geplante Abgabe** mehrere Einlösungen (**MedicationRequest.numberOfRepeatsAllowed > 0**), muss je Einlösung mindestens eine **Durchgeführte Abgabe** erstellt werden (bei Teilabgaben können es mehrere sein). Eine Einlösung gilt als vollständig, wenn für MedicationDispense.type den Wert FFC (First Fill – Complete) oder PFC (Part Fill - Complete) enthält.

Der Status der **Geplanten Abgabe** bleibt solange **active**, bis die letztmögliche Einlösung erfolgt ist (sieheSub_UC_eMed_08_02 - Geplante Abgabe beenden (durch Fachanwendung)).

#### Relevante Elemente (MedicationRequest)

```
AtElgaEmedMedicationRequestGeplanteAbgabe
    status: completed
    authoredOn: Datum der Erstellung der geplanten Abgabe  // bleibt unverändert
    requester: Ursprünglicher Ersteller                    // bleibt unverändert

```

 Offene Punkte: 
Erfolgt in der Geplanten Abgabe eine Datumsanpassung bei automatischen Aktionen durch die Fachanwendung? (in R6 gibt es dafür das Element: statusChanged); betrifft alle automatischen Statuswechsel der Geplanten Abgabe. 

### Sub_UC_eMed_08_03 - Geplante Abgabe abgelaufen (durch Fachanwendung)

Ist der Gültigkeitszeitraum in **dispenseRequest.validityPeriod** der **Geplanten Abgabe** gemäß der ausgewählten Rezeptart (category:recipetype) (siehe [Gültigkeit von Geplanten Abgaben basierend auf der Rezeptart](workflowmanagement.md#gültigkeit-von-geplanten-abgaben-basierend-auf-der-rezeptart)) oder den Einschränkungen des GDAs überschritten, setzt die Fachanwendung die **Geplante Abgabe** **automatisch** auf den Status ****stopped**** (siehe [Status des MedicationRequests in der geplanten Abgabe](workflowmanagement.md#status-des-medicationrequests-in-der-geplanten-abgabe)). Die **Geplante Abgabe** ist damit abgeschlossen.

#### Relevante Elemente (MedicationRequest)

```
AtElgaEmedMedicationRequestGeplanteAbgabe
    status: stopped
    authoredOn: Datum der Erstellung der geplanten Abgabe  // bleibt unverändert
    requester: Ursprünglicher Ersteller                    // bleibt unverändert

```

### Sub_UC_eMed_08_03 - Geplante Abgabe gecancelt (durch Fachanwendung)

Eine **Geplante Abgabe** erhält **automatisch** den Status **cancelled** (siehe [Status des MedicationRequests in der geplanten Abgabe](workflowmanagement.md#status-des-medicationrequests-in-der-geplanten-abgabe)), wenn **alle** **Durchgeführten Abgaben** (jede Einlösung) den Status ****cancelled**** erhalten haben ("Leerabgabe", d.h. keine Abgabe durchgeführt). Die **Geplanten Abgabe** ist damit abgeschlossen.

Sonderfall: Wenn die letzte **Durchgeführte Abgabe** danach verworfen wird (Status **entered-in-error**), wird der Status der **Geplanten Abgabe** durch die Fachanwendung wieder auf **active** gesetzt.

#### Relevante Elemente (MedicationRequest)

```
AtElgaEmedMedicationRequestGeplanteAbgabe
    status: cancelled
    authoredOn: Datum der Erstellung der geplanten Abgabe  // bleibt unverändert
    requester: Ursprünglicher Ersteller                    // bleibt unverändert

```

### Sub_UC_eMed_08_05 - Geplante Abgabe löschen (durch ELGA-Teilnehmer) (prescription-delete)

 Offene Punkte:
 Umsetzung Teilnehmerrechte 

 Der ELGA-Teilnehmer kann eine **Geplante Abgabe** endgültig löschen. Bereits dokumentierte zugehörige **Durchgeführte Abgaben** sowie bestehende Planeinträge bleiben davon unberührt.

Die Löschung der **Geplanten Abgabe** umfasst:

* die fachliche Entfernung der betreffenden MedicationRequest-Ressource sowie
* die Entfernung aller zugehörigen historischen Ressourcen-Versionen (_history).

Zum Löschen einer **Geplanten Abgabe** ruft der ELGA-Teilnehmer diese im Zugangsportal auf. Dieses führt zunächst eine Leseoperation auf die betreffende MedicationRequest-Ressource aus (GET MedicationRequest/[id]) und löscht anschließend die betreffende **Geplante Abgabe** mittels DELETE (DELETE [base]/MedicationRequest/[id]).

Die Ressource einschließlich aller historischen Versionen darf nach erfolgreicher Löschung weder über reguläre FHIR-Interaktionen noch über administrative Schnittstellen abrufbar sein.

 Offene Punkte:
 Referenzen auf gelöschte Ressourcen (z.B. von bestehenden Durchgefürhte Abgaben auf gelöschte Geplante Abgaben) können nicht mehr aufgelöst werden. 

