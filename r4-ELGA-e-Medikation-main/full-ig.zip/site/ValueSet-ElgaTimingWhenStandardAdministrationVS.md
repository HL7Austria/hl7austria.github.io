# HL7.AT.FHIR.ELGA.EMED.R4\ELGA Dosierung Timing When ValueSet für Tageszeitenschema - FHIR® v4.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ELGA Dosierung Timing When ValueSet für Tageszeitenschema**

## ValueSet: ELGA Dosierung Timing When ValueSet für Tageszeitenschema (Experimental) 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.hl7.at/elga/emed/r4/ValueSet/ElgaTimingWhenStandardAdministrationVS | *Version*:0.1.0 | |
| Active as of 2026-09-29 | *Responsible:*[ELGA GmbH](http://elga.gv.at) | *Computable Name*:ElgaTimingWhenStandardAdministrationVS |

 
ValueSet für zulässige Ausprägungen des Elements when eines Timings für eine Dosierung mit Tageszeitenschema. 

 **References** 

* [AtElgaEmedDosageStandardAdministration](StructureDefinition-at-elga-emed-dosage-standard-administration.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ElgaTimingWhenStandardAdministrationVS",
  "url" : "https://fhir.hl7.at/elga/emed/r4/ValueSet/ElgaTimingWhenStandardAdministrationVS",
  "version" : "0.1.0",
  "name" : "ElgaTimingWhenStandardAdministrationVS",
  "title" : "ELGA Dosierung Timing When ValueSet für Tageszeitenschema",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-09-29T15:22:43+00:00",
  "publisher" : "ELGA GmbH",
  "contact" : [{
    "name" : "ELGA GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "http://elga.gv.at"
    }]
  },
  {
    "name" : "ELGA GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://elga.gv.at",
      "use" : "work"
    }]
  }],
  "description" : "ValueSet für zulässige Ausprägungen des Elements when eines Timings für eine Dosierung mit Tageszeitenschema.",
  "compose" : {
    "include" : [{
      "system" : "http://hl7.org/fhir/event-timing",
      "version" : "4.0.1",
      "concept" : [{
        "code" : "MORN"
      },
      {
        "code" : "NOON"
      },
      {
        "code" : "EVE"
      },
      {
        "code" : "NIGHT"
      }]
    }]
  }
}

```
