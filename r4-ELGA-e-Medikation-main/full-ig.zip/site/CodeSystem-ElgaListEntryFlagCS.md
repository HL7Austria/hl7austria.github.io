# HL7.AT.FHIR.ELGA.EMED.R4\ELGA List.entry.flag CodeSystem - FHIR® v4.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ELGA List.entry.flag CodeSystem**

## CodeSystem: ELGA List.entry.flag CodeSystem (Experimental) 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.hl7.at/elga/emed/r4/CodeSystem/ElgaListEntryFlagCS | *Version*:0.1.0 | |
| Active as of 2026-09-25 | *Responsible:*[ELGA GmbH](http://elga.gv.at) | *Computable Name*:ElgaListEntryFlagCS |

 
CodeSystem für zulässige Ausprägungen des Flags eines List.Entries in ELGA. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [ELGA List.entry.flag Value Set](ValueSet-ElgaListEntryFlagVS.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "ElgaListEntryFlagCS",
  "url" : "https://fhir.hl7.at/elga/emed/r4/CodeSystem/ElgaListEntryFlagCS",
  "version" : "0.1.0",
  "name" : "ElgaListEntryFlagCS",
  "title" : "ELGA List.entry.flag CodeSystem",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-09-25T14:56:10+00:00",
  "publisher" : "ELGA GmbH",
  "contact" : [{
    "name" : "ELGA GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "http://elga.gv.at"
    }]
  },
  {
    "name" : "ELGA GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://elga.gv.at",
      "use" : "work"
    }]
  }],
  "description" : "CodeSystem für zulässige Ausprägungen des Flags eines List.Entries in ELGA.",
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 4,
  "concept" : [{
    "code" : "new",
    "display" : "Neuer Planeintrag"
  },
  {
    "code" : "unchanged",
    "display" : "Planeintrag beibehalten"
  },
  {
    "code" : "changed",
    "display" : "Planeintrag geändert"
  },
  {
    "code" : "removed",
    "display" : "Planeintrag entfernt"
  }]
}

```
