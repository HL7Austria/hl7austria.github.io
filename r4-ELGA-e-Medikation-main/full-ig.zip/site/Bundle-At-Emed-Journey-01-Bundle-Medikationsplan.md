# HL7.AT.FHIR.ELGA.EMED.R4\Beispiel Journey 01: Medikationsplan-Searchset-Bundle - FHIR® v4.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Beispiel Journey 01: Medikationsplan-Searchset-Bundle**

## Example Bundle: Beispiel Journey 01: Medikationsplan-Searchset-Bundle



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "At-Emed-Journey-01-Bundle-Medikationsplan",
  "meta" : {
    "profile" : ["https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-elga-emed-bundle-medikationsplan"]
  },
  "type" : "searchset",
  "timestamp" : "2026-02-27T08:00:00+00:00",
  "entry" : [{
    "fullUrl" : "https://example.elga.com/List/At-Emed-Journey-01-List-Medikationsplan",
    "resource" : {
      "resourceType" : "List",
      "id" : "At-Emed-Journey-01-List-Medikationsplan",
      "meta" : {
        "profile" : ["https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-elga-emed-list-medikationsplan"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"List_At-Emed-Journey-01-List-Medikationsplan\"> </a><p class=\"res-header-id\"><b>Generated Narrative: List At-Emed-Journey-01-List-Medikationsplan</b></p><a name=\"At-Emed-Journey-01-List-Medikationsplan\"> </a><a name=\"hcAt-Emed-Journey-01-List-Medikationsplan\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-at-elga-emed-list-medikationsplan.html\">AT ELGA e-Medikation List Medikationsplan</a></p></div><table class=\"clstu\"><tr><td>Date: 2026-02-27 08:00:00+0000 </td><td>Mode: Working List </td><td>Status: Current </td><td>Code: Medikationsplan </td></tr><tr><td>Subject: <a href=\"Patient-At-Emed-Example-Patient-01.html\">Anton Mustermann  Male, DoB: 1900-01-01 ( Social Security number: 1234010100)</a>Source: </td></tr></table><table class=\"grid\"><tr style=\"backgound-color: #eeeeee\"><td><b>Items</b></td></tr></table></div>"
      },
      "status" : "current",
      "mode" : "working",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "736378000",
          "display" : "Medikationsplan"
        }]
      },
      "subject" : {
        "reference" : "Patient/At-Emed-Example-Patient-01"
      },
      "date" : "2026-02-27T08:00:00+00:00",
      "source" : {
        "reference" : "Device/At-Emed-Example-Device-01"
      },
      "emptyReason" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
          "code" : "notstarted"
        }]
      }
    }
  },
  {
    "fullUrl" : "https://example.elga.com/Patient/At-Emed-Example-Patient-01",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "At-Emed-Example-Patient-01",
      "meta" : {
        "profile" : ["https://fhir.hl7.at/elga/core/r4/StructureDefinition/at-elga-core-patient",
        "http://hl7.at/fhir/HL7ATCoreProfiles/4.0.1/StructureDefinition/at-core-patient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_At-Emed-Example-Patient-01\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient At-Emed-Example-Patient-01</b></p><a name=\"At-Emed-Example-Patient-01\"> </a><a name=\"hcAt-Emed-Example-Patient-01\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"https://build.fhir.org/ig/HL7Austria/ELGA-Core-R4/StructureDefinition-at-elga-core-patient.html\">AT ELGA Core Patient Profil</a>, <a href=\"http://hl7.at/fhir/HL7ATCoreProfiles/4.0.1/2.0.0/StructureDefinition-at-core-patient.html\">HL7® AT Core Patient Profile</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Anton Mustermann  Male, DoB: 1900-01-01 ( Social Security number: 1234010100)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Other Ids (see the one above)\">Other Ids:</td><td colspan=\"3\"><ul><li>National unique individual identifier/GH:oeLdSEb0l+8kSdJWjOYyYmnYki0=</li><li>Patient internal identifier/0815</li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li><a href=\"mailto:office@hl7.at\">office@hl7.at</a></li><li><a href=\"tel:+436501234567890\">+436501234567890</a></li><li>Landstrasse 1 Stock 9 Tür 42 Linz Oberösterreich 4020 AUT (home)</li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"HL7® Austria FHIR® Core Extension for the religion (registered in Austria) of a patient.\r\nThe extension is used to encode the religious confession of a patient (only confessions registered in Austria). Furthermore, it uses the official [HL7 AT CodeSystem](https://termpub.gesundheit.gv.at:443/TermBrowser/gui/main/main.zul?loadType=CodeSystem&amp;loadName=HL7 AT ReligionAustria) for religion and is therefore aligned with the ELGA ValueSet, respectively.\">Patient Religion:</td><td colspan=\"3\"><ul><li>code: <span title=\"Codes:{https://termgit.elga.gv.at/CodeSystem/hl7-at-religionaustria 162}\">Pastafarianismus</span></li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"The patient's legal status as citizen of a country.\">Patient Citizenship:</td><td colspan=\"3\"><ul><li>code: <span title=\"Codes:{https://termgit.elga.gv.at/CodeSystem/iso-3166-1-alpha-3 AUT}\">Österreich</span></li></ul></td></tr></table></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://termgit.elga.gv.at/CodeSystem/hl7-at-religionaustria",
              "code" : "162",
              "display" : "Pastafarianismus"
            }]
          }
        }],
        "url" : "http://hl7.at/fhir/HL7ATCoreProfiles/4.0.1/StructureDefinition/at-core-ext-patient-religion"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://termgit.elga.gv.at/CodeSystem/iso-3166-1-alpha-3",
              "code" : "AUT",
              "display" : "Österreich"
            }]
          }
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/patient-citizenship"
      }],
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "SS",
            "display" : "Social Security number"
          }]
        },
        "system" : "urn:oid:1.2.40.0.10.1.4.3.1",
        "value" : "1234010100",
        "assigner" : {
          "display" : "Dachverband der österreichischen Sozialversicherungsträger"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "NI",
            "display" : "National unique individual identifier"
          }]
        },
        "system" : "urn:oid:1.2.40.0.10.2.1.1.149",
        "value" : "GH:oeLdSEb0l+8kSdJWjOYyYmnYki0=",
        "assigner" : {
          "display" : "Bundesministerium für Inneres"
        }
      },
      {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "PI",
            "display" : "Patient internal identifier"
          }]
        },
        "system" : "urn:oid:1.2.3.4.5",
        "value" : "0815",
        "assigner" : {
          "display" : "Ein GDA in Österreich"
        }
      }],
      "name" : [{
        "family" : "Mustermann",
        "given" : ["Anton"],
        "prefix" : ["DI"]
      }],
      "telecom" : [{
        "system" : "email",
        "value" : "office@hl7.at",
        "use" : "work"
      },
      {
        "system" : "phone",
        "value" : "+436501234567890",
        "use" : "home"
      }],
      "gender" : "male",
      "birthDate" : "1900-01-01",
      "address" : [{
        "use" : "home",
        "type" : "both",
        "line" : ["Landstrasse 1 Stock 9 Tür 42"],
        "_line" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
            "valueString" : "Landstrasse"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
            "valueString" : "1"
          },
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-additionalLocator",
            "valueString" : "Stock 9 Tür 42"
          },
          {
            "url" : "http://hl7.at/fhir/HL7ATCoreProfiles/4.0.1/StructureDefinition/at-core-ext-address-additionalInformation",
            "valueString" : "Lift vorhanden"
          }]
        }],
        "city" : "Linz",
        "state" : "Oberösterreich",
        "postalCode" : "4020",
        "country" : "AUT"
      }]
    }
  },
  {
    "fullUrl" : "https://example.elga.com/Device/At-Emed-Example-Device-01",
    "resource" : {
      "resourceType" : "Device",
      "id" : "At-Emed-Example-Device-01",
      "text" : {
        "status" : "additional",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Device_At-Emed-Example-Device-01\"> </a><p>e-Medikation Fachanwendung.</p></div>"
      },
      "deviceName" : [{
        "name" : "e-Med Fachanwendung",
        "type" : "user-friendly-name"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "49062001",
          "display" : "Gerät"
        }]
      }
    }
  }]
}

```
