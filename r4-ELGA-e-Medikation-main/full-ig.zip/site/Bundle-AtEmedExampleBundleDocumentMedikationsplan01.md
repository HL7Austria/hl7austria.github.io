# HL7.AT.FHIR.ELGA.EMED.R4\Beispiel eines Document Bundles Medikationsplan 1 - FHIR® v4.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Beispiel eines Document Bundles Medikationsplan 1**

## Example Bundle: Beispiel eines Document Bundles Medikationsplan 1



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "AtEmedExampleBundleDocumentMedikationsplan01",
  "meta" : {
    "profile" : [
      "https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-emed-bundle-document-medikationsplan"
    ]
  },
  "type" : "document",
  "timestamp" : "2024-10-03T10:12:00+02:00",
  "entry" : [
    {
      "fullUrl" : "Composition/example-composition",
      "resource" : {
        "resourceType" : "Composition",
        "id" : "ExampleMedikationsplanComposition",
        "meta" : {
          "profile" : [
            "https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-emed-composition-medikationsplan"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Composition_ExampleMedikationsplanComposition\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition ExampleMedikationsplanComposition</b></p><a name=\"ExampleMedikationsplanComposition\"> </a><a name=\"hcExampleMedikationsplanComposition\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-at-emed-composition-medikationsplan.html\">ELGA e-Medikation Composition Medikationsplan</a></p></div><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 736378000}\">Medikationsplan</span></p><p><b>date</b>: 2024-10-03 10:12:00+0200</p><p><b>author</b>: <a href=\"Practitioner-ExampleArzt.html\">Practitioner Max Hausarzt </a></p><p><b>title</b>: Medikationsplan</p></div>"
        },
        "status" : "final",
        "type" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "736378000",
              "display" : "Medikationsplan"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/ExamplePatient"
        },
        "date" : "2024-10-03T10:12:00+02:00",
        "author" : [
          {
            "reference" : "Practitioner/ExampleArzt"
          }
        ],
        "title" : "Medikationsplan",
        "section" : [
          {
            "code" : {
              "coding" : [
                {
                  "code" : "medikationsplan",
                  "display" : "Medikationsplan"
                }
              ]
            },
            "entry" : [
              {
                "reference" : "MedicationRequest/med1"
              },
              {
                "reference" : "MedicationRequest/med2"
              },
              {
                "reference" : "List/planlist"
              }
            ]
          }
        ]
      }
    },
    {
      "fullUrl" : "MedicationRequest/med1",
      "resource" : {
        "resourceType" : "MedicationRequest",
        "id" : "ExamplePlaneintragMed1",
        "meta" : {
          "profile" : [
            "https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-emed-medicationrequest-planeintrag"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_ExamplePlaneintragMed1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationRequest ExamplePlaneintragMed1</b></p><a name=\"ExamplePlaneintragMed1\"> </a><a name=\"hcExamplePlaneintragMed1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-at-emed-medicationrequest-planeintrag.html\">ELGA e-Medikation Planeintrag</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>category</b>: <span title=\"Codes:\">Medikationsplaneintrag</span></p><p><b>medication</b>: <span title=\"Codes:{https://termgit.elga.gv.at/CodeSystem/asp-liste 2443061}\">EBETREXAT TBL 10MG</span></p><p><b>subject</b>: <a href=\"Patient-ExamplePatient.html\">Erika Test  Female, DoB: 1970-02-14</a></p><p><b>authoredOn</b>: 2024-10-03</p><p><b>requester</b>: <a href=\"Practitioner-ExampleArzt.html\">Practitioner Max Hausarzt </a></p><h3>DosageInstructions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Text</b></td></tr><tr><td style=\"display: none\">*</td><td>1x morgens</td></tr></table></div>"
        },
        "status" : "active",
        "intent" : "order",
        "category" : [
          {
            "coding" : [
              {
                "code" : "1",
                "display" : "Medikationsplaneintrag"
              }
            ]
          }
        ],
        "medicationCodeableConcept" : {
          "coding" : [
            {
              "system" : "https://termgit.elga.gv.at/CodeSystem/asp-liste",
              "code" : "2443061",
              "display" : "EBETREXAT TBL 10MG"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/ExamplePatient"
        },
        "authoredOn" : "2024-10-03",
        "requester" : {
          "reference" : "Practitioner/ExampleArzt"
        },
        "dosageInstruction" : [
          {
            "text" : "1x morgens"
          }
        ]
      }
    },
    {
      "fullUrl" : "MedicationRequest/med2",
      "resource" : {
        "resourceType" : "MedicationRequest",
        "id" : "ExamplePlaneintragMed2",
        "meta" : {
          "profile" : [
            "https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-emed-medicationrequest-planeintrag"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_ExamplePlaneintragMed2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationRequest ExamplePlaneintragMed2</b></p><a name=\"ExamplePlaneintragMed2\"> </a><a name=\"hcExamplePlaneintragMed2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-at-emed-medicationrequest-planeintrag.html\">ELGA e-Medikation Planeintrag</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>category</b>: <span title=\"Codes:\">Medikationsplaneintrag</span></p><p><b>medication</b>: <span title=\"Codes:{https://termgit.elga.gv.at/CodeSystem/asp-liste 3847199}\">AMLODIPIN 5MG</span></p><p><b>subject</b>: <a href=\"Patient-ExamplePatient.html\">Erika Test  Female, DoB: 1970-02-14</a></p><p><b>authoredOn</b>: 2024-10-03</p><p><b>requester</b>: <a href=\"Practitioner-ExampleArzt.html\">Practitioner Max Hausarzt </a></p><h3>DosageInstructions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Text</b></td></tr><tr><td style=\"display: none\">*</td><td>1x täglich</td></tr></table></div>"
        },
        "status" : "active",
        "intent" : "order",
        "category" : [
          {
            "coding" : [
              {
                "code" : "1",
                "display" : "Medikationsplaneintrag"
              }
            ]
          }
        ],
        "medicationCodeableConcept" : {
          "coding" : [
            {
              "system" : "https://termgit.elga.gv.at/CodeSystem/asp-liste",
              "code" : "3847199",
              "display" : "AMLODIPIN 5MG"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/ExamplePatient"
        },
        "authoredOn" : "2024-10-03",
        "requester" : {
          "reference" : "Practitioner/ExampleArzt"
        },
        "dosageInstruction" : [
          {
            "text" : "1x täglich"
          }
        ]
      }
    },
    {
      "fullUrl" : "List/planlist",
      "resource" : {
        "resourceType" : "List",
        "id" : "ExampleMedikationsplanList",
        "meta" : {
          "profile" : [
            "https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-emed-list-medikationsplan"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"List_ExampleMedikationsplanList\"> </a><p class=\"res-header-id\"><b>Generated Narrative: List ExampleMedikationsplanList</b></p><a name=\"ExampleMedikationsplanList\"> </a><a name=\"hcExampleMedikationsplanList\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-at-emed-list-medikationsplan.html\">ELGA e-Medikation Medikationsplan</a></p></div><table class=\"clstu\"><tr><td>Mode: Working List </td><td>Status: Current </td></tr><tr><td>Order: user </td></tr></table><table class=\"grid\"><tr style=\"backgound-color: #eeeeee\"><td><b>Items</b></td><td>Flag</td></tr><tr><td><a href=\"Bundle-AtEmedExampleBundleDocumentMedikationsplan01.html#MedicationRequest/med1\">MedicationRequest: status = active; intent = order; category = Medikationsplaneintrag; medication[x] = EBETREXAT TBL 10MG; authoredOn = 2024-10-03</a></td><td>original</td></tr><tr><td><a href=\"Bundle-AtEmedExampleBundleDocumentMedikationsplan01.html#MedicationRequest/med2\">MedicationRequest: status = active; intent = order; category = Medikationsplaneintrag; medication[x] = AMLODIPIN 5MG; authoredOn = 2024-10-03</a></td><td>original</td></tr></table></div>"
        },
        "status" : "current",
        "mode" : "working",
        "orderedBy" : {
          "coding" : [
            {
              "code" : "user"
            }
          ]
        },
        "entry" : [
          {
            "flag" : {
              "coding" : [
                {
                  "code" : "original"
                }
              ]
            },
            "item" : {
              "reference" : "MedicationRequest/med1"
            }
          },
          {
            "flag" : {
              "coding" : [
                {
                  "code" : "original"
                }
              ]
            },
            "item" : {
              "reference" : "MedicationRequest/med2"
            }
          }
        ]
      }
    }
  ]
}

```
