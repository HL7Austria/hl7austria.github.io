# HL7.AT.FHIR.ELGA.EMED.R4\ELGA e-Med Medikationsplaneintrag StatusReason Value Set - FHIR® v4.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ELGA e-Med Medikationsplaneintrag StatusReason Value Set**

## ValueSet: ELGA e-Med Medikationsplaneintrag StatusReason Value Set (Experimental) 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.hl7.at/elga/emed/r4/ValueSet/AtElgaEmedValueSetPlaneintragStatusReasonVS | *Version*:0.1.1 | |
| Active as of 2026-09-16 | *Responsible:*[ELGA GmbH](http://elga.gv.at) | *Computable Name*:AtElgaEmedValueSetPlaneintragStatusReasonVS |

 
ValueSet für zulässige Ausprägungen des StatusReason eines Medikationsplaneintrags (MedicationRequest). 

 **References** 

* [At ELGA e-Medikation MedicationRequest Planeintrag](StructureDefinition-at-elga-emed-medicationrequest-planeintrag.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "AtElgaEmedValueSetPlaneintragStatusReasonVS",
  "url" : "https://fhir.hl7.at/elga/emed/r4/ValueSet/AtElgaEmedValueSetPlaneintragStatusReasonVS",
  "version" : "0.1.1",
  "name" : "AtElgaEmedValueSetPlaneintragStatusReasonVS",
  "title" : "ELGA e-Med Medikationsplaneintrag StatusReason Value Set",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-09-16T14:44:43+00:00",
  "publisher" : "ELGA GmbH",
  "contact" : [{
    "name" : "ELGA GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "http://elga.gv.at"
    }]
  },
  {
    "name" : "ELGA GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://elga.gv.at",
      "use" : "work"
    }]
  }],
  "description" : "ValueSet für zulässige Ausprägungen des StatusReason eines Medikationsplaneintrags (MedicationRequest).",
  "compose" : {
    "include" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason",
      "version" : "1.0.1",
      "concept" : [{
        "code" : "salg",
        "display" : "Allergy"
      },
      {
        "code" : "sddi",
        "display" : "Drug interacts with another drug"
      },
      {
        "code" : "sdupther",
        "display" : "Duplicate therapy"
      },
      {
        "code" : "surg",
        "display" : "Patient scheduled for surgery"
      },
      {
        "code" : "sintol",
        "display" : "Suspected intolerance"
      }]
    },
    {
      "system" : "https://fhir.hl7.at/elga/emed/r4/CodeSystem/AtElgaEmedCodeSystemPlaneintragStatusReasonCS"
    }]
  }
}

```
