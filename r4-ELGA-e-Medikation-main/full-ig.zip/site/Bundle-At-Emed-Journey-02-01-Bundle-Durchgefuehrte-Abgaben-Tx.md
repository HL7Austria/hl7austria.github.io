# HL7.AT.FHIR.ELGA.EMED.R4\Beispiel Journey 02-01: Durchgefuehrte-Abgaben-Transaction-Bundle - FHIR® v4.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Beispiel Journey 02-01: Durchgefuehrte-Abgaben-Transaction-Bundle**

## Example Bundle: Beispiel Journey 02-01: Durchgefuehrte-Abgaben-Transaction-Bundle



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "At-Emed-Journey-02-01-Bundle-Durchgefuehrte-Abgaben-Tx",
  "meta" : {
    "profile" : ["https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-elga-emed-bundle-durchgefuehrteabgaben-tx"]
  },
  "type" : "transaction",
  "timestamp" : "2026-02-28T11:00:00+00:00",
  "entry" : [{
    "resource" : {
      "resourceType" : "MedicationDispense",
      "id" : "At-Emed-Journey-02-01-Md-Durchgefuehrte-Abgabe-01",
      "meta" : {
        "profile" : ["https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-elga-emed-medicationdispense-durchgefuehrteabgabe"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationDispense_At-Emed-Journey-02-01-Md-Durchgefuehrte-Abgabe-01\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationDispense At-Emed-Journey-02-01-Md-Durchgefuehrte-Abgabe-01</b></p><a name=\"At-Emed-Journey-02-01-Md-Durchgefuehrte-Abgabe-01\"> </a><a name=\"hcAt-Emed-Journey-02-01-Md-Durchgefuehrte-Abgabe-01\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-at-elga-emed-medicationdispense-durchgefuehrteabgabe.html\">AT ELGA e-Medikation MedicationDispense Durchgeführte Abgabe</a></p></div><p><b>R5: Full representation of the dosage instructions (new)</b>: </p><div><p>1-0-0-1 | Täglich: 1-0-0-0</p>\n</div><p><b>R5: When the recording of the dispense started (new)</b>: 2026-02-28 11:00:00+0000</p><p><b>AT ELGA e-Medikation Extension Group Identifier</b>: WYE82A2G8EEW</p><p><b>status</b>: Completed</p><p><b>medication</b>: <a href=\"#hcAt-Emed-Journey-02-01-Md-Durchgefuehrte-Abgabe-01/contained-medication-journey-02-01-01\">Medication RAMIPRIL HEX TBL 5MG</a></p><p><b>subject</b>: <a href=\"Patient-At-Emed-Example-Patient-01.html\">Anton Mustermann  Male, DoB: 1900-01-01 ( Social Security number: 1234010100)</a></p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-At-Emed-Example-Organization-Apo-01.html\">Organization Amadeus Apotheke</a></td></tr></table><p><b>authorizingPrescription</b>: </p><ul><li><a href=\"MedicationRequest/At-Emed-Journey-03-Mr-Geplante-Abgabe-01\">GeplanteAbgabe 1</a></li><li><a href=\"MedicationRequest/At-Emed-Journey-02-Mr-Planeintrag-01\">Planeintrag 1</a></li></ul><p><b>type</b>: <span title=\"Codes:\">FFC</span></p><p><b>quantity</b>: 1 1<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code1 = '1')</span></p><p><b>whenHandedOver</b>: 2026-02-28 11:00:00+0000</p><blockquote><p><b>dosageInstruction</b></p><p><b>AT ELGA e-Medikation Extension Dosierungskategorie</b>: <span title=\"Codes:{https://fhir.hl7.at/elga/emed/r4/CodeSystem/AtElgaEmedCodeSystemDosageCategory standard}\">Standard Administration</span></p><p><b>sequence</b>: 1</p><p><b>patientInstruction</b>: Nehmen Sie die Tablette vor dem Essen mit ausreichend Flüssigkeit ein.</p><p><b>timing</b>: Morning, Once per 1 day</p><p><b>route</b>: <span title=\"Codes:{https://termgit.elga.gv.at/CodeSystem/medikationartanwendung 100000073619}\">zum Einnehmen</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td> Stück<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code{Stueck} = '{Stueck}')</span></td></tr></table></blockquote><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Medication #contained-medication-journey-02-01-01</b></p><a name=\"At-Emed-Journey-02-01-Md-Durchgefuehrte-Abgabe-01/contained-medication-journey-02-01-01\"> </a><a name=\"hcAt-Emed-Journey-02-01-Md-Durchgefuehrte-Abgabe-01/contained-medication-journey-02-01-01\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-at-elga-emed-medication-medikation.html\">AT ELGA e-Medikation Medication Medikation</a></p></div><p><b>code</b>: <span title=\"Codes:{https://termgit.elga.gv.at/CodeSystem/asp-liste 2450836}\">RAMIPRIL HEX TBL 5MG</span></p></blockquote></div>"
      },
      "contained" : [{
        "resourceType" : "Medication",
        "id" : "contained-medication-journey-02-01-01",
        "meta" : {
          "profile" : ["https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-elga-emed-medication-medikation"]
        },
        "code" : {
          "coding" : [{
            "system" : "https://termgit.elga.gv.at/CodeSystem/asp-liste",
            "code" : "2450836",
            "display" : "RAMIPRIL HEX TBL 5MG"
          }]
        }
      }],
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-MedicationDispense.renderedDosageInstruction",
        "valueMarkdown" : "1-0-0-1 | Täglich: 1-0-0-0"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-MedicationDispense.recorded",
        "valueDateTime" : "2026-02-28T11:00:00+00:00"
      },
      {
        "url" : "https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-elga-emed-extension-group-identifier",
        "valueIdentifier" : {
          "value" : "WYE82A2G8EEW"
        }
      }],
      "status" : "completed",
      "medicationReference" : {
        "reference" : "#contained-medication-journey-02-01-01"
      },
      "subject" : {
        "reference" : "Patient/At-Emed-Example-Patient-01"
      },
      "performer" : [{
        "actor" : {
          "reference" : "Organization/At-Emed-Example-Organization-Apo-01"
        }
      }],
      "authorizingPrescription" : [{
        "reference" : "MedicationRequest/At-Emed-Journey-03-Mr-Geplante-Abgabe-01",
        "display" : "GeplanteAbgabe 1"
      },
      {
        "reference" : "MedicationRequest/At-Emed-Journey-02-Mr-Planeintrag-01",
        "display" : "Planeintrag 1"
      }],
      "type" : {
        "coding" : [{
          "code" : "FFC"
        }]
      },
      "quantity" : {
        "value" : 1,
        "system" : "http://unitsofmeasure.org",
        "code" : "1"
      },
      "whenHandedOver" : "2026-02-28T11:00:00+00:00",
      "dosageInstruction" : [{
        "extension" : [{
          "url" : "https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-elga-emed-extension-dosage-category",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://fhir.hl7.at/elga/emed/r4/CodeSystem/AtElgaEmedCodeSystemDosageCategory",
              "code" : "standard"
            }]
          }
        }],
        "sequence" : 1,
        "patientInstruction" : "Nehmen Sie die Tablette vor dem Essen mit ausreichend Flüssigkeit ein.",
        "timing" : {
          "repeat" : {
            "frequency" : 1,
            "period" : 1,
            "periodUnit" : "d",
            "when" : ["MORN"]
          }
        },
        "route" : {
          "coding" : [{
            "system" : "https://termgit.elga.gv.at/CodeSystem/medikationartanwendung",
            "code" : "100000073619",
            "display" : "zum Einnehmen"
          }]
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "unit" : "Stück",
            "system" : "http://unitsofmeasure.org",
            "code" : "{Stueck}"
          }
        }]
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "MedicationDispense"
    }
  },
  {
    "resource" : {
      "resourceType" : "MedicationDispense",
      "id" : "At-Emed-Journey-02-01-Md-Durchgefuehrte-Abgabe-02",
      "meta" : {
        "profile" : ["https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-elga-emed-medicationdispense-durchgefuehrteabgabe"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationDispense_At-Emed-Journey-02-01-Md-Durchgefuehrte-Abgabe-02\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationDispense At-Emed-Journey-02-01-Md-Durchgefuehrte-Abgabe-02</b></p><a name=\"At-Emed-Journey-02-01-Md-Durchgefuehrte-Abgabe-02\"> </a><a name=\"hcAt-Emed-Journey-02-01-Md-Durchgefuehrte-Abgabe-02\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-at-elga-emed-medicationdispense-durchgefuehrteabgabe.html\">AT ELGA e-Medikation MedicationDispense Durchgeführte Abgabe</a></p></div><p><b>R5: Full representation of the dosage instructions (new)</b>: </p><div><p>1-0-1-0 | Täglich 1-0-1-0</p>\n</div><p><b>R5: When the recording of the dispense started (new)</b>: 2026-02-28 11:00:00+0000</p><p><b>AT ELGA e-Medikation Extension Group Identifier</b>: WYE82A2G8EEW</p><p><b>status</b>: Completed</p><p><b>medication</b>: <a href=\"#hcAt-Emed-Journey-02-01-Md-Durchgefuehrte-Abgabe-02/contained-medication-journey-02-01-02-magistral\">Medication: form = Salbe</a></p><p><b>subject</b>: <a href=\"Patient-At-Emed-Example-Patient-01.html\">Anton Mustermann  Male, DoB: 1900-01-01 ( Social Security number: 1234010100)</a></p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-At-Emed-Example-Organization-Apo-01.html\">Organization Amadeus Apotheke</a></td></tr></table><p><b>authorizingPrescription</b>: </p><ul><li><a href=\"MedicationRequest/At-Emed-Journey-03-Mr-Geplante-Abgabe-02\">GeplanteAbgabe 1</a></li><li><a href=\"MedicationRequest/At-Emed-Journey-02-Mr-Planeintrag-02\">Planeintrag 1</a></li></ul><p><b>type</b>: <span title=\"Codes:\">FFP</span></p><p><b>quantity</b>: 0 0<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code0 = '0')</span></p><blockquote><p><b>dosageInstruction</b></p><p><b>AT ELGA e-Medikation Extension Dosierungskategorie</b>: <span title=\"Codes:{https://fhir.hl7.at/elga/emed/r4/CodeSystem/AtElgaEmedCodeSystemDosageCategory standard}\">Standard Administration</span></p><p><b>sequence</b>: 1</p><p><b>patientInstruction</b>: Nehmen Sie die Tablette vor dem Essen mit ausreichend Flüssigkeit ein.</p><p><b>timing</b>: Morning, Once per 1 day</p><p><b>route</b>: <span title=\"Codes:{https://termgit.elga.gv.at/CodeSystem/medikationartanwendung 100000073619}\">zum Einnehmen</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td> Stück<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code{Stueck} = '{Stueck}')</span></td></tr></table></blockquote><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Medication #contained-medication-journey-02-01-02-magistral</b></p><a name=\"At-Emed-Journey-02-01-Md-Durchgefuehrte-Abgabe-02/contained-medication-journey-02-01-02-magistral\"> </a><a name=\"hcAt-Emed-Journey-02-01-Md-Durchgefuehrte-Abgabe-02/contained-medication-journey-02-01-02-magistral\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-at-elga-emed-medication-medikation.html\">AT ELGA e-Medikation Medication Medikation</a></p></div><p><b>form</b>: <span title=\"Codes:{https://termgit.elga.gv.at/CodeSystem/medikationdarreichungsform 100000073713}\">Salbe</span></p><blockquote><p><b>ingredient</b></p><p><b>item</b>: <span title=\"Codes:{https://termgit.elga.gv.at/CodeSystem/atc-deutsch-wido A11HA30}\">Dexpanthenol</span></p><p><b>strength</b>: 5 g<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeg = 'g')</span>/100 g<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeg = 'g')</span></p></blockquote><blockquote><p><b>ingredient</b></p><p><b>item</b>: <span title=\"Codes:\">Salbengrundlage</span></p><p><b>isActive</b>: false</p><p><b>strength</b>: 95 g/100 g</p></blockquote></blockquote></div>"
      },
      "contained" : [{
        "resourceType" : "Medication",
        "id" : "contained-medication-journey-02-01-02-magistral",
        "meta" : {
          "profile" : ["https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-elga-emed-medication-medikation"]
        },
        "form" : {
          "coding" : [{
            "system" : "https://termgit.elga.gv.at/CodeSystem/medikationdarreichungsform",
            "code" : "100000073713",
            "display" : "Salbe"
          }]
        },
        "ingredient" : [{
          "itemCodeableConcept" : {
            "coding" : [{
              "system" : "https://termgit.elga.gv.at/CodeSystem/atc-deutsch-wido",
              "code" : "A11HA30",
              "display" : "Dexpanthenol"
            }]
          },
          "strength" : {
            "numerator" : {
              "value" : 5,
              "unit" : "g",
              "system" : "http://unitsofmeasure.org",
              "code" : "g"
            },
            "denominator" : {
              "value" : 100,
              "unit" : "g",
              "system" : "http://unitsofmeasure.org",
              "code" : "g"
            }
          }
        },
        {
          "itemCodeableConcept" : {
            "text" : "Salbengrundlage"
          },
          "isActive" : false,
          "strength" : {
            "numerator" : {
              "value" : 95,
              "unit" : "g"
            },
            "denominator" : {
              "value" : 100,
              "unit" : "g"
            }
          }
        }]
      }],
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-MedicationDispense.renderedDosageInstruction",
        "valueMarkdown" : "1-0-1-0 | Täglich 1-0-1-0"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-MedicationDispense.recorded",
        "valueDateTime" : "2026-02-28T11:00:00+00:00"
      },
      {
        "url" : "https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-elga-emed-extension-group-identifier",
        "valueIdentifier" : {
          "value" : "WYE82A2G8EEW"
        }
      }],
      "status" : "completed",
      "medicationReference" : {
        "reference" : "#contained-medication-journey-02-01-02-magistral"
      },
      "subject" : {
        "reference" : "Patient/At-Emed-Example-Patient-01"
      },
      "performer" : [{
        "actor" : {
          "reference" : "Organization/At-Emed-Example-Organization-Apo-01"
        }
      }],
      "authorizingPrescription" : [{
        "reference" : "MedicationRequest/At-Emed-Journey-03-Mr-Geplante-Abgabe-02",
        "display" : "GeplanteAbgabe 1"
      },
      {
        "reference" : "MedicationRequest/At-Emed-Journey-02-Mr-Planeintrag-02",
        "display" : "Planeintrag 1"
      }],
      "type" : {
        "coding" : [{
          "code" : "FFP"
        }]
      },
      "quantity" : {
        "value" : 0,
        "system" : "http://unitsofmeasure.org",
        "code" : "0"
      },
      "dosageInstruction" : [{
        "extension" : [{
          "url" : "https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-elga-emed-extension-dosage-category",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://fhir.hl7.at/elga/emed/r4/CodeSystem/AtElgaEmedCodeSystemDosageCategory",
              "code" : "standard"
            }]
          }
        }],
        "sequence" : 1,
        "patientInstruction" : "Nehmen Sie die Tablette vor dem Essen mit ausreichend Flüssigkeit ein.",
        "timing" : {
          "repeat" : {
            "frequency" : 1,
            "period" : 1,
            "periodUnit" : "d",
            "when" : ["MORN"]
          }
        },
        "route" : {
          "coding" : [{
            "system" : "https://termgit.elga.gv.at/CodeSystem/medikationartanwendung",
            "code" : "100000073619",
            "display" : "zum Einnehmen"
          }]
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "unit" : "Stück",
            "system" : "http://unitsofmeasure.org",
            "code" : "{Stueck}"
          }
        }]
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "MedicationDispense"
    }
  }]
}

```
