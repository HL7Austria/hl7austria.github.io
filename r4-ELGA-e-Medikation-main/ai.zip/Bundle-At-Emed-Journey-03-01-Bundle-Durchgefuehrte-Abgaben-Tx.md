# HL7.AT.FHIR.ELGA.EMED.R4\Beispiel Journey 03-01: Transaction Bundle - FHIR® v4.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Beispiel Journey 03-01: Transaction Bundle**

## Example Bundle: Beispiel Journey 03-01: Transaction Bundle



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "At-Emed-Journey-03-01-Bundle-Durchgefuehrte-Abgaben-Tx",
  "meta" : {
    "profile" : ["https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-elga-emed-bundle-durchgefuehrteabgaben-tx"]
  },
  "type" : "transaction",
  "timestamp" : "2026-03-01T15:15:00+00:00",
  "entry" : [{
    "fullUrl" : "urn:uuid:3126a1c8-d139-4763-9bda-5ac61a0cd378",
    "resource" : {
      "resourceType" : "MedicationDispense",
      "id" : "At-Emed-Journey-03-01-Md-Durchgefuehrte-Abgabe-02",
      "meta" : {
        "profile" : ["https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-elga-emed-medicationdispense-durchgefuehrteabgabe"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationDispense_At-Emed-Journey-03-01-Md-Durchgefuehrte-Abgabe-02\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationDispense At-Emed-Journey-03-01-Md-Durchgefuehrte-Abgabe-02</b></p><a name=\"At-Emed-Journey-03-01-Md-Durchgefuehrte-Abgabe-02\"> </a><a name=\"hcAt-Emed-Journey-03-01-Md-Durchgefuehrte-Abgabe-02\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-at-elga-emed-medicationdispense-durchgefuehrteabgabe.html\">AT ELGA e-Medikation MedicationDispense Durchgeführte Abgabe</a></p></div><p><b>R5: Full representation of the dosage instructions (new)</b>: </p><div><p>1-0-1-0 | Täglich 1-0-1-0</p>\n</div><p><b>R5: When the recording of the dispense started (new)</b>: 2026-03-01 15:15:00+0000</p><p><b>AT ELGA e-Medikation Extension Group Identifier</b>: WYE82A2G8EEW</p><p><b>status</b>: Completed</p><p><b>medication</b>: <a href=\"#hcAt-Emed-Journey-03-01-Md-Durchgefuehrte-Abgabe-02/contained-medication-journey-03-01-02-magistral\">Medication: form = Salbe</a></p><p><b>subject</b>: <a href=\"Patient-At-Emed-Example-Patient-01.html\">Anton Mustermann</a></p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-At-Emed-Example-Organization-02.html\">Amadeus Apotheke</a></td></tr></table><p><b>authorizingPrescription</b>: </p><ul><li><a href=\"MedicationRequest-At-Emed-Journey-01-03-Mr-Geplante-Abgabe-02.html\">Geplante Abgabe 2</a></li><li><a href=\"MedicationRequest-At-Emed-Journey-01-02-Mr-Planeintrag-02.html\">Planeintrag 2</a></li></ul><p><b>type</b>: <span title=\"Codes:\">FFC</span></p><p><b>quantity</b>: 1 1<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code1 = '1')</span></p><p><b>whenHandedOver</b>: 2026-03-01 15:15:00+0000</p><blockquote><p><b>dosageInstruction</b></p><p><b>AT ELGA e-Medikation Extension Dosierungskategorie</b>: <span title=\"Codes:{https://fhir.hl7.at/elga/emed/r4/CodeSystem/AtElgaEmedCodeSystemDosageCategory standard}\">Standard Administration</span></p><p><b>sequence</b>: 1</p><p><b>patientInstruction</b>: Nehmen Sie die Tablette vor dem Essen mit ausreichend Flüssigkeit ein.</p><p><b>timing</b>: Morning, Once per 1 day</p><p><b>route</b>: <span title=\"Codes:{https://termgit.elga.gv.at/CodeSystem/medikationartanwendung 100000073619}\">zum Einnehmen</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td> Stück<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code{Stueck} = '{Stueck}')</span></td></tr></table></blockquote><hr/><blockquote><p class=\"res-header-id\"><b>Generated Narrative: Medication #contained-medication-journey-03-01-02-magistral</b></p><a name=\"At-Emed-Journey-03-01-Md-Durchgefuehrte-Abgabe-02/contained-medication-journey-03-01-02-magistral\"> </a><a name=\"hcAt-Emed-Journey-03-01-Md-Durchgefuehrte-Abgabe-02/contained-medication-journey-03-01-02-magistral\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-at-elga-emed-medication-magistrale-zubereitung.html\">AT ELGA e-Medikation Medication Magistrale Medikation</a></p></div><p><b>form</b>: <span title=\"Codes:{https://termgit.elga.gv.at/CodeSystem/medikationdarreichungsform 100000073713}\">Salbe</span></p><blockquote><p><b>ingredient</b></p><p><b>item</b>: <span title=\"Codes:{https://termgit.elga.gv.at/CodeSystem/atc-deutsch-wido A11HA30}\">Dexpanthenol</span></p><p><b>strength</b>: 5 g<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeg = 'g')</span>/100 g<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeg = 'g')</span></p></blockquote><blockquote><p><b>ingredient</b></p><p><b>item</b>: <span title=\"Codes:\">Salbengrundlage</span></p><p><b>isActive</b>: false</p><p><b>strength</b>: 95 g/100 g</p></blockquote></blockquote></div>"
      },
      "contained" : [{
        "resourceType" : "Medication",
        "id" : "contained-medication-journey-03-01-02-magistral",
        "meta" : {
          "profile" : ["https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-elga-emed-medication-magistrale-zubereitung"]
        },
        "form" : {
          "coding" : [{
            "system" : "https://termgit.elga.gv.at/CodeSystem/medikationdarreichungsform",
            "code" : "100000073713",
            "display" : "Salbe"
          }]
        },
        "ingredient" : [{
          "itemCodeableConcept" : {
            "coding" : [{
              "system" : "https://termgit.elga.gv.at/CodeSystem/atc-deutsch-wido",
              "code" : "A11HA30",
              "display" : "Dexpanthenol"
            }]
          },
          "strength" : {
            "numerator" : {
              "value" : 5,
              "unit" : "g",
              "system" : "http://unitsofmeasure.org",
              "code" : "g"
            },
            "denominator" : {
              "value" : 100,
              "unit" : "g",
              "system" : "http://unitsofmeasure.org",
              "code" : "g"
            }
          }
        },
        {
          "itemCodeableConcept" : {
            "text" : "Salbengrundlage"
          },
          "isActive" : false,
          "strength" : {
            "numerator" : {
              "value" : 95,
              "unit" : "g"
            },
            "denominator" : {
              "value" : 100,
              "unit" : "g"
            }
          }
        }]
      }],
      "extension" : [{
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-MedicationDispense.renderedDosageInstruction",
        "valueMarkdown" : "1-0-1-0 | Täglich 1-0-1-0"
      },
      {
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-MedicationDispense.recorded",
        "valueDateTime" : "2026-03-01T15:15:00+00:00"
      },
      {
        "url" : "https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-elga-emed-extension-group-identifier",
        "valueIdentifier" : {
          "value" : "WYE82A2G8EEW"
        }
      }],
      "status" : "completed",
      "medicationReference" : {
        "reference" : "#contained-medication-journey-03-01-02-magistral"
      },
      "subject" : {
        "reference" : "Patient/At-Emed-Example-Patient-01",
        "display" : "Anton Mustermann"
      },
      "performer" : [{
        "actor" : {
          "reference" : "Organization/At-Emed-Example-Organization-02",
          "display" : "Amadeus Apotheke"
        }
      }],
      "authorizingPrescription" : [{
        "reference" : "MedicationRequest/At-Emed-Journey-01-03-Mr-Geplante-Abgabe-02",
        "display" : "Geplante Abgabe 2"
      },
      {
        "reference" : "MedicationRequest/At-Emed-Journey-01-02-Mr-Planeintrag-02",
        "display" : "Planeintrag 2"
      }],
      "type" : {
        "coding" : [{
          "code" : "FFC"
        }]
      },
      "quantity" : {
        "value" : 1,
        "system" : "http://unitsofmeasure.org",
        "code" : "1"
      },
      "whenHandedOver" : "2026-03-01T15:15:00+00:00",
      "dosageInstruction" : [{
        "extension" : [{
          "url" : "https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-elga-emed-extension-dosage-category",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://fhir.hl7.at/elga/emed/r4/CodeSystem/AtElgaEmedCodeSystemDosageCategory",
              "code" : "standard"
            }]
          }
        }],
        "sequence" : 1,
        "patientInstruction" : "Nehmen Sie die Tablette vor dem Essen mit ausreichend Flüssigkeit ein.",
        "timing" : {
          "repeat" : {
            "frequency" : 1,
            "period" : 1,
            "periodUnit" : "d",
            "when" : ["MORN"]
          }
        },
        "route" : {
          "coding" : [{
            "system" : "https://termgit.elga.gv.at/CodeSystem/medikationartanwendung",
            "code" : "100000073619",
            "display" : "zum Einnehmen"
          }]
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "unit" : "Stück",
            "system" : "http://unitsofmeasure.org",
            "code" : "{Stueck}"
          }
        }]
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "MedicationDispense"
    }
  }]
}

```
