# hl7.at.fhir.elga.emed.r4#0.1.1: ELGA e-Medikation (R4) DRAFT

## Pages

* [HL7.AT.FHIR.ELGA.EMED.R4\Home - FHIR® v4.0.1](index.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Hintergrund - FHIR® v4.0.1](background.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Herausforderungen - FHIR® v4.0.1](challenges.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Patient Journey - FHIR® v4.0.1](patient_journey.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\​Technische Use Cases für Durchgeführte Abgaben lesen (UC_eMed_07) - FHIR® v4.0.1](Sub_UC_eMed_07_02.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\​Technische Use Cases für Geplante Abgabe schreiben (UC_eMed_08) - FHIR® v4.0.1](Sub_UC_eMed_08.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Akteure - FHIR® v4.0.1](actors.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\​Technische Use Cases für Durchgeführte Abgabe schreiben (UC_eMed_09) - FHIR® v4.0.1](Sub_UC_eMed_09.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\​Technische Use Cases für Medikationsplan schreiben (UC_eMed_06) - FHIR® v4.0.1](Sub_UC_eMed_06.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Designentscheidungen - FHIR® v4.0.1](design_choices.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Artifacts Summary - FHIR® v4.0.1](artifacts.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\​Technische Use Cases für Geplante Abgaben lesen (UC_eMed_07) - FHIR® v4.0.1](Sub_UC_eMed_07_01.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Workflowmanagement - FHIR® v4.0.1](workflowmanagement.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Umfang und Inhalt - FHIR® v4.0.1](scope_and_content.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Overview Use Case - FHIR® v4.0.1](overview_use_case.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Technische Use Cases - FHIR® v4.0.1](overview_sub_use_case.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\​Technische Use Cases für Medikationsplan lesen (UC_eMed_05) - FHIR® v4.0.1](Sub_UC_eMed_05.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Transaktionen - FHIR® v4.0.1](interactions.md)

## Resources

### CodeSystems

* [ELGA List.entry.flag CodeSystem](CodeSystem-ElgaListEntryFlagCS.md)
* [ELGA e-Med MedicationRequest Kategorie CodeSystem](CodeSystem-MedicationRequestCategoryCS.md)

### ValueSets

* [ELGA e-Med Durchgeführte Abgabe Status Value Set](ValueSet-DurchgefuehrteAbgabeStatusVS.md)
* [ELGA e-Med Durchgeführte Abgabe Typ Value Set](ValueSet-DurchgefuehrteAbgabeTypVS.md)
* [ELGA List Empty Reason Value Set](ValueSet-ElgaListEmptyReasonVS.md)
* [ELGA List.entry.flag Value Set](ValueSet-ElgaListEntryFlagVS.md)
* [ELGA List Status ValueSet](ValueSet-ElgaListStatusVS.md)
* [ELGA e-Med Geplante Abgabe Status ValueSet](ValueSet-GeplanteAbgabeStatusVS.md)
* [ELGA e-Med MedicationRequest Kategorie ValueSet](ValueSet-MedicationRequestCategoryVS.md)
* [ELGA e-Med Medikationsplaneintrag Status Value Set](ValueSet-MedikationsplaneintragStatusVS.md)

### Complex-type Profiles

* [AT ELGA e-Medikation Dosage Dosierung](StructureDefinition-at-elga-emed-dosage-dosierung.md)
* [AT ELGA e-Medikation Timing](StructureDefinition-at-elga-emed-timing.md)

### Resource Profiles

* [AT ELGA e-Medikation Collection Bundle Medikationsplan](StructureDefinition-at-elga-emed-bundle-medikationsplan.md)
* [AT ELGA e-Medikation Transaction Bundle Medikationsplan](StructureDefinition-at-elga-emed-bundle-medikationsplantx.md)
* [AT ELGA e-Medikation List Medikationsplan](StructureDefinition-at-elga-emed-list-medikationsplan.md)
* [AT ELGA e-Medikation Medication Medikation](StructureDefinition-at-elga-emed-medication-medikation.md)
* [AT ELGA e-Medikation MedicationDispense Durchgeführte Abgabe](StructureDefinition-at-elga-emed-medicationdispense-durchgefuehrteabgabe.md)
* [At ELGA e-Medikation MedicationRequest Geplante Abgabe](StructureDefinition-at-elga-emed-medicationrequest-geplanteabgabe.md)
* [At ELGA e-Medikation MedicationRequest Planeintrag](StructureDefinition-at-elga-emed-medicationrequest-planeintrag.md)
* [At ELGA e-Medikation Substance Wirkstoff](StructureDefinition-at-elga-emed-substance-wirkstoff.md)

### ImplementationGuides

* [ELGA e-Medikation (R4) DRAFT](index.md)

### OperationDefinitions

* [e-Med Operation für Plan-Read](OperationDefinition-AtEmed.List.PlanRead.md)
* [e-Med Operation für Plan-Write](OperationDefinition-AtEmed.List.PlanWrite.md)
* [eMed Operation für GroupIdentifier-Create](OperationDefinition-at-emed-operation-groupidentifier-create.md)
* [eMed Operation für GroupIdentifier Prescription Search](OperationDefinition-at-emed-operation-groupidentifier-prescription-search.md)

### Examples

* [At-Emed-Journey-01-Bundle-Medikationsplan (Bundle)](Bundle-At-Emed-Journey-01-Bundle-Medikationsplan.md)
* [At-Emed-Journey-01-Bundle-Tx-Medikationsplan (Bundle)](Bundle-At-Emed-Journey-01-Bundle-Tx-Medikationsplan.md)
* [At-Emed-Journey-02-Bundle-Medikationsplan (Bundle)](Bundle-At-Emed-Journey-02-Bundle-Medikationsplan.md)
* [At-Emed-Journey-02-Bundle-Tx-Medikationsplan (Bundle)](Bundle-At-Emed-Journey-02-Bundle-Tx-Medikationsplan.md)
* [At-Emed-Journey-05-a-Bundle-Medikationsplan-Tx (Bundle)](Bundle-At-Emed-Journey-05-a-Bundle-Medikationsplan-Tx.md)
* [At-Emed-Journey-05-a-Bundle-Medikationsplan (Bundle)](Bundle-At-Emed-Journey-05-a-Bundle-Medikationsplan.md)
* [At-Emed-Journey-05-b-Bundle-Medikationsplan (Bundle)](Bundle-At-Emed-Journey-05-b-Bundle-Medikationsplan.md)
* [At-Emed-Journey-05-b-Bundle-Tx-Medikationsplan (Bundle)](Bundle-At-Emed-Journey-05-b-Bundle-Tx-Medikationsplan.md)
* [At-Emed-Example-Device-01 (Device)](Device-At-Emed-Example-Device-01.md)
* [At-Emed-Journey-01-List-Medikationsplan (List)](List-At-Emed-Journey-01-List-Medikationsplan.md)
* [At-Emed-Journey-02-List-Medikationsplan (List)](List-At-Emed-Journey-02-List-Medikationsplan.md)
* [At-Emed-Journey-05-a-List-Reihenfolge (List)](List-At-Emed-Journey-05-a-List-Reihenfolge.md)
* [At-Emed-Journey-05-b-List-Aenderung (List)](List-At-Emed-Journey-05-b-List-Aenderung.md)
* [At-Emed-Example-Medication-Magistral-01 (Medication)](Medication-At-Emed-Example-Medication-Magistral-01.md)
* [At-Emed-Example-Durchgefuehrte-Abgabe-01 (MedicationDispense)](MedicationDispense-At-Emed-Example-Durchgefuehrte-Abgabe-01.md)
* [At-Emed-Example-Mr-Geplante-Abgabe (MedicationRequest)](MedicationRequest-At-Emed-Example-Mr-Geplante-Abgabe.md)
* [At-Emed-Example-Mr-Planeintrag (MedicationRequest)](MedicationRequest-At-Emed-Example-Mr-Planeintrag.md)
* [At-Emed-Journey-02-Mr-Planeintrag-01 (MedicationRequest)](MedicationRequest-At-Emed-Journey-02-Mr-Planeintrag-01.md)
* [At-Emed-Journey-02-Mr-Planeintrag-02 (MedicationRequest)](MedicationRequest-At-Emed-Journey-02-Mr-Planeintrag-02.md)
* [At-Emed-Journey-03-Mr-Geplante-Abgabe (MedicationRequest)](MedicationRequest-At-Emed-Journey-03-Mr-Geplante-Abgabe.md)
* [At-Emed-Journey-05-b-Mr-Planeintrag-01 (MedicationRequest)](MedicationRequest-At-Emed-Journey-05-b-Mr-Planeintrag-01.md)
* [Amadeus Apotheke (Organization)](Organization-At-Emed-Example-Organization-Apo-01.md)
* [At-Emed-Example-Patient-01 (Patient)](Patient-At-Emed-Example-Patient-01.md)
* [At-Emed-Example-Practitioner-01 (Practitioner)](Practitioner-At-Emed-Example-Practitioner-01.md)
* [At-Emed-Example-Practitioner-02 (Practitioner)](Practitioner-At-Emed-Example-Practitioner-02.md)
* [At-Emed-Example-Substance-Clotrimazol (Substance)](Substance-At-Emed-Example-Substance-Clotrimazol.md)
* [At-Emed-Example-Substance-Hydrocortison (Substance)](Substance-At-Emed-Example-Substance-Hydrocortison.md)
