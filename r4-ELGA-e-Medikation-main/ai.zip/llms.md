# hl7.at.fhir.elga.emed.r4#0.1.1: ELGA e-Medikation (R4) ENTWURF

## Pages

* [HL7.AT.FHIR.ELGA.EMED.R4\Start - FHIR® v4.0.1](index.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Mappings - FHIR® v4.0.1](mapping.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Die "e-Medikation" - FHIR® v4.0.1](requirements.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Artifacts Summary - FHIR® v4.0.1](artifacts.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\UC_eMed_05 - Medikationsplan lesen - FHIR® v4.0.1](UC_eMed_05.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Überblick Anwendungsfälle - FHIR® v4.0.1](anwendungsfaelle.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\UC_eMed_09 - Durchgeführte Abgabe schreiben - FHIR® v4.0.1](UC_eMed_09.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\UC_eMed_06 - Medikationsplan schreiben - FHIR® v4.0.1](UC_eMed_06.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Akteure - FHIR® v4.0.1](actors.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\UC_eMed_07 - Geplante und durchgeführte Abgaben lesen - FHIR® v4.0.1](UC_eMed_07.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\UC_eMed_08 - Geplante Abgabe schreiben - FHIR® v4.0.1](UC_eMed_08.md)

## Resources

### CodeSystems

* [ELGA e-Medikation MedicationRequest Kategorie CodeSystem](CodeSystem-MedicationRequestCategoryCS.md)

### ValueSets

* [ELGA e-Medikation MedicationRequest Kategorie ValueSet](ValueSet-MedicationRequestCategoryVS.md)

### Resource Profiles

* [ELGA e-Medikation Medikationsplan](StructureDefinition-at-emed-list-medikationsplan.md)
* [ELGA e-Medikation Medication](StructureDefinition-at-emed-medication.md)
* [ELGA e-Medikation Abgabe](StructureDefinition-at-emed-medicationdispense.md)
* [ELGA e-Medikation Geplante Abgabe](StructureDefinition-at-emed-medicationrequest-geplanteAbgabe.md)
* [ELGA e-Medikation Planeintrag](StructureDefinition-at-emed-medicationrequest-planeintrag.md)

### ImplementationGuides

* [ELGA e-Medikation (R4) ENTWURF](index.md)

### Examples

* [AtEmedExampleMedikationsplan01 (List)](List-AtEmedExampleMedikationsplan01.md)
* [AtEmedExampleMedicationCefuroxime (Medication)](Medication-AtEmedExampleMedicationCefuroxime.md)
* [AtEmedExampleDurchgefuehrteAbgabe01 (MedicationDispense)](MedicationDispense-AtEmedExampleDurchgefuehrteAbgabe01.md)
* [AtEmedExampleGeplanteAbgabe01 (MedicationRequest)](MedicationRequest-AtEmedExampleGeplanteAbgabe01.md)
* [AtEmedExamplePlaneintrag01 (MedicationRequest)](MedicationRequest-AtEmedExamplePlaneintrag01.md)
* [AtEmedExamplePatient01 (Patient)](Patient-AtEmedExamplePatient01.md)
* [at-emed-example-practitioner-01 (Practitioner)](Practitioner-at-emed-example-practitioner-01.md)
