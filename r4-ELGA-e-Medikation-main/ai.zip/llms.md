# hl7.at.fhir.elga.emed.r4#0.1.1: ELGA e-Medikation (R4) ENTWURF

## Pages

* [HL7.AT.FHIR.ELGA.EMED.R4\Home - FHIR® v4.0.1](index.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Hintergrund - FHIR® v4.0.1](background.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Mappings - FHIR® v4.0.1](mapping.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Überblick & Anwendungsbeispiel - FHIR® v4.0.1](use_case_overview.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Umfang und Inhalt - FHIR® v4.0.1](scope_and_content.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Akteure - FHIR® v4.0.1](actors.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\UC_eMed_09 - Durchgeführte Abgabe schreiben - FHIR® v4.0.1](UC_eMed_09.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Designentscheidungen - FHIR® v4.0.1](design_choices.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Dosierschemata - FHIR® v4.0.1](dosaging.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\UC_eMed_05 - Medikationsplan lesen - FHIR® v4.0.1](UC_eMed_05.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Sub-Usecases zu UC_eMed_06 (Medikationsplan schreiben) - FHIR® v4.0.1](UC_eMed_06_Sub_UC.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Artifacts Summary - FHIR® v4.0.1](artifacts.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\UC_eMed_07 - Geplante und durchgeführte Abgaben lesen - FHIR® v4.0.1](UC_eMed_07.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\UC_eMed_08 - Geplante Abgabe schreiben - FHIR® v4.0.1](UC_eMed_08.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Patient Journey - FHIR® v4.0.1](patient_journey.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\UC_eMed_06 - Medikationsplan schreiben - FHIR® v4.0.1](UC_eMed_06.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Herausforderungen - FHIR® v4.0.1](challenges.md)

## Resources

### CodeSystems

* [ELGA e-Med MedicationRequest Kategorie CodeSystem](CodeSystem-MedicationRequestCategoryCS.md)

### ValueSets

* [ELGA e-Med Durchgeführte Abgabe Status Value Set](ValueSet-DurchgefuehrteAbgabeStatusVS.md)
* [ELGA e-Med Durchgeführte Abgabe Typ Value Set](ValueSet-DurchgefuehrteAbgabeTypVS.md)
* [ELGA e-Med Geplante Abgabe Status ValueSet](ValueSet-GeplanteAbgabeStatusVS.md)
* [ELGA e-Med MedicationRequest Kategorie ValueSet](ValueSet-MedicationRequestCategoryVS.md)
* [ELGA e-Med Medikationsplan Empty Reason Value Set](ValueSet-MedikationsplanEmptyReasonVS.md)
* [ELGA e-Med Medikationsplaneintrag Status Value Set](ValueSet-MedikationsplaneintragStatusVS.md)

### Complex-type Profiles

* [ELGA e-Med Dosage](StructureDefinition-at-emed-dosage.md)
* [ELGA e-Med Timing](StructureDefinition-at-emed-timing.md)

### Resource Profiles

* [ELGA e-Med Medikationsplan Collection Bundle](StructureDefinition-at-emed-bundle-medikationsplan.md)
* [ELGA e-Med Medikationsplan Transaction Bundle](StructureDefinition-at-emed-bundle-tx-medikationsplan.md)
* [ELGA e-Med Medikationsplan](StructureDefinition-at-emed-list-medikationsplan.md)
* [ELGA e-Med Durchgeführte Abgabe](StructureDefinition-at-emed-md-durchgefuehrte-abgabe.md)
* [ELGA e-Med Medikation](StructureDefinition-at-emed-medication.md)
* [ELGA e-Med Geplante Abgabe](StructureDefinition-at-emed-mr-geplante-abgabe.md)
* [ELGA e-Med Planeintrag](StructureDefinition-at-emed-mr-planeintrag.md)
* [ELGA e-Med Substanz](StructureDefinition-at-emed-substance.md)

### ImplementationGuides

* [ELGA e-Medikation (R4) ENTWURF](index.md)

### OperationDefinitions

* [e-Med Operation für Read-to-write](OperationDefinition-AtEmed.List.Readtowrite.md)
* [e-Med Operation für Write des Medikationsplans](OperationDefinition-AtEmed.List.Write.md)

### Examples

* [At-Emed-Example-Bundle-Medikationsplan-Dosierungsvarianten (Bundle)](Bundle-At-Emed-Example-Bundle-Medikationsplan-Dosierungsvarianten.md)
* [At-Emed-Example-Bundle-Tx-Medikationsplan-Dosierungsvarianten (Bundle)](Bundle-At-Emed-Example-Bundle-Tx-Medikationsplan-Dosierungsvarianten.md)
* [At-Emed-Journey-01-Bundle-Medikationsplan (Bundle)](Bundle-At-Emed-Journey-01-Bundle-Medikationsplan.md)
* [At-Emed-Journey-01-Bundle-Tx-Medikationsplan (Bundle)](Bundle-At-Emed-Journey-01-Bundle-Tx-Medikationsplan.md)
* [At-Emed-Journey-02-Bundle-Medikationsplan (Bundle)](Bundle-At-Emed-Journey-02-Bundle-Medikationsplan.md)
* [At-Emed-Journey-02-Bundle-Tx-Medikationsplan (Bundle)](Bundle-At-Emed-Journey-02-Bundle-Tx-Medikationsplan.md)
* [At-Emed-Journey-05-a-Bundle-Medikationsplan-Tx (Bundle)](Bundle-At-Emed-Journey-05-a-Bundle-Medikationsplan-Tx.md)
* [At-Emed-Journey-05-a-Bundle-Medikationsplan (Bundle)](Bundle-At-Emed-Journey-05-a-Bundle-Medikationsplan.md)
* [At-Emed-Journey-05-b-Bundle-Medikationsplan (Bundle)](Bundle-At-Emed-Journey-05-b-Bundle-Medikationsplan.md)
* [At-Emed-Journey-05-b-Bundle-Tx-Medikationsplan (Bundle)](Bundle-At-Emed-Journey-05-b-Bundle-Tx-Medikationsplan.md)
* [At-Emed-Example-Device-01 (Device)](Device-At-Emed-Example-Device-01.md)
* [At-Emed-Example-List-Medikationsplan-Dosierungsvarianten (List)](List-At-Emed-Example-List-Medikationsplan-Dosierungsvarianten.md)
* [At-Emed-Journey-01-List-Medikationsplan (List)](List-At-Emed-Journey-01-List-Medikationsplan.md)
* [At-Emed-Journey-02-List-Medikationsplan (List)](List-At-Emed-Journey-02-List-Medikationsplan.md)
* [At-Emed-Journey-05-a-List-Reihenfolge (List)](List-At-Emed-Journey-05-a-List-Reihenfolge.md)
* [At-Emed-Journey-05-b-List-Aenderung (List)](List-At-Emed-Journey-05-b-List-Aenderung.md)
* [At-Emed-Example-Medication-Magistral-01 (Medication)](Medication-At-Emed-Example-Medication-Magistral-01.md)
* [At-Emed-Example-Durchgefuehrte-Abgabe-01 (MedicationDispense)](MedicationDispense-At-Emed-Example-Durchgefuehrte-Abgabe-01.md)
* [At-Emed-Example-Mr-Dosierung-1010 (MedicationRequest)](MedicationRequest-At-Emed-Example-Mr-Dosierung-1010.md)
* [At-Emed-Example-Mr-Dosierung-Freitext (MedicationRequest)](MedicationRequest-At-Emed-Example-Mr-Dosierung-Freitext.md)
* [At-Emed-Example-Mr-Dosierung-Intervalle-Wh (MedicationRequest)](MedicationRequest-At-Emed-Example-Mr-Dosierung-Intervalle-Wh.md)
* [At-Emed-Example-Mr-Dosierung-Wochentag-Kombi (MedicationRequest)](MedicationRequest-At-Emed-Example-Mr-Dosierung-Wochentag-Kombi.md)
* [At-Emed-Example-Mr-Dosierung-Wochentag (MedicationRequest)](MedicationRequest-At-Emed-Example-Mr-Dosierung-Wochentag.md)
* [At-Emed-Example-Mr-Dosierung-Zeit-1tg (MedicationRequest)](MedicationRequest-At-Emed-Example-Mr-Dosierung-Zeit-1tg.md)
* [At-Emed-Example-Mr-Dosierung-Zeitintervalle-Kombi (MedicationRequest)](MedicationRequest-At-Emed-Example-Mr-Dosierung-Zeitintervalle-Kombi.md)
* [At-Emed-Example-Mr-Geplante-Abgabe (MedicationRequest)](MedicationRequest-At-Emed-Example-Mr-Geplante-Abgabe.md)
* [At-Emed-Example-Mr-Planeintrag (MedicationRequest)](MedicationRequest-At-Emed-Example-Mr-Planeintrag.md)
* [At-Emed-Journey-02-Mr-Planeintrag-01 (MedicationRequest)](MedicationRequest-At-Emed-Journey-02-Mr-Planeintrag-01.md)
* [At-Emed-Journey-02-Mr-Planeintrag-02 (MedicationRequest)](MedicationRequest-At-Emed-Journey-02-Mr-Planeintrag-02.md)
* [At-Emed-Journey-03-Mr-Geplante-Abgabe (MedicationRequest)](MedicationRequest-At-Emed-Journey-03-Mr-Geplante-Abgabe.md)
* [At-Emed-Journey-05-b-Mr-Planeintrag-01 (MedicationRequest)](MedicationRequest-At-Emed-Journey-05-b-Mr-Planeintrag-01.md)
* [Amadeus Apotheke (Organization)](Organization-At-Emed-Example-Organization-Apo-01.md)
* [At-Emed-Example-Patient-01 (Patient)](Patient-At-Emed-Example-Patient-01.md)
* [At-Emed-Example-Practitioner-01 (Practitioner)](Practitioner-At-Emed-Example-Practitioner-01.md)
* [At-Emed-Example-Practitioner-02 (Practitioner)](Practitioner-At-Emed-Example-Practitioner-02.md)
* [At-Emed-Example-Substance-Clotrimazol (Substance)](Substance-At-Emed-Example-Substance-Clotrimazol.md)
* [At-Emed-Example-Substance-Hydrocortison (Substance)](Substance-At-Emed-Example-Substance-Hydrocortison.md)
