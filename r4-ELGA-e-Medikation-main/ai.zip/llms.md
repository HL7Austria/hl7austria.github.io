# hl7.at.fhir.elga.emed.r4#0.1.1: ELGA e-Medikation (R4)

## Pages

* [HL7.AT.FHIR.ELGA.EMED.R4\Start - FHIR® v4.0.1](index.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Mappings - FHIR® v4.0.1](mapping.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Die "e-Medikation" - FHIR® v4.0.1](requirements.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Artifacts Summary - FHIR® v4.0.1](artifacts.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Überblick Anwendungsfälle - FHIR® v4.0.1](anwendungsfaelle.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\UC_DiMe_05 - Medikationsplan lesen - FHIR® v4.0.1](UC_DiMe_05.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Akteure - FHIR® v4.0.1](actors.md)

## Resources

### Resource Profiles

* [MyPatient](StructureDefinition-MyPatient.md)

### ImplementationGuides

* [ELGA e-Medikation (R4)](index.md)

### Examples

* [PatientExample (Patient)](Patient-PatientExample.md)
