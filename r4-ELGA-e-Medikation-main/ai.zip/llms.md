# hl7.at.fhir.elga.emed.r4#0.1.1: ELGA e-Medikation (R4) ENTWURF

## Pages

* [HL7.AT.FHIR.ELGA.EMED.R4\Start - FHIR® v4.0.1](index.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Mappings - FHIR® v4.0.1](mapping.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Die "e-Medikation" - FHIR® v4.0.1](requirements.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Artifacts Summary - FHIR® v4.0.1](artifacts.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\UC_eMed_05 - Medikationsplan lesen - FHIR® v4.0.1](UC_eMed_05.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Überblick Anwendungsfälle - FHIR® v4.0.1](anwendungsfaelle.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\UC_eMed_09 - Durchgeführte Abgabe schreiben - FHIR® v4.0.1](UC_eMed_09.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\UC_eMed_06 - Medikationsplan schreiben - FHIR® v4.0.1](UC_eMed_06.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\Akteure - FHIR® v4.0.1](actors.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\UC_eMed_07 - Geplante und durchgeführte Abgaben lesen - FHIR® v4.0.1](UC_eMed_07.md)
* [HL7.AT.FHIR.ELGA.EMED.R4\UC_eMed_08 - Geplante Abgabe schreiben - FHIR® v4.0.1](UC_eMed_08.md)

## Resources

### CodeSystems

* [ELGA e-Med MedicationRequest Kategorie CodeSystem](CodeSystem-MedicationRequestCategoryCS.md)

### ValueSets

* [ELGA e-Med MedicationRequest Kategorie ValueSet](ValueSet-MedicationRequestCategoryVS.md)

### Resource Profiles

* [ELGA e-Med Medikationsplan Collection Bundle](StructureDefinition-at-emed-bundle-medikationsplan.md)
* [ELGA e-Med Medikationsplan Transaction Bundle](StructureDefinition-at-emed-bundle-tx-medikationsplan.md)
* [ELGA e-Med Medikationsplan](StructureDefinition-at-emed-list-medikationsplan.md)
* [ELGA e-Med Durchgeführte Abgabe](StructureDefinition-at-emed-md-durchgefuehrte-abgabe.md)
* [ELGA e-Med Medikation](StructureDefinition-at-emed-medication.md)
* [ELGA e-Med Geplante Abgabe](StructureDefinition-at-emed-mr-geplante-abgabe.md)
* [ELGA e-Med Planeintrag](StructureDefinition-at-emed-mr-planeintrag.md)

### ImplementationGuides

* [ELGA e-Medikation (R4) ENTWURF](index.md)

### Examples

* [AtEmedJourneyBundleMedikationsplan01 (Bundle)](Bundle-AtEmedJourneyBundleMedikationsplan01.md)
* [AtEmedJourneyBundleMedikationsplan02 (Bundle)](Bundle-AtEmedJourneyBundleMedikationsplan02.md)
* [AtEmedJourneyBundleMedikationsplanTx01 (Bundle)](Bundle-AtEmedJourneyBundleMedikationsplanTx01.md)
* [AtEmedJourneyBundleMedikationsplanTx02 (Bundle)](Bundle-AtEmedJourneyBundleMedikationsplanTx02.md)
* [AtEmedJourneyListMedikationsplan01 (List)](List-AtEmedJourneyListMedikationsplan01.md)
* [AtEmedJourneyListMedikationsplan02 (List)](List-AtEmedJourneyListMedikationsplan02.md)
* [AtEmedJourneyMedicationMagistral02 (Medication)](Medication-AtEmedJourneyMedicationMagistral02.md)
* [AtEmedExampleDurchgefuehrteAbgabe01 (MedicationDispense)](MedicationDispense-AtEmedExampleDurchgefuehrteAbgabe01.md)
* [AtEmedExampleGeplanteAbgabe01 (MedicationRequest)](MedicationRequest-AtEmedExampleGeplanteAbgabe01.md)
* [AtEmedJourneyMrPlaneintrag0201 (MedicationRequest)](MedicationRequest-AtEmedJourneyMrPlaneintrag0201.md)
* [AtEmedJourneyMrPlaneintrag0202 (MedicationRequest)](MedicationRequest-AtEmedJourneyMrPlaneintrag0202.md)
* [Amadeus Apotheke (Organization)](Organization-AtEmedExampleOrganizationApo01.md)
* [AtEmedExamplePatient01 (Patient)](Patient-AtEmedExamplePatient01.md)
* [AtEmedExamplePractitioner01 (Practitioner)](Practitioner-AtEmedExamplePractitioner01.md)
* [AtEmedJourneySubstanceClotrimazol (Substance)](Substance-AtEmedJourneySubstanceClotrimazol.md)
* [AtEmedJourneySubstanceHydrocortison (Substance)](Substance-AtEmedJourneySubstanceHydrocortison.md)
