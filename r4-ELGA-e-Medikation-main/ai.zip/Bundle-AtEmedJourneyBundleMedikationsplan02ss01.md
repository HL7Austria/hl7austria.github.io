# HL7.AT.FHIR.ELGA.EMED.R4\AtEmedJourneyBundleMedikationsplan02ss01 - FHIR® v4.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AtEmedJourneyBundleMedikationsplan02ss01**

## Example Bundle: AtEmedJourneyBundleMedikationsplan02ss01



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "AtEmedJourneyBundleMedikationsplan02ss01",
  "meta" : {
    "lastUpdated" : "2026-02-10T15:18:13.015+00:00"
  },
  "type" : "searchset",
  "total" : 1,
  "link" : [
    {
      "relation" : "self",
      "url" : "https://hapi.fhir.org/baseR4/List?_include=*&patient=Patient%2FAtEmedExamplePatient02ss02"
    }
  ],
  "entry" : [
    {
      "fullUrl" : "https://hapi.fhir.org/baseR4/List/AtEmedJourneyListMedikationsplan02ss02",
      "resource" : {
        "resourceType" : "List",
        "id" : "AtEmedJourneyListMedikationsplan02ss02",
        "meta" : {
          "versionId" : "3",
          "lastUpdated" : "2026-02-10T15:14:55.310+00:00",
          "source" : "#FPldqdn9bnu6I6Cf",
          "profile" : [
            "https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-emed-list-medikationsplan"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"List_AtEmedJourneyListMedikationsplan02ss02\"> </a><p class=\"res-header-id\"><b>Generated Narrative: List AtEmedJourneyListMedikationsplan02ss02</b></p><a name=\"AtEmedJourneyListMedikationsplan02ss02\"> </a><a name=\"hcAtEmedJourneyListMedikationsplan02ss02\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">version: 3; Last updated: 2026-02-10 15:14:55+0000; </p><p style=\"margin-bottom: 0px\">Information Source: #FPldqdn9bnu6I6Cf</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-at-emed-list-medikationsplan.html\">ELGA e-Med Medikationsplan</a></p></div><table class=\"clstu\"><tr><td>Date: 2026-01-28 08:00:00+0000 </td><td>Mode: Working List </td><td>Status: Current </td><td>Code: Medikationsplan </td></tr><tr><td>Subject: <a href=\"Bundle-AtEmedJourneyBundleMedikationsplan02ss01.html#Patient_AtEmedExamplePatient02ss02\">Maxima Mustermann  Male, DoB: 1900-01-01 ( Social Security number: 1234010100)</a>Source: Order: Sorted by User </td></tr></table><table class=\"grid\"><tr style=\"backgound-color: #eeeeee\"><td><b>Items</b></td><td>Date</td><td>Flag</td></tr><tr><td><a href=\"Bundle-AtEmedJourneyBundleMedikationsplan02ss01.html#MedicationRequest_AtEmedJourneyMrPlaneintrag0201ss02\">MedicationRequest: extension = 2026-01-28 --&gt; 2026-02-28,1 Kapsel täglich morgens; identifier = 4711; status = active; intent = order; category = Medikationsplaneintrag; medication[x] = EBETREXAT TBL 10MG; authoredOn = 2026-01-28 08:00:00+0000; reasonCode = Essentielle Hypertonie; note = Freitext Informationen zum Medikationsplaneintrag.</a></td><td>2026-01-28 08:00:00+0000</td><td>Prescribed</td></tr><tr><td><a href=\"Bundle-AtEmedJourneyBundleMedikationsplan02ss01.html#MedicationRequest_AtEmedJourneyMrPlaneintrag0202ss02\">MedicationRequest: extension = 2026-01-28 --&gt; 2026-02-28,1 täglich auftragen; identifier = 4712; status = active; intent = order; category = Medikationsplaneintrag; medication[x] = ASPIRIN TBL 500MG; authoredOn = 2026-01-28 08:00:00+0000; note = Freitext Informationen zum Medikationsplaneintrag.</a></td><td>2026-01-28 08:00:00+0000</td><td>Prescribed</td></tr></table></div>"
        },
        "status" : "current",
        "mode" : "working",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "736378000",
              "display" : "Medikationsplan"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/AtEmedExamplePatient02ss02"
        },
        "date" : "2026-01-28T08:00:00+00:00",
        "source" : {
          "reference" : "Practitioner/AtEmedExamplePractitioner01ss02"
        },
        "orderedBy" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/list-order",
              "code" : "user"
            }
          ]
        },
        "entry" : [
          {
            "flag" : {
              "coding" : [
                {
                  "system" : "urn:oid:1.2.36.1.2001.1001.101.104.16592",
                  "code" : "04",
                  "display" : "Prescribed"
                }
              ]
            },
            "date" : "2026-01-28T08:00:00+00:00",
            "item" : {
              "reference" : "MedicationRequest/AtEmedJourneyMrPlaneintrag0201ss02"
            }
          },
          {
            "flag" : {
              "coding" : [
                {
                  "system" : "urn:oid:1.2.36.1.2001.1001.101.104.16592",
                  "code" : "04",
                  "display" : "Prescribed"
                }
              ]
            },
            "date" : "2026-01-28T08:00:00+00:00",
            "item" : {
              "reference" : "MedicationRequest/AtEmedJourneyMrPlaneintrag0202ss02"
            }
          }
        ]
      },
      "search" : {
        "mode" : "match"
      }
    },
    {
      "fullUrl" : "https://hapi.fhir.org/baseR4/MedicationRequest/AtEmedJourneyMrPlaneintrag0202ss02",
      "resource" : {
        "resourceType" : "MedicationRequest",
        "id" : "AtEmedJourneyMrPlaneintrag0202ss02",
        "meta" : {
          "versionId" : "2",
          "lastUpdated" : "2026-02-10T15:14:55.310+00:00",
          "source" : "#FPldqdn9bnu6I6Cf",
          "profile" : [
            "https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-emed-mr-planeintrag"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_AtEmedJourneyMrPlaneintrag0202ss02\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationRequest AtEmedJourneyMrPlaneintrag0202ss02</b></p><a name=\"AtEmedJourneyMrPlaneintrag0202ss02\"> </a><a name=\"hcAtEmedJourneyMrPlaneintrag0202ss02\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">version: 2; Last updated: 2026-02-10 15:14:55+0000; </p><p style=\"margin-bottom: 0px\">Information Source: #FPldqdn9bnu6I6Cf</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-at-emed-mr-planeintrag.html\">ELGA e-Med Planeintrag</a></p></div><p><b>Extension Definition for MedicationRequest.effectiveDosePeriod for Version 5.0</b>: 2026-01-28 --&gt; 2026-02-28</p><p><b>Extension Definition for MedicationRequest.renderedDosageInstruction for Version 5.0</b>: </p><div><p>1 täglich auftragen</p>\n</div><p><b>identifier</b>: 4712</p><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>category</b>: <span title=\"Codes:{https://fhir.hl7.at/elga/emed/r4/CodeSystem/MedicationRequestCategoryCS 1}\">Medikationsplaneintrag</span></p><p><b>medication</b>: <span title=\"Codes:{https://termgit.elga.gv.at/CodeSystem/asp-liste 0004340}\">ASPIRIN TBL 500MG</span></p><p><b>subject</b>: <a href=\"Bundle-AtEmedJourneyBundleMedikationsplan02ss01.html#Patient_AtEmedExamplePatient02ss02\">Maxima Mustermann  Male, DoB: 1900-01-01 ( Social Security number: 1234010100)</a></p><p><b>authoredOn</b>: 2026-01-28 08:00:00+0000</p><p><b>requester</b>: <a href=\"Bundle-AtEmedJourneyBundleMedikationsplan02ss01.html#Practitioner_AtEmedExamplePractitioner01ss02\">Practitioner Melanie Musterärztin </a></p><p><b>note</b>: </p><blockquote><div><p>Freitext Informationen zum Medikationsplaneintrag.</p>\n</div></blockquote><h3>DosageInstructions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Text</b></td><td><b>PatientInstruction</b></td><td><b>Timing</b></td><td><b>Route</b></td></tr><tr><td style=\"display: none\">*</td><td>1 täglich auftragen</td><td>Abends sehr dünn auf die betroffene Stelle auftragen.</td><td>Once per 1 day</td><td><span title=\"Codes:{https://termgit.elga.gv.at/CodeSystem-medikationartanwendung.html 100000073566}\">Anwendung auf der Haut</span></td></tr></table></div>"
        },
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-MedicationRequest.effectiveDosePeriod",
            "valuePeriod" : {
              "start" : "2026-01-28",
              "end" : "2026-02-28"
            }
          },
          {
            "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-MedicationRequest.renderedDosageInstruction",
            "valueMarkdown" : "1 täglich auftragen"
          }
        ],
        "identifier" : [
          {
            "value" : "4712"
          }
        ],
        "status" : "active",
        "intent" : "order",
        "category" : [
          {
            "coding" : [
              {
                "system" : "https://fhir.hl7.at/elga/emed/r4/CodeSystem/MedicationRequestCategoryCS",
                "code" : "1"
              }
            ]
          }
        ],
        "medicationCodeableConcept" : {
          "coding" : [
            {
              "system" : "https://termgit.elga.gv.at/CodeSystem/asp-liste",
              "code" : "0004340",
              "display" : "ASPIRIN TBL 500MG"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/AtEmedExamplePatient02ss02"
        },
        "authoredOn" : "2026-01-28T08:00:00+00:00",
        "requester" : {
          "reference" : "Practitioner/AtEmedExamplePractitioner01ss02"
        },
        "note" : [
          {
            "text" : "Freitext Informationen zum Medikationsplaneintrag."
          }
        ],
        "dosageInstruction" : [
          {
            "text" : "1 täglich auftragen",
            "patientInstruction" : "Abends sehr dünn auf die betroffene Stelle auftragen.",
            "timing" : {
              "repeat" : {
                "frequency" : 1,
                "period" : 1,
                "periodUnit" : "d"
              }
            },
            "route" : {
              "coding" : [
                {
                  "system" : "https://termgit.elga.gv.at/CodeSystem-medikationartanwendung.html",
                  "code" : "100000073566",
                  "display" : "Anwendung auf der Haut"
                }
              ]
            }
          }
        ]
      },
      "search" : {
        "mode" : "include"
      }
    },
    {
      "fullUrl" : "https://hapi.fhir.org/baseR4/MedicationRequest/AtEmedJourneyMrPlaneintrag0201ss02",
      "resource" : {
        "resourceType" : "MedicationRequest",
        "id" : "AtEmedJourneyMrPlaneintrag0201ss02",
        "meta" : {
          "versionId" : "2",
          "lastUpdated" : "2026-02-10T15:14:55.310+00:00",
          "source" : "#FPldqdn9bnu6I6Cf",
          "profile" : [
            "https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-emed-mr-planeintrag"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_AtEmedJourneyMrPlaneintrag0201ss02\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationRequest AtEmedJourneyMrPlaneintrag0201ss02</b></p><a name=\"AtEmedJourneyMrPlaneintrag0201ss02\"> </a><a name=\"hcAtEmedJourneyMrPlaneintrag0201ss02\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">version: 2; Last updated: 2026-02-10 15:14:55+0000; </p><p style=\"margin-bottom: 0px\">Information Source: #FPldqdn9bnu6I6Cf</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-at-emed-mr-planeintrag.html\">ELGA e-Med Planeintrag</a></p></div><p><b>Extension Definition for MedicationRequest.effectiveDosePeriod for Version 5.0</b>: 2026-01-28 --&gt; 2026-02-28</p><p><b>Extension Definition for MedicationRequest.renderedDosageInstruction for Version 5.0</b>: </p><div><p>1 Kapsel täglich morgens</p>\n</div><p><b>identifier</b>: 4711</p><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>category</b>: <span title=\"Codes:{https://fhir.hl7.at/elga/emed/r4/CodeSystem/MedicationRequestCategoryCS 1}\">Medikationsplaneintrag</span></p><p><b>medication</b>: <span title=\"Codes:{https://termgit.elga.gv.at/CodeSystem/asp-liste 2443061}\">EBETREXAT TBL 10MG</span></p><p><b>subject</b>: <a href=\"Bundle-AtEmedJourneyBundleMedikationsplan02ss01.html#Patient_AtEmedExamplePatient02ss02\">Maxima Mustermann  Male, DoB: 1900-01-01 ( Social Security number: 1234010100)</a></p><p><b>authoredOn</b>: 2026-01-28 08:00:00+0000</p><p><b>requester</b>: <a href=\"Bundle-AtEmedJourneyBundleMedikationsplan02ss01.html#Practitioner_AtEmedExamplePractitioner01ss02\">Practitioner Melanie Musterärztin </a></p><p><b>reasonCode</b>: <span title=\"Codes:{http://snomed.info/sct 59621000}\">Essentielle Hypertonie</span></p><p><b>note</b>: </p><blockquote><div><p>Freitext Informationen zum Medikationsplaneintrag.</p>\n</div></blockquote><blockquote><p><b>dosageInstruction</b></p><p><b>text</b>: 1 Kapsel täglich morgens</p><p><b>patientInstruction</b>: Nehmen Sie die Kapsel jeden Morgen mit ausreichend Flüssigkeit ein.</p><p><b>timing</b>: Once per 1 day</p><p><b>route</b>: <span title=\"Codes:{https://termgit.elga.gv.at/CodeSystem-medikationartanwendung.html 100000073619}\">zum Einnehmen</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>5 mg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg = 'mg')</span></td></tr></table></blockquote></div>"
        },
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-MedicationRequest.effectiveDosePeriod",
            "valuePeriod" : {
              "start" : "2026-01-28",
              "end" : "2026-02-28"
            }
          },
          {
            "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-MedicationRequest.renderedDosageInstruction",
            "valueMarkdown" : "1 Kapsel täglich morgens"
          }
        ],
        "identifier" : [
          {
            "value" : "4711"
          }
        ],
        "status" : "active",
        "intent" : "order",
        "category" : [
          {
            "coding" : [
              {
                "system" : "https://fhir.hl7.at/elga/emed/r4/CodeSystem/MedicationRequestCategoryCS",
                "code" : "1"
              }
            ]
          }
        ],
        "medicationCodeableConcept" : {
          "coding" : [
            {
              "system" : "https://termgit.elga.gv.at/CodeSystem/asp-liste",
              "code" : "2443061",
              "display" : "EBETREXAT TBL 10MG"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/AtEmedExamplePatient02ss02"
        },
        "authoredOn" : "2026-01-28T08:00:00+00:00",
        "requester" : {
          "reference" : "Practitioner/AtEmedExamplePractitioner01ss02"
        },
        "reasonCode" : [
          {
            "coding" : [
              {
                "system" : "http://snomed.info/sct",
                "code" : "59621000",
                "display" : "Essentielle Hypertonie"
              }
            ]
          }
        ],
        "note" : [
          {
            "text" : "Freitext Informationen zum Medikationsplaneintrag."
          }
        ],
        "dosageInstruction" : [
          {
            "text" : "1 Kapsel täglich morgens",
            "patientInstruction" : "Nehmen Sie die Kapsel jeden Morgen mit ausreichend Flüssigkeit ein.",
            "timing" : {
              "repeat" : {
                "frequency" : 1,
                "period" : 1,
                "periodUnit" : "d"
              }
            },
            "route" : {
              "coding" : [
                {
                  "system" : "https://termgit.elga.gv.at/CodeSystem-medikationartanwendung.html",
                  "code" : "100000073619",
                  "display" : "zum Einnehmen"
                }
              ]
            },
            "doseAndRate" : [
              {
                "doseQuantity" : {
                  "value" : 5,
                  "unit" : "mg",
                  "system" : "http://unitsofmeasure.org",
                  "code" : "mg"
                }
              }
            ]
          }
        ]
      },
      "search" : {
        "mode" : "include"
      }
    },
    {
      "fullUrl" : "https://hapi.fhir.org/baseR4/Practitioner/AtEmedExamplePractitioner01ss02",
      "resource" : {
        "resourceType" : "Practitioner",
        "id" : "AtEmedExamplePractitioner01ss02",
        "meta" : {
          "versionId" : "1",
          "lastUpdated" : "2026-02-10T08:57:29.799+00:00",
          "source" : "#yUly1sggUdCSs0mz",
          "profile" : [
            "http://hl7.at/fhir/HL7ATCoreProfiles/4.0.1/StructureDefinition/at-core-practitioner"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_AtEmedExamplePractitioner01ss02\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner AtEmedExamplePractitioner01ss02</b></p><a name=\"AtEmedExamplePractitioner01ss02\"> </a><a name=\"hcAtEmedExamplePractitioner01ss02\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">version: 1; Last updated: 2026-02-10 08:57:29+0000; </p><p style=\"margin-bottom: 0px\">Information Source: #yUly1sggUdCSs0mz</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.at/fhir/HL7ATCoreProfiles/4.0.1/2.0.0/StructureDefinition-at-core-practitioner.html\">HL7® AT Core Practitioner Profile</a></p></div><p><b>identifier</b>: <a href=\"http://terminology.hl7.org/6.5.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:oid:1.2.40.0.34.99.4613.4, <code>urn:oid:1.2.40.0.10.1.4.3.2</code>/987654321</p><p><b>active</b>: true</p><p><b>name</b>: Melanie Musterärztin </p><p><b>telecom</b>: <a href=\"mailto:office@musterpraxis.at\">office@musterpraxis.at</a>, <a href=\"tel:+436500987654321\">+436500987654321</a></p><p><b>address</b>: Mozartgasse 8 Stiege 2 St. Wolfgang Salzburg 5350 AUT (work)</p><p><b>gender</b>: Female</p></div>"
        },
        "identifier" : [
          {
            "system" : "urn:ietf:rfc:3986",
            "value" : "urn:oid:1.2.40.0.34.99.4613.4",
            "assigner" : {
              "display" : "Bundesministerium für Gesundheit"
            }
          },
          {
            "system" : "urn:oid:1.2.40.0.10.1.4.3.2",
            "value" : "987654321",
            "assigner" : {
              "display" : "Dachverband der österreichischen Sozialversicherungsträger"
            }
          }
        ],
        "active" : true,
        "name" : [
          {
            "family" : "Musterärztin",
            "given" : ["Melanie"],
            "prefix" : ["Prof. Dr."]
          }
        ],
        "telecom" : [
          {
            "system" : "email",
            "value" : "office@musterpraxis.at",
            "use" : "work"
          },
          {
            "system" : "phone",
            "value" : "+436500987654321",
            "use" : "work"
          }
        ],
        "address" : [
          {
            "use" : "work",
            "type" : "both",
            "line" : ["Mozartgasse 8 Stiege 2"],
            "_line" : [
              {
                "extension" : [
                  {
                    "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
                    "valueString" : "Mozartgasse"
                  },
                  {
                    "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
                    "valueString" : "8"
                  },
                  {
                    "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-additionalLocator",
                    "valueString" : "Stiege 2"
                  },
                  {
                    "url" : "http://hl7.at/fhir/HL7ATCoreProfiles/4.0.1/StructureDefinition/at-core-ext-address-additionalInformation",
                    "valueString" : "Barrierefreier Zugang"
                  }
                ]
              }
            ],
            "city" : "St. Wolfgang",
            "state" : "Salzburg",
            "postalCode" : "5350",
            "country" : "AUT"
          }
        ],
        "gender" : "female"
      },
      "search" : {
        "mode" : "include"
      }
    },
    {
      "fullUrl" : "https://hapi.fhir.org/baseR4/Patient/AtEmedExamplePatient02ss02",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "AtEmedExamplePatient02ss02",
        "meta" : {
          "versionId" : "3",
          "lastUpdated" : "2026-02-10T15:02:49.056+00:00",
          "source" : "#qk9ph8gyzRWfK9vX",
          "profile" : [
            "http://hl7.at/fhir/HL7ATCoreProfiles/4.0.1/StructureDefinition/at-core-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_AtEmedExamplePatient02ss02\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient AtEmedExamplePatient02ss02</b></p><a name=\"AtEmedExamplePatient02ss02\"> </a><a name=\"hcAtEmedExamplePatient02ss02\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">version: 3; Last updated: 2026-02-10 15:02:49+0000; </p><p style=\"margin-bottom: 0px\">Information Source: #qk9ph8gyzRWfK9vX</p><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.at/fhir/HL7ATCoreProfiles/4.0.1/2.0.0/StructureDefinition-at-core-patient.html\">HL7® AT Core Patient Profile</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Maxima Mustermann  Male, DoB: 1900-01-01 ( Social Security number: 1234010100)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Other Ids (see the one above)\">Other Ids:</td><td colspan=\"3\"><ul><li>National unique individual identifier/GH:oeLdSEb0l+8kSdJWjOYyYmnYki0=</li><li>Patient internal identifier/0815</li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li><a href=\"mailto:office@hl7.at\">office@hl7.at</a></li><li><a href=\"tel:+436501234567890\">+436501234567890</a></li><li>Landstrasse 1 Stock 9 Tür 42 Linz Oberösterreich 4020 AUT (home)</li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"The patient's legal status as citizen of a country.\">Patient Citizenship:</td><td colspan=\"3\"><ul><li>code: <span title=\"Codes:{https://termgit.elga.gv.at/CodeSystem/iso-3166-1-alpha-3 AUT}\">Österreich</span></li></ul></td></tr></table></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "code",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://termgit.elga.gv.at/CodeSystem/hl7-at-religionaustria",
                      "code" : "162",
                      "display" : "Pastafarianismus"
                    }
                  ]
                }
              }
            ],
            "url" : "http://hl7.at/fhir/HL7ATCoreProfiles/5.0.0/StructureDefinition/at-core-ext-patient-religion"
          },
          {
            "extension" : [
              {
                "url" : "code",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "https://termgit.elga.gv.at/CodeSystem/iso-3166-1-alpha-3",
                      "code" : "AUT",
                      "display" : "Österreich"
                    }
                  ]
                }
              }
            ],
            "url" : "http://hl7.org/fhir/StructureDefinition/patient-citizenship"
          }
        ],
        "identifier" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "SS",
                  "display" : "Social Security number"
                }
              ]
            },
            "system" : "urn:oid:1.2.40.0.10.1.4.3.1",
            "value" : "1234010100",
            "assigner" : {
              "display" : "Dachverband der österreichischen Sozialversicherungsträger"
            }
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "NI",
                  "display" : "National unique individual identifier"
                }
              ]
            },
            "system" : "urn:oid:1.2.40.0.10.2.1.1.149",
            "value" : "GH:oeLdSEb0l+8kSdJWjOYyYmnYki0=",
            "assigner" : {
              "display" : "Bundesministerium für Inneres"
            }
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "PI",
                  "display" : "Patient internal identifier"
                }
              ]
            },
            "system" : "urn:oid:1.2.3.4.5",
            "value" : "0815",
            "assigner" : {
              "display" : "Ein GDA in Österreich"
            }
          }
        ],
        "name" : [
          {
            "family" : "Mustermann",
            "given" : ["Maxima"],
            "prefix" : ["DI"]
          }
        ],
        "telecom" : [
          {
            "system" : "email",
            "value" : "office@hl7.at",
            "use" : "work"
          },
          {
            "system" : "phone",
            "value" : "+436501234567890",
            "use" : "home"
          }
        ],
        "gender" : "male",
        "birthDate" : "1900-01-01",
        "address" : [
          {
            "use" : "home",
            "type" : "both",
            "line" : ["Landstrasse 1 Stock 9 Tür 42"],
            "_line" : [
              {
                "extension" : [
                  {
                    "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
                    "valueString" : "Landstrasse"
                  },
                  {
                    "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
                    "valueString" : "1"
                  },
                  {
                    "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-additionalLocator",
                    "valueString" : "Stock 9 Tür 42"
                  },
                  {
                    "url" : "http://hl7.at/fhir/HL7ATCoreProfiles/5.0.0/StructureDefinition/at-core-ext-address-additionalInformation",
                    "valueString" : "Lift vorhanden"
                  }
                ]
              }
            ],
            "city" : "Linz",
            "state" : "Oberösterreich",
            "postalCode" : "4020",
            "country" : "AUT"
          }
        ]
      },
      "search" : {
        "mode" : "include"
      }
    }
  ]
}

```
