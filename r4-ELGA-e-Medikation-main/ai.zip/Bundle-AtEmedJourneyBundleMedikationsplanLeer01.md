# HL7.AT.FHIR.ELGA.EMED.R4\Example JourneyBundle Collection Medikationsplan leer 01 - FHIR® v4.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example JourneyBundle Collection Medikationsplan leer 01**

## Example Bundle: Example JourneyBundle Collection Medikationsplan leer 01



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "AtEmedJourneyBundleMedikationsplanLeer01",
  "meta" : {
    "profile" : [
      "https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-emed-bundle-medikationsplan"
    ]
  },
  "identifier" : {
    "system" : "http://system-to-be-defined.com",
    "value" : "63fef90a-be11-4ddf-aece-d77da15c4f20"
  },
  "type" : "collection",
  "timestamp" : "2026-01-28T08:00:00+00:00",
  "entry" : [
    {
      "resource" : {
        "resourceType" : "List",
        "id" : "AtEmedJourneyListMedikationsplanLeer01",
        "meta" : {
          "profile" : [
            "https://fhir.hl7.at/elga/emed/r4/StructureDefinition/at-emed-list-medikationsplan"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"List_AtEmedJourneyListMedikationsplanLeer01\"> </a><p class=\"res-header-id\"><b>Generated Narrative: List AtEmedJourneyListMedikationsplanLeer01</b></p><a name=\"AtEmedJourneyListMedikationsplanLeer01\"> </a><a name=\"hcAtEmedJourneyListMedikationsplanLeer01\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-at-emed-list-medikationsplan.html\">ELGA e-Medikation Medikationsplan</a></p></div><table class=\"clstu\"><tr><td>Date: 2026-01-28 08:00:00+1100 </td><td>Mode: Working List </td><td>Status: Current </td><td>Code: Medikationsplan </td></tr><tr><td>Subject: <a href=\"Patient-AtEmedExamplePatient01.html\">Max Mustermann  Male, DoB: 1900-01-01 ( Social Security number: 1234010100)</a>Source: Order: Sorted by User </td></tr></table><table class=\"grid\"><tr style=\"backgound-color: #eeeeee\"><td><b>Items</b></td></tr></table></div>"
        },
        "status" : "current",
        "mode" : "working",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "736378000",
              "display" : "Medikationsplan"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/AtEmedExamplePatient01"
        },
        "date" : "2026-01-28T08:00:00+11:00",
        "source" : {
          "reference" : "Practitioner/AtEmedExamplePractitioner01"
        },
        "orderedBy" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/list-order",
              "code" : "user"
            }
          ]
        },
        "emptyReason" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/list-empty-reason",
              "code" : "notstarted"
            }
          ]
        }
      }
    }
  ]
}

```
