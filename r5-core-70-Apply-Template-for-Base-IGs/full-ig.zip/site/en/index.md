# Home - HL7® Austria FHIR® Core Implementation Guide v2.1.0

## Home

### Introduction

> This is the implementation guide for the **Core Profiles (v2.1.0: [STU](https://www.hl7.org/fhir/versions.html) 3)** based on HL7® FHIR® R5. It is a **ballot** implementation guide that is hosted on the [HL7® Austria github project](https://github.com/HL7Austria). The most recent version of this implementation guide can be found at the [HL7® Austria FHIR® Website](https://fhir.hl7.at/).

This implementation guide is provided to support the use of FHIR® in Austria.

This guide is a working specification. We anticipate that it will be implemented and tested by FHIR® system producers whose feedback will help improve its content. With this standard for trial use, we are looking for feedback on whether the following goals have been met:

* The HL7® Austria FHIR® Core Implementation Guide (IG) covers administrative Resources, like Patient, Organization, Practitioner, etc. that can be used on their own with no specific functional requirements for usage or they can be used for other more functional FHIR® IGs in Austria via dependencies. It contains only those Profiles and Extension where adaptions for Austria were necessary.
* This guide defines the minimum constraints on the FHIR® resources to create the Austrian Core Profiles.
* It contains guidance on the [HL7® AT Core Patient Profile](StructureDefinition-at-core-patient.md). 
* Along with the Patient profile the representation of the common structure of address information within Austrian information systems ([HL7® AT Core Address Profile](StructureDefinition-at-core-address.md)) and the extension to encode the religious confession of a patient (only confessions registered in Austria) ([Patient Religion](StructureDefinition-at-core-ext-patient-religion.md)) have been specified.
 
* Furthermore the codes for gender were extended to allow the usage of all official administrative genders in Austria.
* It defines the requirements for Organization, Practitioner or PractitionerRole to carry information specific to Austria (e.g. identifiers).
* This guide contains no code systems or value sets on its own. Note, that code systems and value sets that are used in the various Profiles or Extensions of this guide will generally be made available via a separate IG on the [Austrian Terminology Server](https://termgit.elga.gv.at/) based on [TerminoloGit](https://gitlab.com/elga-gmbh/termgit). 
* It does contain an Extension and a Profile for the ValueSet Resource, that allows to add the OID of code cystems that are referenced within the ValueSet, not just the URL reference.
* This profile is already used by the Austrian Terminology Server.
 

### Relation to Austrian EHR System (ELGA)

Currently, the Austrian EHR system (ELGA) is mainly based on HL7® CDA®. In order to enable the creation of FHIR® resources that have a similar data structure this Implementation Guide provides mappings to the CDA® based implementation guides (e.g. [Mappings for Allgemeiner Implementierungsleitfaden v3](StructureDefinition-at-core-patient-mappings.md#mappings-for-allgemeiner-implementierungsleitfaden-v3-https-wiki)). Furthermore ELGA is using the HL7® Austria FHIR® Core IG as a basis for their FHIR® Implementation Guides.

