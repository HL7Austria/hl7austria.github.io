# HL7.AT.FHIR.CORE.R5\HL7ATCoreLocationGraz - FHIR® v5.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HL7ATCoreLocationGraz**

## Example Location: HL7ATCoreLocationGraz

Profile: [HL7® AT Core Location Profile](StructureDefinition-at-core-location.md)

Campus Graz (urn:oid:1.2.40.0.34.4.10#K101.1)

-------

| | |
| :--- | :--- |
| Address: | Graz 8010 AUT |
| Position: | 47.0707, 15.4395 |
| Managed By: | [Amadeus Spital (Allgemeine Krankenanstalt) (OID:1.2.40.0.34.99.4613.3)](Organization-HL7ATCoreOrganizationExample01.md) |



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "HL7ATCoreLocationGraz",
  "meta" : {
    "profile" : ["https://fhir.hl7.at/core/r5/StructureDefinition/at-core-location"]
  },
  "identifier" : [{
    "system" : "urn:oid:1.2.40.0.34.4.10",
    "value" : "K101.1",
    "assigner" : {
      "display" : "Österreichisches Bundesministerium für Gesundheit"
    }
  }],
  "name" : "Campus Graz",
  "address" : {
    "city" : "Graz",
    "postalCode" : "8010",
    "country" : "AUT"
  },
  "position" : {
    "longitude" : 15.4395,
    "latitude" : 47.0707
  },
  "managingOrganization" : {
    "reference" : "Organization/HL7ATCoreOrganizationExample01"
  }
}

```
