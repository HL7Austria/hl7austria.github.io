# HL7.AT.FHIR.TC.WG.SCHEDULING.R5\HL7ATSchedulingScheduleExample01 - FHIR® v5.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HL7ATSchedulingScheduleExample01**

## Example Schedule: HL7ATSchedulingScheduleExample01

Profile: [HL7® AT Scheduling Schedule Profile](StructureDefinition-at-scheduling-schedule.md)

**active**: true

### ServiceTypes

| | |
| :--- | :--- |
| - | **Concept** |
| * | Physiotherapy |

**actor**: [Melanie Musterärztin](http://hl7.at/fhir/HL7ATCoreProfiles/5.0.0/2.0.0/Practitioner-HL7ATCorePractitionerExample01.html)

**planningHorizon**: 2025-05-13 08:00:00+0200 --> 2025-05-23 17:00:00+0200



## Resource Content

```json
{
  "resourceType" : "Schedule",
  "id" : "HL7ATSchedulingScheduleExample01",
  "meta" : {
    "profile" : [
      "http://hl7.at/fhir/TC-FHIR-AG-Scheduling-R5/R5/StructureDefinition/at-scheduling-schedule"
    ]
  },
  "active" : true,
  "serviceType" : [
    {
      "concept" : {
        "coding" : [
          {
            "system" : "http://hl7.at/fhir/TC-FHIR-AG-Scheduling-R5/R5/ValueSet/AtSchedulingServiceType",
            "code" : "65",
            "display" : "Physiotherapy"
          }
        ]
      }
    }
  ],
  "actor" : [
    {
      "reference" : "Practitioner/HL7ATCorePractitionerExample01",
      "display" : "Melanie Musterärztin"
    }
  ],
  "planningHorizon" : {
    "start" : "2025-05-13T08:00:00+02:00",
    "end" : "2025-05-23T17:00:00+02:00"
  }
}

```
