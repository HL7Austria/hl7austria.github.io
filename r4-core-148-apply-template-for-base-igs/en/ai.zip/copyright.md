# Copyright - HL7® Austria FHIR® Core Implementation Guide v2.1.0

## Copyright

### License and Legal Terms

HL7®, HEALTH LEVEL SEVEN® and FHIR® are trademarks owned by Health Level Seven International, registered with the United States Patent and Trademark Office.

This Implementation Guide contains and references intellectual property owned by third parties (“Third Party IP”). Acceptance of these License Terms does not grant any rights with respect to Third Party IP. The licensee alone is responsible for identifying and obtaining any necessary licenses or authorizations to utilize Third Party IP in connection with the specification or otherwise.

### IP-Statements

This publication includes IP covered under the following statements.

* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [Gynäkologische Ultraschalldiagnostik](HealthcareService-HealthcareServiceUltraschall.md), [Hebammensprechstunde – Schwangerschaft und Wochenbett](HealthcareService-HealthcareServiceHebammenberatung.md)... Show 6 more, [PractitionerRole/HL7ATCorePractitionerRoleExample01](PractitionerRole-HL7ATCorePractitionerRoleExample01.md), [PractitionerRole/PractitionerRoleAnjaLeitnerSonnenfeld](PractitionerRole-PractitionerRoleAnjaLeitnerSonnenfeld.md), [PractitionerRole/PractitionerRoleLukasSteinerOrdination](PractitionerRole-PractitionerRoleLukasSteinerOrdination.md), [PractitionerRole/PractitionerRoleLukasSteinerSpital](PractitionerRole-PractitionerRoleLukasSteinerSpital.md), [PractitionerRole/PractitionerRoleSarahBergerSonnenfeld](PractitionerRole-PractitionerRoleSarahBergerSonnenfeld.md) and [PractitionerRole/PractitionerRoleThomasHoferSonnenfeld](PractitionerRole-PractitionerRoleThomasHoferSonnenfeld.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [Organization type](http://terminology.hl7.org/7.4.0/CodeSystem-organization-type.html): [Abteilung für Innere Medizin – Amadeus Spital](Organization-OrganizationAmadeusSpitalInnereMedizin.md), [Gruppenpraxis Frauenmedizin Sonnenfeld OG](Organization-OrganizationGruppenpraxisFrauenmedizinSonnenfeld.md) and [Ordination Dr. Lukas Steiner](Organization-OrganizationOrdinationLukasSteiner.md)
* [Service category](http://terminology.hl7.org/7.4.0/CodeSystem-service-category.html): [Gynäkologische Ultraschalldiagnostik](HealthcareService-HealthcareServiceUltraschall.md) and [Hebammensprechstunde – Schwangerschaft und Wochenbett](HealthcareService-HealthcareServiceHebammenberatung.md)
* [Service type](http://terminology.hl7.org/7.4.0/CodeSystem-service-type.html): [Gynäkologische Ultraschalldiagnostik](HealthcareService-HealthcareServiceUltraschall.md) and [Hebammensprechstunde – Schwangerschaft und Wochenbett](HealthcareService-HealthcareServiceHebammenberatung.md)
* [Test script operation code](http://terminology.hl7.org/7.4.0/CodeSystem-testscript-operation-codes.html): [HL7® AT Core TestScript - Patient Create](TestScript-testscript-patient-create-at-core.md) and [HL7® AT Core TestScript - Patient Update](TestScript-testscript-patient-update-at-core.md)
* [contactRole2](http://terminology.hl7.org/7.4.0/CodeSystem-v2-0131.html): [Patient/HL7ATCorePatientCreateTestExample](Patient-HL7ATCorePatientCreateTestExample.md), [Patient/HL7ATCorePatientExample04-Full](Patient-HL7ATCorePatientExample04-Full.md) and [Patient/HL7ATCorePatientUpdateTestExample](Patient-HL7ATCorePatientUpdateTestExample.md)
* [identifierType](http://terminology.hl7.org/7.4.0/CodeSystem-v2-0203.html): [Patient/HL7ATCorePatientCreateTestExample](Patient-HL7ATCorePatientCreateTestExample.md), [Patient/HL7ATCorePatientExample01](Patient-HL7ATCorePatientExample01.md)... Show 9 more, [Patient/HL7ATCorePatientExample02-deceasedTime](Patient-HL7ATCorePatientExample02-deceasedTime.md), [Patient/HL7ATCorePatientExample03-deceasedBoolean](Patient-HL7ATCorePatientExample03-deceasedBoolean.md), [Patient/HL7ATCorePatientExample04-Full](Patient-HL7ATCorePatientExample04-Full.md), [Patient/HL7ATCorePatientExample05-FullElga](Patient-HL7ATCorePatientExample05-FullElga.md), [Patient/HL7ATCorePatientExample06-GenderExtension](Patient-HL7ATCorePatientExample06-GenderExtension.md), [Patient/HL7ATCorePatientExample07-MunicipalityCode](Patient-HL7ATCorePatientExample07-MunicipalityCode.md), [Patient/HL7ATCorePatientUpdateTestExample](Patient-HL7ATCorePatientUpdateTestExample.md), [Patient/PatientFelixGruber](Patient-PatientFelixGruber.md) and [RelatedPerson/RelatedPersonMartinGruber](RelatedPerson-RelatedPersonMartinGruber.md)
* [degreeLicenseCertificate](http://terminology.hl7.org/7.4.0/CodeSystem-v2-0360.html): [Practitioner/PractitionerAnjaLeitner](Practitioner-PractitionerAnjaLeitner.md), [Practitioner/PractitionerLukasSteiner](Practitioner-PractitionerLukasSteiner.md) and [Practitioner/PractitionerThomasHofer](Practitioner-PractitionerThomasHofer.md)
* [MaritalStatus](http://terminology.hl7.org/7.4.0/CodeSystem-v3-MaritalStatus.html): [Patient/HL7ATCorePatientCreateTestExample](Patient-HL7ATCorePatientCreateTestExample.md), [Patient/HL7ATCorePatientExample02-deceasedTime](Patient-HL7ATCorePatientExample02-deceasedTime.md)... Show 4 more, [Patient/HL7ATCorePatientExample03-deceasedBoolean](Patient-HL7ATCorePatientExample03-deceasedBoolean.md), [Patient/HL7ATCorePatientExample04-Full](Patient-HL7ATCorePatientExample04-Full.md), [Patient/HL7ATCorePatientExample05-FullElga](Patient-HL7ATCorePatientExample05-FullElga.md) and [Patient/HL7ATCorePatientUpdateTestExample](Patient-HL7ATCorePatientUpdateTestExample.md)
* [RoleCode](http://terminology.hl7.org/7.4.0/CodeSystem-v3-RoleCode.html): [Patient/HL7ATCorePatientExample05-FullElga](Patient-HL7ATCorePatientExample05-FullElga.md) and [RelatedPerson/RelatedPersonMartinGruber](RelatedPerson-RelatedPersonMartinGruber.md)


