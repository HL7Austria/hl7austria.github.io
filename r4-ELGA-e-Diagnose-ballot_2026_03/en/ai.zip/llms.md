# hl7.at.fhir.elga.ediag.r4#0.1.0: ELGA e-Diagnose R4(en)

## Pages

* [e-Diagnose](index.md)
* [Herausforderungen](challenges.md)
* [Patient Journey](patient_journey.md)
* [Copyright](copyright.md)
* [Überblick Anwendungsfälle](use_cases.md)
* [Lesender Zugriff](use_case_read.md)
* [Artifacts Summary](artifacts.md)
* [Transaktionen](transaction.md)
* [Impressum](imprint.md)
* [Download](download.md)
* [Autoren und Mitwirkende](contributors.md)
* [Akteure](actors.md)
* [Hintergrund](background.md)
* [Designentscheidungen](design_choices.md)
* [Umfang und Inhalt](scope_and_content.md)
* [Publikationsinformationen](publication_info.md)
* [Schreibender Zugriff](use_case_write.md)
* [Ausüben von Teilnehmerrechten](use_case_participant.md)
* [Dependencies](dependencies.md)

## Resources

### CodeSystems

* [AT e-Diagnose Business Identifier CS](CodeSystem-at-ediag-business-identifier.md)
* [AT e-Diagnose OperationOutcome Details CS](CodeSystem-at-ediag-operationoutcome-details.md)
* [AT e-Diagnose Reaktionszeit CS](CodeSystem-at-ediag-reaction-time.md)

### ValueSets

* [AT e-Diagnose AllergyIntolerance Clinical Status](ValueSet-at-ediag-allergyintolerance-clinical-status.md)
* [AT e-Diagnose AllergyIntolerance Code](ValueSet-at-ediag-allergyintolerance-code.md)
* [AT e-Diagnose AllergyIntolerance Verification Status](ValueSet-at-ediag-allergyintolerance-verification-status.md)
* [AT e-Diagnose Condition Clinical Status](ValueSet-at-ediag-condition-clinical-status.md)
* [AT e-Diagnose Condition Code](ValueSet-at-ediag-condition-code.md)
* [AT e-Diagnose Condition Verification Status](ValueSet-at-ediag-condition-verification-status.md)
* [AT e-Diagnose List Code](ValueSet-at-ediag-list-code.md)
* [ELGA List Empty Reason](ValueSet-at-ediag-list-emptyreason.md)
* [AT e-Diagnose OperationOutcome Details VS](ValueSet-at-ediag-operationoutcome-details.md)
* [AT e-Diagnose Procedure Code](ValueSet-at-ediag-procedure-code.md)
* [AT e-Diagnose Reaktionszeit VS](ValueSet-at-ediag-reaction-time.md)

### Resource Profiles

* [AT e-Diagnose AllergyIntolerance](StructureDefinition-at-elga-ediag-allergyintolerance.md)
* [AT e-Diagnose Condition](StructureDefinition-at-elga-ediag-condition.md)
* [AT e-Diagnose Summary-Liste](StructureDefinition-at-elga-ediag-list.md)
* [AT e-Diagnose OperationOutcome](StructureDefinition-at-elga-ediag-operationoutcome.md)
* [AT e-Diagnose Procedure](StructureDefinition-at-elga-ediag-procedure.md)
* [AT e-Diagnose RelatedPerson](StructureDefinition-at-elga-ediag-relatedperson.md)

### Extensions

* [AT e-Diagnose Entered In Error](StructureDefinition-at-elga-ediag-ext-entered-in-error.md)
* [AT e-Diagnose Evidenz (e-Befund)](StructureDefinition-at-elga-ediag-ext-evidence.md)
* [AT e-Diagnose Reaktionszeit](StructureDefinition-at-elga-ediag-ext-reaction-time.md)
* [AT e-Diagnose Reported (Fremdangabe)](StructureDefinition-at-elga-ediag-ext-reported.md)

### ImplementationGuides

* [ELGA e-Diagnose R4](ImplementationGuide-hl7.at.fhir.elga.ediag.r4.md)

### OperationDefinitions

* [e-Diagnose Operation $delete](OperationDefinition-at-ediag-operation-entry-delete.md)
* [e-Diagnose Operation $entered-in-error](OperationDefinition-at-ediag-operation-entry-entered-in-error.md)
* [e-Diagnose Operation $delete-history-version](OperationDefinition-at-ediag-operation-list-delete-history-version.md)
* [e-Diagnose Operation $write](OperationDefinition-at-ediag-operation-list-write.md)

### SearchParameters

* [AllergyIntoleranceEvidence](SearchParameter-at-elga-ediag-searchparameter-allergyintolerance-evidence.md)
* [ConditionRecorder](SearchParameter-at-elga-ediag-searchparameter-condition-recorder.md)
* [ProcedureAsserter](SearchParameter-at-elga-ediag-searchparameter-procedure-asserter.md)
* [ProcedureRecorder](SearchParameter-at-elga-ediag-searchparameter-procedure-recorder.md)
* [ProcedureReport](SearchParameter-at-elga-ediag-searchparameter-procedure-report.md)

### Examples

* [AllergyEntry01 (AllergyIntolerance)](AllergyIntolerance-AllergyEntry01.md)
* [AllergyEntry01Request (AllergyIntolerance)](AllergyIntolerance-AllergyEntry01Request.md)
* [AllergyListSearchSet01 (Bundle)](Bundle-AllergyListSearchSet01.md)
* [ConditionListSearchSet01 (Bundle)](Bundle-ConditionListSearchSet01.md)
* [ConditionListSearchSet02 (Bundle)](Bundle-ConditionListSearchSet02.md)
* [ConditionListSearchSet03 (Bundle)](Bundle-ConditionListSearchSet03.md)
* [ConditionSearchSet01 (Bundle)](Bundle-ConditionSearchSet01.md)
* [ConditionSearchSet02 (Bundle)](Bundle-ConditionSearchSet02.md)
* [ConditionSearchSet03 (Bundle)](Bundle-ConditionSearchSet03.md)
* [ConditionEntry01 (Condition)](Condition-ConditionEntry01.md)
* [ConditionEntry01Request (Condition)](Condition-ConditionEntry01Request.md)
* [ConditionEntry02 (Condition)](Condition-ConditionEntry02.md)
* [ConditionEntry03 (Condition)](Condition-ConditionEntry03.md)
* [ConditionEntry03EnteredInError (Condition)](Condition-ConditionEntry03EnteredInError.md)
* [ConditionEntry04 (Condition)](Condition-ConditionEntry04.md)
* [ConditionEntry05 (Condition)](Condition-ConditionEntry05.md)
* [ConditionEntry06 (Condition)](Condition-ConditionEntry06.md)
* [ConditionEntryContainedRelatedPerson (Condition)](Condition-ConditionEntryContainedRelatedPerson.md)
* [DeviceExample (Device)](Device-DeviceExample.md)
* [AllergyList01 (List)](List-AllergyList01.md)
* [AllergyListEmpty (List)](List-AllergyListEmpty.md)
* [ConditionList01 (List)](List-ConditionList01.md)
* [ConditionList02 (List)](List-ConditionList02.md)
* [ConditionList03 (List)](List-ConditionList03.md)
* [ConditionList04 (List)](List-ConditionList04.md)
* [ConditionListEmpty (List)](List-ConditionListEmpty.md)
* [ProcedureList01 (List)](List-ProcedureList01.md)
* [ProcedureListEmpty (List)](List-ProcedureListEmpty.md)
* [AllergyListWrite01 (Parameters)](Parameters-AllergyListWrite01.md)
* [ConditionDeleteResponse01 (Parameters)](Parameters-ConditionDeleteResponse01.md)
* [ConditionEnteredInErrorParameters01 (Parameters)](Parameters-ConditionEnteredInErrorParameters01.md)
* [ConditionEnteredInErrorResponse01 (Parameters)](Parameters-ConditionEnteredInErrorResponse01.md)
* [ConditionListWrite01 (Parameters)](Parameters-ConditionListWrite01.md)
* [ConditionListWrite02 (Parameters)](Parameters-ConditionListWrite02.md)
* [ConditionListWrite03 (Parameters)](Parameters-ConditionListWrite03.md)
* [ProcedureListWrite01 (Parameters)](Parameters-ProcedureListWrite01.md)
* [PatientExample (Patient)](Patient-PatientExample.md)
* [PractitionerExample (Practitioner)](Practitioner-PractitionerExample.md)
* [ProcedureEntry01 (Procedure)](Procedure-ProcedureEntry01.md)
* [ProcedureEntry01Request (Procedure)](Procedure-ProcedureEntry01Request.md)
