# AT e-Diagnose AllergyIntolerance Code - ELGA e-Diagnose R4 v0.1.0

## ValueSet: AT e-Diagnose AllergyIntolerance Code 

 **References** 

* [AT e-Diagnose AllergyIntolerance](StructureDefinition-at-elga-ediag-allergyintolerance.md)

Dieses Value-Set gliedert sich in zwei große Bereiche:

* Für Allergien und Intoleranzen, die auf Medikamente zurückzuführen sind, sollen Codes aus dem Codesystem `https://termgit.elga.gv.at/CodeSystem/medikation-ages-wirkstoffe` verwendet werden.
* Für Allergien und Intoleranzen, die **nicht** auf Medikamente zurückzuführen sind, sollen Codes aus SNOMED CT `http://snomed.info/sct` verwendet werden.

* Für Allergien und Intoleranzen, die keinen Medikamentenbezug haben, orientieren sich die Inhalte am Value-Set eHDSIAllergenNoDrug des Master Valueset Catalogue (MVC) von MyHealth@EU.
* Dieses Value-Set wurde für die e-Diagnose entworfen und wird auf den [österreichischen e-Health Terminologieserver](https://termgit.elga.gv.at/) verschoben, abhängig vom Ergebnis des Ballots.
* Eine Expansion dieses Value-Sets ist zurzeit nicht möglich, weil das referenzierte Value-Set ([https://termgit.elga.gv.at/ValueSet/elga-wirkstoffe-ages](https://termgit.elga.gv.at/ValueSet/elga-wirkstoffe-ages)) vom IG Publisher nicht aufgelöst werden kann.
* Mit der Bereitstellung der aktuellen Version der International Edition von SNOMED CT inklusive der Austrian Extension am österreichischen e-Health Terminologieserver werden folgende Punkte aufgelöst: 
* Der IG Publisher hat zurzeit nur Zugriff auf die International Edition von SNOMED CT in der Version http://snomed.info/sct/900000000000207008/version/20250201, weshalb weniger Konzepte in diesem Value-Set angezeigt werden als in der aktuellen Version von SNOMED CT verfügbar sind.
* Aktuell werden österreichische Übersetzungen auf Basis der Austrian Extension in dem Value-Set noch nicht aufgelöst.
 

### Logical Definition (CLD)

 

### Expansion

No Expansion for this valueset (not supported by Publication Tooling)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "at-ediag-allergyintolerance-code",
  "url" : "https://fhir.hl7.at/elga/ediag/r4/ValueSet/at-ediag-allergyintolerance-code",
  "version" : "0.1.0",
  "name" : "AtEDiagAllergyIntoleranceCode",
  "title" : "AT e-Diagnose AllergyIntolerance Code",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-10-20T08:47:52+00:00",
  "publisher" : "ELGA GmbH",
  "contact" : [{
    "name" : "ELGA GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "http://elga.gv.at"
    }]
  },
  {
    "name" : "ELGA GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://elga.gv.at",
      "use" : "work"
    }]
  }],
  "description" : "Value-Set für die Codierung von Allergien und Intoleranzen.",
  "compose" : {
    "include" : [{
      "valueSet" : ["https://termgit.elga.gv.at/ValueSet/elga-wirkstoffe-ages"]
    },
    {
      "system" : "http://snomed.info/sct",
      "concept" : [{
        "code" : "432003"
      },
      {
        "code" : "2159007"
      },
      {
        "code" : "2309006"
      },
      {
        "code" : "2799001"
      },
      {
        "code" : "3692009"
      },
      {
        "code" : "3718001"
      },
      {
        "code" : "3829006"
      },
      {
        "code" : "6725000"
      },
      {
        "code" : "7434003"
      },
      {
        "code" : "7791007"
      },
      {
        "code" : "8204009"
      },
      {
        "code" : "9010006"
      },
      {
        "code" : "9021002"
      },
      {
        "code" : "10827009"
      },
      {
        "code" : "11526002"
      },
      {
        "code" : "12503006"
      },
      {
        "code" : "12510000"
      },
      {
        "code" : "13577000"
      },
      {
        "code" : "13652007"
      },
      {
        "code" : "14006006"
      },
      {
        "code" : "14321009"
      },
      {
        "code" : "14402002"
      },
      {
        "code" : "15896008"
      },
      {
        "code" : "16313001"
      },
      {
        "code" : "17172002"
      },
      {
        "code" : "17486007"
      },
      {
        "code" : "17693003"
      },
      {
        "code" : "19839007"
      },
      {
        "code" : "19893005"
      },
      {
        "code" : "21592006"
      },
      {
        "code" : "22242006"
      },
      {
        "code" : "22836000"
      },
      {
        "code" : "22931006"
      },
      {
        "code" : "22968009"
      },
      {
        "code" : "23182003"
      },
      {
        "code" : "24102007"
      },
      {
        "code" : "24215009"
      },
      {
        "code" : "25761002"
      },
      {
        "code" : "27119002"
      },
      {
        "code" : "28230009"
      },
      {
        "code" : "28421003"
      },
      {
        "code" : "28647000"
      },
      {
        "code" : "29263009"
      },
      {
        "code" : "29522004"
      },
      {
        "code" : "31006001"
      },
      {
        "code" : "31347007"
      },
      {
        "code" : "33008008"
      },
      {
        "code" : "33396006"
      },
      {
        "code" : "35233000"
      },
      {
        "code" : "35605007"
      },
      {
        "code" : "35609001"
      },
      {
        "code" : "37017009"
      },
      {
        "code" : "37575004"
      },
      {
        "code" : "38271009"
      },
      {
        "code" : "41750006"
      },
      {
        "code" : "41967008"
      },
      {
        "code" : "42416001"
      },
      {
        "code" : "43230003"
      },
      {
        "code" : "43735007"
      },
      {
        "code" : "44027008"
      },
      {
        "code" : "47703008"
      },
      {
        "code" : "48540004"
      },
      {
        "code" : "50593009"
      },
      {
        "code" : "51503008"
      },
      {
        "code" : "51905005"
      },
      {
        "code" : "51963001"
      },
      {
        "code" : "52454007"
      },
      {
        "code" : "52836003"
      },
      {
        "code" : "54041009"
      },
      {
        "code" : "55700001"
      },
      {
        "code" : "56822005"
      },
      {
        "code" : "57126000"
      },
      {
        "code" : "57720001"
      },
      {
        "code" : "59351004"
      },
      {
        "code" : "59533004"
      },
      {
        "code" : "59545008"
      },
      {
        "code" : "61088005"
      },
      {
        "code" : "61789006"
      },
      {
        "code" : "63338004"
      },
      {
        "code" : "63766005"
      },
      {
        "code" : "64601002"
      },
      {
        "code" : "65123005"
      },
      {
        "code" : "65345002"
      },
      {
        "code" : "66562002"
      },
      {
        "code" : "66925006"
      },
      {
        "code" : "67324005"
      },
      {
        "code" : "68524009"
      },
      {
        "code" : "71463006"
      },
      {
        "code" : "72179002"
      },
      {
        "code" : "72511004"
      },
      {
        "code" : "73892005"
      },
      {
        "code" : "75044009"
      },
      {
        "code" : "75665004"
      },
      {
        "code" : "77249007"
      },
      {
        "code" : "79549001"
      },
      {
        "code" : "80237000"
      },
      {
        "code" : "81911001"
      },
      {
        "code" : "82566005"
      },
      {
        "code" : "83595008"
      },
      {
        "code" : "83619009"
      },
      {
        "code" : "84181009"
      },
      {
        "code" : "84212004"
      },
      {
        "code" : "84791008"
      },
      {
        "code" : "85066006"
      },
      {
        "code" : "89811004"
      },
      {
        "code" : "89889006"
      },
      {
        "code" : "102259006"
      },
      {
        "code" : "102261002"
      },
      {
        "code" : "102262009"
      },
      {
        "code" : "102263004"
      },
      {
        "code" : "102264005"
      },
      {
        "code" : "102697003"
      },
      {
        "code" : "105590001"
      },
      {
        "code" : "111088007"
      },
      {
        "code" : "111095003"
      },
      {
        "code" : "115589000"
      },
      {
        "code" : "116364004"
      },
      {
        "code" : "116549003"
      },
      {
        "code" : "116637007"
      },
      {
        "code" : "119417004"
      },
      {
        "code" : "125706008"
      },
      {
        "code" : "128488006"
      },
      {
        "code" : "128489003"
      },
      {
        "code" : "226491003"
      },
      {
        "code" : "226723006"
      },
      {
        "code" : "226776001"
      },
      {
        "code" : "226791004"
      },
      {
        "code" : "226793001"
      },
      {
        "code" : "226915003"
      },
      {
        "code" : "226916002"
      },
      {
        "code" : "226934003"
      },
      {
        "code" : "226942002"
      },
      {
        "code" : "226955001"
      },
      {
        "code" : "226963000"
      },
      {
        "code" : "226967004"
      },
      {
        "code" : "227042005"
      },
      {
        "code" : "227066004"
      },
      {
        "code" : "227067008"
      },
      {
        "code" : "227072004"
      },
      {
        "code" : "227078000"
      },
      {
        "code" : "227081005"
      },
      {
        "code" : "227083008"
      },
      {
        "code" : "227099002"
      },
      {
        "code" : "227105000"
      },
      {
        "code" : "227106004"
      },
      {
        "code" : "227131003"
      },
      {
        "code" : "227136008"
      },
      {
        "code" : "227139001"
      },
      {
        "code" : "227144008"
      },
      {
        "code" : "227147001"
      },
      {
        "code" : "227150003"
      },
      {
        "code" : "227151004"
      },
      {
        "code" : "227156009"
      },
      {
        "code" : "227183005"
      },
      {
        "code" : "227215000"
      },
      {
        "code" : "227219006"
      },
      {
        "code" : "227220000"
      },
      {
        "code" : "227227002"
      },
      {
        "code" : "227229004"
      },
      {
        "code" : "227230009"
      },
      {
        "code" : "227313005"
      },
      {
        "code" : "227339008"
      },
      {
        "code" : "227346004"
      },
      {
        "code" : "227350006"
      },
      {
        "code" : "227362005"
      },
      {
        "code" : "227374009"
      },
      {
        "code" : "227376006"
      },
      {
        "code" : "227379004"
      },
      {
        "code" : "227382009"
      },
      {
        "code" : "227383004"
      },
      {
        "code" : "227385006"
      },
      {
        "code" : "227387003"
      },
      {
        "code" : "227388008"
      },
      {
        "code" : "227389000"
      },
      {
        "code" : "227390009"
      },
      {
        "code" : "227391008"
      },
      {
        "code" : "227392001"
      },
      {
        "code" : "227395004"
      },
      {
        "code" : "227396003"
      },
      {
        "code" : "227398002"
      },
      {
        "code" : "227400003"
      },
      {
        "code" : "227404007"
      },
      {
        "code" : "227405008"
      },
      {
        "code" : "227407000"
      },
      {
        "code" : "227408005"
      },
      {
        "code" : "227409002"
      },
      {
        "code" : "227410007"
      },
      {
        "code" : "227411006"
      },
      {
        "code" : "227413009"
      },
      {
        "code" : "227414003"
      },
      {
        "code" : "227423000"
      },
      {
        "code" : "227425007"
      },
      {
        "code" : "227435001"
      },
      {
        "code" : "227444000"
      },
      {
        "code" : "227447007"
      },
      {
        "code" : "227493005"
      },
      {
        "code" : "227501001"
      },
      {
        "code" : "227511008"
      },
      {
        "code" : "227512001"
      },
      {
        "code" : "227514000"
      },
      {
        "code" : "227515004"
      },
      {
        "code" : "227538001"
      },
      {
        "code" : "227598003"
      },
      {
        "code" : "228104004"
      },
      {
        "code" : "229934002"
      },
      {
        "code" : "229941008"
      },
      {
        "code" : "229944000"
      },
      {
        "code" : "230034002"
      },
      {
        "code" : "255620007"
      },
      {
        "code" : "255640000"
      },
      {
        "code" : "255667006"
      },
      {
        "code" : "255764006"
      },
      {
        "code" : "255769001"
      },
      {
        "code" : "255772008"
      },
      {
        "code" : "255775005"
      },
      {
        "code" : "255786007"
      },
      {
        "code" : "255814009"
      },
      {
        "code" : "255840003"
      },
      {
        "code" : "255842006"
      },
      {
        "code" : "255844007"
      },
      {
        "code" : "255859001"
      },
      {
        "code" : "255864002"
      },
      {
        "code" : "255868004"
      },
      {
        "code" : "255871007"
      },
      {
        "code" : "255924000"
      },
      {
        "code" : "256186006"
      },
      {
        "code" : "256218005"
      },
      {
        "code" : "256259004"
      },
      {
        "code" : "256260009"
      },
      {
        "code" : "256262001"
      },
      {
        "code" : "256267007"
      },
      {
        "code" : "256270006"
      },
      {
        "code" : "256272003"
      },
      {
        "code" : "256277009"
      },
      {
        "code" : "256281009"
      },
      {
        "code" : "256289006"
      },
      {
        "code" : "256290002"
      },
      {
        "code" : "256292005"
      },
      {
        "code" : "256293000"
      },
      {
        "code" : "256303006"
      },
      {
        "code" : "256305004"
      },
      {
        "code" : "256306003"
      },
      {
        "code" : "256307007"
      },
      {
        "code" : "256313003"
      },
      {
        "code" : "256315005"
      },
      {
        "code" : "256316006"
      },
      {
        "code" : "256317002"
      },
      {
        "code" : "256318007"
      },
      {
        "code" : "256319004"
      },
      {
        "code" : "256326004"
      },
      {
        "code" : "256329006"
      },
      {
        "code" : "256330001"
      },
      {
        "code" : "256331002"
      },
      {
        "code" : "256350002"
      },
      {
        "code" : "256351003"
      },
      {
        "code" : "256352005"
      },
      {
        "code" : "256353000"
      },
      {
        "code" : "256354006"
      },
      {
        "code" : "256355007"
      },
      {
        "code" : "256363008"
      },
      {
        "code" : "256417003"
      },
      {
        "code" : "256419000"
      },
      {
        "code" : "256435007"
      },
      {
        "code" : "256440004"
      },
      {
        "code" : "256443002"
      },
      {
        "code" : "256496006"
      },
      {
        "code" : "256501007"
      },
      {
        "code" : "256504004"
      },
      {
        "code" : "256506002"
      },
      {
        "code" : "256526003"
      },
      {
        "code" : "256579008"
      },
      {
        "code" : "256596009"
      },
      {
        "code" : "256607001"
      },
      {
        "code" : "256633009"
      },
      {
        "code" : "259221006"
      },
      {
        "code" : "260108001"
      },
      {
        "code" : "260118006"
      },
      {
        "code" : "260126003"
      },
      {
        "code" : "260131001"
      },
      {
        "code" : "260152009"
      },
      {
        "code" : "260153004"
      },
      {
        "code" : "260154005"
      },
      {
        "code" : "260156007"
      },
      {
        "code" : "260167008"
      },
      {
        "code" : "260168003"
      },
      {
        "code" : "260176001"
      },
      {
        "code" : "260177005"
      },
      {
        "code" : "260179008"
      },
      {
        "code" : "260184002"
      },
      {
        "code" : "260189007"
      },
      {
        "code" : "260204008"
      },
      {
        "code" : "260205009"
      },
      {
        "code" : "261243003"
      },
      {
        "code" : "261249004"
      },
      {
        "code" : "261250004"
      },
      {
        "code" : "261712009"
      },
      {
        "code" : "264287008"
      },
      {
        "code" : "264295007"
      },
      {
        "code" : "264331002"
      },
      {
        "code" : "264337003"
      },
      {
        "code" : "276310004"
      },
      {
        "code" : "277016007"
      },
      {
        "code" : "278840001"
      },
      {
        "code" : "280939008"
      },
      {
        "code" : "286550009"
      },
      {
        "code" : "288326000"
      },
      {
        "code" : "288328004"
      },
      {
        "code" : "288460008"
      },
      {
        "code" : "289122001"
      },
      {
        "code" : "289949002"
      },
      {
        "code" : "289955007"
      },
      {
        "code" : "290008007"
      },
      {
        "code" : "301093003"
      },
      {
        "code" : "301712000"
      },
      {
        "code" : "303300008"
      },
      {
        "code" : "303314008"
      },
      {
        "code" : "303315009"
      },
      {
        "code" : "311443003"
      },
      {
        "code" : "311731000"
      },
      {
        "code" : "311846002"
      },
      {
        "code" : "373780001"
      },
      {
        "code" : "387239001"
      },
      {
        "code" : "387293003"
      },
      {
        "code" : "391737006"
      },
      {
        "code" : "395734009"
      },
      {
        "code" : "396049000"
      },
      {
        "code" : "398705004"
      },
      {
        "code" : "408742009"
      },
      {
        "code" : "409595003"
      },
      {
        "code" : "410853002"
      },
      {
        "code" : "412056003"
      },
      {
        "code" : "412060000"
      },
      {
        "code" : "412061001"
      },
      {
        "code" : "412068007"
      },
      {
        "code" : "412070003"
      },
      {
        "code" : "412071004"
      },
      {
        "code" : "412145001"
      },
      {
        "code" : "412150007"
      },
      {
        "code" : "412153009"
      },
      {
        "code" : "412156001"
      },
      {
        "code" : "412161004"
      },
      {
        "code" : "412357001"
      },
      {
        "code" : "412548006"
      },
      {
        "code" : "415710007"
      },
      {
        "code" : "418266005"
      },
      {
        "code" : "418504009"
      },
      {
        "code" : "418785009"
      },
      {
        "code" : "418920007"
      },
      {
        "code" : "419420009"
      },
      {
        "code" : "419604006"
      },
      {
        "code" : "419633007"
      },
      {
        "code" : "421556008"
      },
      {
        "code" : "425620007"
      },
      {
        "code" : "430503006"
      },
      {
        "code" : "431510009"
      },
      {
        "code" : "434162003"
      },
      {
        "code" : "472731004"
      },
      {
        "code" : "698730007"
      },
      {
        "code" : "702730004"
      },
      {
        "code" : "710039005"
      },
      {
        "code" : "710171001"
      },
      {
        "code" : "710172008"
      },
      {
        "code" : "710178007"
      },
      {
        "code" : "710179004"
      },
      {
        "code" : "710183004"
      },
      {
        "code" : "710184005"
      },
      {
        "code" : "710226003"
      },
      {
        "code" : "710900003"
      },
      {
        "code" : "710902006"
      },
      {
        "code" : "710930006"
      },
      {
        "code" : "710932003"
      },
      {
        "code" : "710937009"
      },
      {
        "code" : "710943006"
      },
      {
        "code" : "711088004"
      },
      {
        "code" : "711089007"
      },
      {
        "code" : "711090003"
      },
      {
        "code" : "711092006"
      },
      {
        "code" : "711094007"
      },
      {
        "code" : "711096009"
      },
      {
        "code" : "711097000"
      },
      {
        "code" : "711098005"
      },
      {
        "code" : "711143002"
      },
      {
        "code" : "711316002"
      },
      {
        "code" : "711319009"
      },
      {
        "code" : "719108000"
      },
      {
        "code" : "720687003"
      },
      {
        "code" : "726731009"
      },
      {
        "code" : "726749009"
      },
      {
        "code" : "726755004"
      },
      {
        "code" : "726758002"
      },
      {
        "code" : "726759005"
      },
      {
        "code" : "726761001"
      },
      {
        "code" : "726763003"
      },
      {
        "code" : "726764009"
      },
      {
        "code" : "734881000"
      },
      {
        "code" : "735004000"
      },
      {
        "code" : "735006003"
      },
      {
        "code" : "735009005"
      },
      {
        "code" : "735029006"
      },
      {
        "code" : "735030001"
      },
      {
        "code" : "735034005"
      },
      {
        "code" : "735035006"
      },
      {
        "code" : "735042006"
      },
      {
        "code" : "735043001"
      },
      {
        "code" : "735045008"
      },
      {
        "code" : "735046009"
      },
      {
        "code" : "735047000"
      },
      {
        "code" : "735049002"
      },
      {
        "code" : "735050002"
      },
      {
        "code" : "735051003"
      },
      {
        "code" : "735053000"
      },
      {
        "code" : "735106000"
      },
      {
        "code" : "735123009"
      },
      {
        "code" : "735124003"
      },
      {
        "code" : "735211005"
      },
      {
        "code" : "735212003"
      },
      {
        "code" : "735213008"
      },
      {
        "code" : "735214002"
      },
      {
        "code" : "735215001"
      },
      {
        "code" : "735245003"
      },
      {
        "code" : "735246002"
      },
      {
        "code" : "735248001"
      },
      {
        "code" : "735249009"
      },
      {
        "code" : "735336002"
      },
      {
        "code" : "735337006"
      },
      {
        "code" : "735340006"
      },
      {
        "code" : "735341005"
      },
      {
        "code" : "735959004"
      },
      {
        "code" : "735971005"
      },
      {
        "code" : "735972003"
      },
      {
        "code" : "735974002"
      },
      {
        "code" : "735977009"
      },
      {
        "code" : "735979007"
      },
      {
        "code" : "736027000"
      },
      {
        "code" : "736030007"
      },
      {
        "code" : "736031006"
      },
      {
        "code" : "736159005"
      },
      {
        "code" : "736162008"
      },
      {
        "code" : "736258006"
      },
      {
        "code" : "762766007"
      },
      {
        "code" : "762952008"
      },
      {
        "code" : "764166003"
      },
      {
        "code" : "765099008"
      },
      {
        "code" : "767406000"
      },
      {
        "code" : "770326002"
      },
      {
        "code" : "771518004"
      },
      {
        "code" : "772245002"
      },
      {
        "code" : "773757000"
      },
      {
        "code" : "782576004"
      },
      {
        "code" : "785344003"
      },
      {
        "code" : "1003736004"
      },
      {
        "code" : "1003752001"
      },
      {
        "code" : "1137358000"
      },
      {
        "code" : "1137359008"
      },
      {
        "code" : "442461000124102"
      },
      {
        "code" : "24515005"
      },
      {
        "code" : "37663002"
      },
      {
        "code" : "51386004"
      },
      {
        "code" : "63045006"
      },
      {
        "code" : "70813002"
      },
      {
        "code" : "80259003"
      },
      {
        "code" : "87918000"
      },
      {
        "code" : "116274004"
      },
      {
        "code" : "227038007"
      },
      {
        "code" : "227110001"
      },
      {
        "code" : "256248008"
      },
      {
        "code" : "256406004"
      },
      {
        "code" : "289954006"
      },
      {
        "code" : "735108004"
      },
      {
        "code" : "442571000124108"
      }]
    }]
  }
}

```
