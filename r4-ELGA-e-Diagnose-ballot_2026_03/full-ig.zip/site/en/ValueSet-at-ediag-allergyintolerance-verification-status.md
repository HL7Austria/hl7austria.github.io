# AT e-Diagnose AllergyIntolerance Verification Status - ELGA e-Diagnose R4 v0.1.0

## ValueSet: AT e-Diagnose AllergyIntolerance Verification Status 

 **References** 

* [AT e-Diagnose AllergyIntolerance](StructureDefinition-at-elga-ediag-allergyintolerance.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "at-ediag-allergyintolerance-verification-status",
  "url" : "https://fhir.hl7.at/elga/ediag/r4/ValueSet/at-ediag-allergyintolerance-verification-status",
  "version" : "0.1.0",
  "name" : "AtEdiagAllergyIntoleranceVerificationStatus",
  "title" : "AT e-Diagnose AllergyIntolerance Verification Status",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-10-27T15:15:47+00:00",
  "publisher" : "ELGA GmbH",
  "contact" : [{
    "name" : "ELGA GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "http://elga.gv.at"
    }]
  },
  {
    "name" : "ELGA GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://elga.gv.at",
      "use" : "work"
    }]
  }],
  "description" : "Value-Set mit den für e-Diagnose zulässigen Ausprägungen von AllergyIntolerance.verificationStatus (siehe Workflowmanagement: Erlaubte Kombinationen für AllergyIntolerance).",
  "compose" : {
    "include" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/allergyintolerance-verification",
      "version" : "1.0.1",
      "concept" : [{
        "code" : "unconfirmed",
        "display" : "Unconfirmed"
      },
      {
        "code" : "presumed",
        "display" : "Presumed"
      },
      {
        "code" : "confirmed",
        "display" : "Confirmed"
      },
      {
        "code" : "refuted",
        "display" : "Refuted"
      }]
    }]
  }
}

```
