# Input Observation: Oxygen Saturation (1) - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Input Observation: Oxygen Saturation (1)**

## Example Observation: Input Observation: Oxygen Saturation (1)

**status**: Final

**category**: Vital Signs

**code**: Oxygen saturation in Arterial blood by Pulse oximetry

**subject**: [Anonymous Patient Female, DoB: 1959-04-12](Patient-patient-001.md)

**encounter**: [Encounter: status = completed; class = ambulatory; actualPeriod = 2026-03-01 10:00:00+0000 --> 2026-03-01 10:30:00+0000](Encounter-encounter-001.md)

**effective**: 2026-03-01 10:10:00+0000

**performer**: [Clinical Reviewer](Practitioner-practitioner-001.md)

**value**: 92 % (Details: UCUM code% = '%')

**note**: 

> 

NEWS2 SpO2 scale: scale-1; supplemental oxygen: false




## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "sc-01-ai-only-observation-oxygen-saturation-001",
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "vital-signs",
      "display" : "Vital Signs"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "2708-6",
      "display" : "Oxygen saturation in Arterial blood"
    },
    {
      "system" : "http://loinc.org",
      "code" : "59408-5",
      "display" : "Oxygen saturation in Arterial blood by Pulse oximetry"
    }],
    "text" : "Oxygen saturation in Arterial blood by Pulse oximetry"
  },
  "subject" : {
    "reference" : "Patient/patient-001"
  },
  "encounter" : {
    "reference" : "Encounter/encounter-001"
  },
  "effectiveDateTime" : "2026-03-01T10:10:00Z",
  "performer" : [{
    "reference" : "Practitioner/practitioner-001"
  }],
  "valueQuantity" : {
    "value" : 92,
    "unit" : "%",
    "system" : "http://unitsofmeasure.org",
    "code" : "%"
  },
  "note" : [{
    "text" : "NEWS2 SpO2 scale: scale-1; supplemental oxygen: false"
  }]
}

```
