# Provenance: Secondary Use Example - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Provenance: Secondary Use Example**

## Example Provenance: Provenance: Secondary Use Example

Profile: [Trust AI Provenance](StructureDefinition-trust-ai-provenance.md)

Provenance for [Observation AI-assisted early warning risk assessment](Observation-sc-01-ai-only-ai-observation-risk-001.md)

Summary

| | |
| :--- | :--- |
| Occurrence | 2026-03-01 10:15:00+0000 --> 2026-03-01 10:15:03+0000 |
| Recorded | 2026-03-01 10:15:04+0000 |
| Activity | secondary-use-ai-validation |
| Authorization | * Vital Interests (Art. 6(1)(d))
* Health or Social Care (Art. 9(2)(h))
 |
| Subject | [Anonymous Patient Female, DoB: 1959-04-12](Patient-patient-001.md) |
| Encounter | [Encounter: status = completed; class = ambulatory; actualPeriod = 2026-03-01 10:00:00+0000 --> 2026-03-01 10:30:00+0000](Encounter-encounter-001.md) |

**Agents**

* **who**: [Device: extension = ,->DocumentReference: extension = Not Clinically Validated,,,; status = current; type = AI Model Card; date = 2026-03-01 10:00:00+0000; description = Synthetic model card for a deterministic AI-output simulation component used in the PoC.,->DocumentReference: status = current; identifier = Trust AI Registration Number: trust-ai-000123; status = active; manufacturer = ExampleMed AI GmbH; note = Synthetic maintenance information for PoC purposes.,AI-assisted early warning risk assessment based on synthetic NEWS2-inspired vital parameters.](Device-device-riskassist-ai.md)

**Entities**

* **Role**: Source
  * **What**: [Observation Body temperature](Observation-sc-04-correction-exp-observation-temperature-001.md)



## Resource Content

```json
{
  "resourceType" : "Provenance",
  "id" : "example-secondary-use-provenance",
  "meta" : {
    "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-provenance"]
  },
  "extension" : [{
    "url" : "http://example.org/fhir/trust-ai-transparency/StructureDefinition/usage-category",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://example.org/fhir/trust-ai-transparency/CodeSystem/usage-category-cs",
        "code" : "secondary-use",
        "display" : "Secondary Use"
      }]
    }
  },
  {
    "url" : "http://example.org/fhir/trust-ai-transparency/StructureDefinition/case-specific-indication",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://example.org/fhir/trust-ai-transparency/CodeSystem/trust-ai-case-specific-indication-cs",
        "code" : "prognosis",
        "display" : "Prognostic Prediction"
      }]
    }
  },
  {
    "url" : "http://example.org/fhir/trust-ai-transparency/StructureDefinition/automated-decision-flag",
    "valueBoolean" : false
  },
  {
    "url" : "http://example.org/fhir/trust-ai-transparency/StructureDefinition/secondary-use-purpose",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://example.org/fhir/trust-ai-transparency/CodeSystem/secondary-use-purpose-cs",
        "code" : "scientific-research",
        "display" : "Scientific Research"
      }]
    }
  },
  {
    "url" : "http://example.org/fhir/trust-ai-transparency/StructureDefinition/data-permit",
    "valueIdentifier" : {
      "system" : "http://example.org/fhir/sid/data-permit",
      "value" : "EHDS-PERMIT-2026-0001"
    }
  }],
  "target" : [{
    "reference" : "Observation/sc-01-ai-only-ai-observation-risk-001"
  }],
  "occurredPeriod" : {
    "start" : "2026-03-01T10:15:00Z",
    "end" : "2026-03-01T10:15:03Z"
  },
  "recorded" : "2026-03-01T10:15:04Z",
  "authorization" : [{
    "concept" : {
      "coding" : [{
        "system" : "http://example.org/fhir/trust-ai-transparency/CodeSystem/gdpr-art6-codesystem",
        "code" : "gdpr-art-6-1-d"
      }]
    }
  },
  {
    "concept" : {
      "coding" : [{
        "system" : "http://example.org/fhir/trust-ai-transparency/CodeSystem/gdpr-art9-codesystem",
        "code" : "gdpr-art-9-2-h"
      }]
    }
  }],
  "activity" : {
    "text" : "secondary-use-ai-validation"
  },
  "patient" : {
    "reference" : "Patient/patient-001"
  },
  "encounter" : {
    "reference" : "Encounter/encounter-001"
  },
  "agent" : [{
    "who" : {
      "reference" : "Device/device-riskassist-ai"
    }
  }],
  "entity" : [{
    "role" : "source",
    "what" : {
      "reference" : "Observation/sc-04-correction-exp-observation-temperature-001"
    }
  }]
}

```
