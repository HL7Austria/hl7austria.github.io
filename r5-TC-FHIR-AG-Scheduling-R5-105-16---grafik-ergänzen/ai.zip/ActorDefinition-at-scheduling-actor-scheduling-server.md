# HL7.AT.FHIR.TC.WG.SCHEDULING.R5\HL7® AT Scheduling Server ActorDefinition - FHIR® v5.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HL7® AT Scheduling Server ActorDefinition**

## ActorDefinition: HL7® AT Scheduling Server ActorDefinition 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://hl7.at/fhir/TC-FHIR-AG-Scheduling-R5/R5/ActorDefinition/at-scheduling-actor-scheduling-server | *Version*:0.2.0 | |
| Draft as of 2026-03-06 | *Responsible:*HL7® Austria, TC FHIR® | *Computable Name*: |

 
A system providing the FHIR API for appointment booking and related data 



## Resource Content

```json
{
  "resourceType" : "ActorDefinition",
  "id" : "at-scheduling-actor-scheduling-server",
  "url" : "http://hl7.at/fhir/TC-FHIR-AG-Scheduling-R5/R5/ActorDefinition/at-scheduling-actor-scheduling-server",
  "version" : "0.2.0",
  "title" : "HL7® AT Scheduling Server ActorDefinition",
  "status" : "draft",
  "date" : "2026-03-06T11:03:45+00:00",
  "publisher" : "HL7® Austria, TC FHIR®",
  "description" : "A system providing the FHIR API for appointment booking and related data",
  "type" : "system",
  "documentation" : "A Scheduling Server provides data relevant to appointment scheduling, including Healthcare Service Providers, Healthcare Services, available time slots. It offers services such as creating patients, booking, editing and cancelling appointments."
}

```
