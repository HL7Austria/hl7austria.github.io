<?xml version="1.0" encoding="UTF-8"?>
<sch:schema xmlns:sch="http://purl.oclc.org/dsdl/schematron" queryBinding="xslt2">
  <sch:ns prefix="f" uri="http://hl7.org/fhir"/>
  <sch:ns prefix="h" uri="http://www.w3.org/1999/xhtml"/>
  <!-- 
    This file contains just the constraints for the profile ValueSet
    It includes the base constraints for the resource as well.
    Because of the way that schematrons and containment work, 
    you may need to use this schematron fragment to build a, 
    single schematron that validates contained resources (if you have any) 
  -->
  <sch:pattern>
    <sch:title>f:ValueSet/f:compose/f:include</sch:title>
    <sch:rule context="f:ValueSet/f:compose/f:include">
      <sch:assert test="count(f:extension[@url = 'https://fhir.hl7.at/core/r5/StructureDefinition/at-core-ext-valueset-systemoid']) &lt;= 1">extension with URL = 'https://fhir.hl7.at/core/r5/StructureDefinition/at-core-ext-valueset-systemoid': maximum cardinality of 'extension' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:ValueSet/f:expansion/f:contains</sch:title>
    <sch:rule context="f:ValueSet/f:expansion/f:contains">
      <sch:assert test="count(f:extension[@url = 'https://fhir.hl7.at/core/r5/StructureDefinition/at-core-ext-valueset-systemoid']) &lt;= 1">extension with URL = 'https://fhir.hl7.at/core/r5/StructureDefinition/at-core-ext-valueset-systemoid': maximum cardinality of 'extension' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
</sch:schema>
