# HL7ATCoreOrganizationExample02-MultipleVPNR - HL7® Austria FHIR® Core Implementation Guide v2.1.0

## Example Organization: HL7ATCoreOrganizationExample02-MultipleVPNR

Profile: [HL7® AT Core Organization Profile](StructureDefinition-at-core-organization.md)

Landeskrankenhaus Hall in Tirol (Allgemeine Krankenanstalt) (OID:1.2.40.0.34.3.1.1061)

-------

| | |
| :--- | :--- |
| Type: | Allgemeine Krankenanstalt |
| Other Ids: | * `urn:oid:1.2.40.0.10.1.4.3.2`/438968
* `urn:oid:1.2.40.0.10.1.4.3.2`/833477
 |
| Contact Detail | * [info.pkh@tirol-kliniken.at](mailto:info.pkh@tirol-kliniken.at)
* Milser Straße 10 Hall in Tirol Tirol 6060 AUT (work)
 |



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "HL7ATCoreOrganizationExample02-MultipleVPNR",
  "meta" : {
    "profile" : ["https://fhir.hl7.at/core/r5/StructureDefinition/at-core-organization"]
  },
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:1.2.40.0.34.3.1.1061",
    "assigner" : {
      "display" : "Bundesministerium für Gesundheit"
    }
  },
  {
    "system" : "urn:oid:1.2.40.0.10.1.4.3.2",
    "value" : "438968",
    "assigner" : {
      "display" : "Dachverband der österreichischen Sozialversicherungsträger"
    }
  },
  {
    "system" : "urn:oid:1.2.40.0.10.1.4.3.2",
    "value" : "833477",
    "assigner" : {
      "display" : "Dachverband der österreichischen Sozialversicherungsträger"
    }
  }],
  "type" : [{
    "coding" : [{
      "system" : "https://termgit.elga.gv.at/CodeSystem/elga-gtelvogdarollen",
      "code" : "300",
      "display" : "Allgemeine Krankenanstalt"
    }]
  }],
  "name" : "Landeskrankenhaus Hall in Tirol",
  "contact" : [{
    "telecom" : [{
      "system" : "email",
      "value" : "info.pkh@tirol-kliniken.at",
      "use" : "work"
    }],
    "address" : {
      "use" : "work",
      "type" : "both",
      "line" : ["Milser Straße 10"],
      "_line" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
          "valueString" : "Milser Straße"
        },
        {
          "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
          "valueString" : "10"
        }]
      }],
      "city" : "Hall in Tirol",
      "state" : "Tirol",
      "postalCode" : "6060",
      "country" : "AUT"
    }
  }]
}

```
