# Communication request over directed messaging. - HL7® Austria TC FHIR® Messaging v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Communication request over directed messaging.**

## MessageDefinition: Communication request over directed messaging. 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.hl7.at/fhir/ATMessaging/0.1.0/MessageDefinition/at-messaging-communicationrequest-message | *Version*:0.1.0 |
| Draft as of 2026-01-21 | *Computable Name*:ATMessagingCommunicationRequestMessage |

 
Regulates the resources to be used in a directed message when performing a CommunicationRequest. 

**url**: [MessageDefinition Communication request over directed messaging.](MessageDefinition-at-messaging-communicationrequest-message.md)

**version**: 0.1.0

**versionAlgorithm**: [Version Algorithm: semver](http://hl7.org/fhir/R5/codesystem-version-algorithm.html#version-algorithm-semver) (SemVer)

**name**: ATMessagingCommunicationRequestMessage

**title**: Communication request over directed messaging.

**status**: Draft

**date**: 2026-01-21

**publisher**: HL7® Austria, TC FHIR®

**contact**: HL7® Austria, TC FHIR®: [https://hl7.at/technische-komitees/tc-fhir/](https://hl7.at/technische-komitees/tc-fhir/),[tc-fhir@hl7.at](mailto:tc-fhir@hl7.at), Technical Committee for FHIR® at HL7® Austria: [tc-fhir@hl7.at](mailto:tc-fhir@hl7.at)

**description**: 

Regulates the resources to be used in a directed message when performing a CommunicationRequest.

**jurisdiction**: Austria

**event**: [ATMessagingEventType: request](CodeSystem-at-messaging-event-type.md#at-messaging-event-type-request) (Message to initiate a workflow to request an action or a communication.)

**category**: Consequence

> **focus****code**: CommunicationRequest**profile**: [AT Messaging CommunicationRequest](StructureDefinition-at-messaging-communication-request.md)**min**: 1**max**: 1

> **focus****code**: Patient**profile**: [HL7® AT Core Patient Profile](http://hl7.at/fhir/HL7ATCoreProfiles/5.0.0/2.0.0/StructureDefinition-at-core-patient.html)**min**: 1**max**: 1

> **focus****code**: Encounter**min**: 0**max**: 1

> **allowedResponse****message**: [Communication over directed messaging.](MessageDefinition-at-messaging-communication-message.md)**situation**: 

As soon as the receiving system has processed the message successfully when the result of the CommunicationRequest cannot be fulfilled (yet) or is fulfilled through a Communication (e.g. telephone call or chat) and in error cases.


> **allowedResponse****message**: [Document transfer over directed messaging.](MessageDefinition-at-messaging-document-message.md)**situation**: 

As soon as the receiving system has processed the message successfully when the result of the CommunicationRequest is available as document and can be transfered to the requesting party.




## Resource Content

```json
{
  "resourceType" : "MessageDefinition",
  "id" : "at-messaging-communicationrequest-message",
  "url" : "http://fhir.hl7.at/fhir/ATMessaging/0.1.0/MessageDefinition/at-messaging-communicationrequest-message",
  "version" : "0.1.0",
  "versionAlgorithmCoding" : {
    "system" : "http://hl7.org/fhir/version-algorithm",
    "code" : "semver"
  },
  "name" : "ATMessagingCommunicationRequestMessage",
  "title" : "Communication request over directed messaging.",
  "status" : "draft",
  "date" : "2026-01-21",
  "publisher" : "HL7® Austria, TC FHIR®",
  "contact" : [
    {
      "name" : "HL7® Austria, TC FHIR®",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://hl7.at/technische-komitees/tc-fhir/"
        },
        {
          "system" : "email",
          "value" : "tc-fhir@hl7.at"
        }
      ]
    },
    {
      "name" : "Technical Committee for FHIR® at HL7® Austria",
      "telecom" : [
        {
          "system" : "email",
          "value" : "tc-fhir@hl7.at"
        }
      ]
    }
  ],
  "description" : "Regulates the resources to be used in a directed message when performing a CommunicationRequest.",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "AT",
          "display" : "Austria"
        }
      ]
    }
  ],
  "eventCoding" : {
    "system" : "http://fhir.hl7.at/fhir/ATMessaging/0.1.0/CodeSystem/at-messaging-event-type",
    "code" : "request"
  },
  "category" : "consequence",
  "focus" : [
    {
      "code" : "CommunicationRequest",
      "profile" : "http://fhir.hl7.at/fhir/ATMessaging/0.1.0/StructureDefinition/at-messaging-communication-request",
      "min" : 1,
      "max" : "1"
    },
    {
      "code" : "Patient",
      "profile" : "http://hl7.at/fhir/HL7ATCoreProfiles/5.0.0/StructureDefinition/at-core-patient",
      "min" : 1,
      "max" : "1"
    },
    {
      "code" : "Encounter",
      "min" : 0,
      "max" : "1"
    }
  ],
  "allowedResponse" : [
    {
      "message" : "http://fhir.hl7.at/fhir/ATMessaging/0.1.0/MessageDefinition/at-messaging-communication-message",
      "situation" : "As soon as the receiving system has processed the message successfully when the result of the CommunicationRequest cannot be fulfilled (yet) or is fulfilled through a Communication (e.g. telephone call or chat) and in error cases."
    },
    {
      "message" : "http://fhir.hl7.at/fhir/ATMessaging/0.1.0/MessageDefinition/at-messaging-document-message",
      "situation" : "As soon as the receiving system has processed the message successfully when the result of the CommunicationRequest is available as document and can be transfered to the requesting party."
    }
  ]
}

```
