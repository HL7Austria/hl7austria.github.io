# HL7.AT.FHIR.MESSAGING.R5\Lab request - FHIR® v5.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Lab request**

## Example Bundle: Lab request



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "96beaf3e-6e2f-40f4-b1d3-02b19c984fb1",
  "meta" : {
    "profile" : [
      "http://fhir.hl7.at/fhir/ATMessaging/0.1.0/StructureDefinition/at-messaging-bundle"
    ]
  },
  "type" : "message",
  "timestamp" : "2026-01-27T21:38:50+02:00",
  "entry" : [
    {
      "fullUrl" : "urn:uuid:777091de-488e-4b23-a283-3fcc2ec262a5",
      "resource" : {
        "resourceType" : "MessageHeader",
        "id" : "777091de-488e-4b23-a283-3fcc2ec262a5",
        "meta" : {
          "profile" : [
            "http://fhir.hl7.at/fhir/ATMessaging/0.1.0/StructureDefinition/at-messaging-message-header"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_777091de-488e-4b23-a283-3fcc2ec262a5\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader 777091de-488e-4b23-a283-3fcc2ec262a5</b></p><a name=\"777091de-488e-4b23-a283-3fcc2ec262a5\"> </a><a name=\"hc777091de-488e-4b23-a283-3fcc2ec262a5\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-at-messaging-message-header.html\">AT Messaging Message Header</a></p></div><p><b>event</b>: <a href=\"CodeSystem-at-messaging-event-type.html#at-messaging-event-type-request\">ATMessagingEventType: request</a> (Message to initiate a workflow to request an action or a communication.)</p><h3>Destinations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint[x]</b></td><td><b>Receiver</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-96beaf3e-6e2f-40f4-b1d3-02b19c984fb1.html#urn-uuid-aeaa7306-7d02-483d-bb50-7ca0f631b04a\">Endpoint: status = active; connectionType = The message is transported over the Matrix protocol.; address = @vienna:externallab.at</a></td><td><a href=\"Bundle-96beaf3e-6e2f-40f4-b1d3-02b19c984fb1.html#urn-uuid-b024548e-7baa-44e7-8862-0246bd96cf4b\">Organization Speziallabor Wien und sonstwo GmbH</a></td></tr></table><p><b>sender</b>: <a href=\"Bundle-269f4c84-7762-47aa-b872-c4f927301485.html#urn-uuid-2d8fedd6-3ccf-4725-97b0-fa9e19cbd8fc\">Practitioner Hannah Huber </a></p><p><b>author</b>: <a href=\"Bundle-269f4c84-7762-47aa-b872-c4f927301485.html#urn-uuid-2d8fedd6-3ccf-4725-97b0-fa9e19cbd8fc\">Practitioner Hannah Huber </a></p><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint[x]</b></td><td><b>Name</b></td><td><b>Software</b></td><td><b>Version</b></td><td><b>Contact</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Bundle-269f4c84-7762-47aa-b872-c4f927301485.html#urn-uuid-4707d4ab-0020-4cc9-8e0f-242f95ce31f3\">Endpoint: status = active; connectionType = The message is transported over the Matrix protocol.; address = @huber:praxisdrhuber.example.at</a></td><td>My AIS</td><td>at.itbusiness.gp</td><td>1.2.3</td><td><a href=\"mailto:office@itbusiness.at\">office@itbusiness.at</a></td></tr></table><p><b>focus</b>: </p><ul><li><a href=\"Bundle-96beaf3e-6e2f-40f4-b1d3-02b19c984fb1.html#urn-uuid-81fd7dbf-5207-4bc5-b7df-89e97dcbbb79\">ServiceRequest Blood test</a></li><li><a href=\"Bundle-269f4c84-7762-47aa-b872-c4f927301485.html#urn-uuid-1a6ed9fa-9ba7-41fa-9d79-24d669aa3273\">Max Mustermann  Male, DoB: 1900-01-01 ( Social Security number: 1234010100)</a></li></ul><p><b>definition</b>: <a href=\"MessageDefinition-at-messaging-servicerequest-message.html\">Service request over directed messaging.</a></p></div>"
        },
        "eventCoding" : {
          "system" : "http://fhir.hl7.at/fhir/ATMessaging/0.1.0/CodeSystem/at-messaging-event-type",
          "code" : "request"
        },
        "destination" : [
          {
            "endpointReference" : {
              "reference" : "urn:uuid:aeaa7306-7d02-483d-bb50-7ca0f631b04a"
            },
            "receiver" : {
              "reference" : "urn:uuid:b024548e-7baa-44e7-8862-0246bd96cf4b"
            }
          }
        ],
        "sender" : {
          "reference" : "urn:uuid:2d8fedd6-3ccf-4725-97b0-fa9e19cbd8fc"
        },
        "author" : {
          "reference" : "urn:uuid:2d8fedd6-3ccf-4725-97b0-fa9e19cbd8fc"
        },
        "source" : {
          "endpointReference" : {
            "reference" : "urn:uuid:4707d4ab-0020-4cc9-8e0f-242f95ce31f3"
          },
          "name" : "My AIS",
          "software" : "at.itbusiness.gp",
          "version" : "1.2.3",
          "contact" : {
            "system" : "email",
            "value" : "office@itbusiness.at"
          }
        },
        "focus" : [
          {
            "reference" : "urn:uuid:81fd7dbf-5207-4bc5-b7df-89e97dcbbb79"
          },
          {
            "reference" : "urn:uuid:1a6ed9fa-9ba7-41fa-9d79-24d669aa3273"
          }
        ],
        "definition" : "http://fhir.hl7.at/fhir/ATMessaging/0.1.0/MessageDefinition/at-messaging-servicerequest-message"
      }
    },
    {
      "fullUrl" : "urn:uuid:aeaa7306-7d02-483d-bb50-7ca0f631b04a",
      "resource" : {
        "resourceType" : "Endpoint",
        "id" : "aeaa7306-7d02-483d-bb50-7ca0f631b04a",
        "meta" : {
          "profile" : [
            "http://fhir.hl7.at/fhir/ATMessaging/0.1.0/StructureDefinition/at-messaging-endpoint"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Endpoint_aeaa7306-7d02-483d-bb50-7ca0f631b04a\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Endpoint aeaa7306-7d02-483d-bb50-7ca0f631b04a</b></p><a name=\"aeaa7306-7d02-483d-bb50-7ca0f631b04a\"> </a><a name=\"hcaeaa7306-7d02-483d-bb50-7ca0f631b04a\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-at-messaging-endpoint.html\">AT Messaging Endpoint</a></p></div><p><b>status</b>: Active</p><p><b>connectionType</b>: <span title=\"Codes:{http://fhir.hl7.at/fhir/ATMessaging/0.1.0/CodeSystem/at-messaging-endpoint-type matrix}\">The message is transported over the Matrix protocol.</span></p><p><b>address</b>: @vienna:externallab.at</p></div>"
        },
        "status" : "active",
        "connectionType" : [
          {
            "coding" : [
              {
                "system" : "http://fhir.hl7.at/fhir/ATMessaging/0.1.0/CodeSystem/at-messaging-endpoint-type",
                "code" : "matrix"
              }
            ]
          }
        ],
        "address" : "@vienna:externallab.at"
      }
    },
    {
      "fullUrl" : "urn:uuid:4707d4ab-0020-4cc9-8e0f-242f95ce31f3",
      "resource" : {
        "resourceType" : "Endpoint",
        "id" : "4707d4ab-0020-4cc9-8e0f-242f95ce31f3",
        "meta" : {
          "profile" : [
            "http://fhir.hl7.at/fhir/ATMessaging/0.1.0/StructureDefinition/at-messaging-endpoint"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Endpoint_4707d4ab-0020-4cc9-8e0f-242f95ce31f3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Endpoint 4707d4ab-0020-4cc9-8e0f-242f95ce31f3</b></p><a name=\"4707d4ab-0020-4cc9-8e0f-242f95ce31f3\"> </a><a name=\"hc4707d4ab-0020-4cc9-8e0f-242f95ce31f3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-at-messaging-endpoint.html\">AT Messaging Endpoint</a></p></div><p><b>status</b>: Active</p><p><b>connectionType</b>: <span title=\"Codes:{http://fhir.hl7.at/fhir/ATMessaging/0.1.0/CodeSystem/at-messaging-endpoint-type matrix}\">The message is transported over the Matrix protocol.</span></p><p><b>address</b>: @huber:praxisdrhuber.example.at</p></div>"
        },
        "status" : "active",
        "connectionType" : [
          {
            "coding" : [
              {
                "system" : "http://fhir.hl7.at/fhir/ATMessaging/0.1.0/CodeSystem/at-messaging-endpoint-type",
                "code" : "matrix"
              }
            ]
          }
        ],
        "address" : "@huber:praxisdrhuber.example.at"
      }
    },
    {
      "fullUrl" : "urn:uuid:81fd7dbf-5207-4bc5-b7df-89e97dcbbb79",
      "resource" : {
        "resourceType" : "ServiceRequest",
        "id" : "81fd7dbf-5207-4bc5-b7df-89e97dcbbb79",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ServiceRequest_81fd7dbf-5207-4bc5-b7df-89e97dcbbb79\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ServiceRequest 81fd7dbf-5207-4bc5-b7df-89e97dcbbb79</b></p><a name=\"81fd7dbf-5207-4bc5-b7df-89e97dcbbb79\"> </a><a name=\"hc81fd7dbf-5207-4bc5-b7df-89e97dcbbb79\"> </a><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 108252007}\">Laboratory procedure</span></p><h3>Codes</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Concept</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 396550006}\">Blood test</span></td></tr></table><p><b>subject</b>: <a href=\"Bundle-269f4c84-7762-47aa-b872-c4f927301485.html#urn-uuid-1a6ed9fa-9ba7-41fa-9d79-24d669aa3273\">Max Mustermann  Male, DoB: 1900-01-01 ( Social Security number: 1234010100)</a></p></div>"
        },
        "status" : "active",
        "intent" : "order",
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://snomed.info/sct",
                "code" : "108252007",
                "display" : "Laboratory procedure"
              }
            ]
          }
        ],
        "code" : {
          "concept" : {
            "coding" : [
              {
                "system" : "http://snomed.info/sct",
                "code" : "396550006",
                "display" : "Blood test"
              }
            ]
          }
        },
        "subject" : {
          "reference" : "urn:uuid:1a6ed9fa-9ba7-41fa-9d79-24d669aa3273"
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:1a6ed9fa-9ba7-41fa-9d79-24d669aa3273",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "1a6ed9fa-9ba7-41fa-9d79-24d669aa3273",
        "meta" : {
          "profile" : [
            "http://hl7.at/fhir/HL7ATCoreProfiles/5.0.0/StructureDefinition/at-core-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_1a6ed9fa-9ba7-41fa-9d79-24d669aa3273\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient 1a6ed9fa-9ba7-41fa-9d79-24d669aa3273</b></p><a name=\"1a6ed9fa-9ba7-41fa-9d79-24d669aa3273\"> </a><a name=\"hc1a6ed9fa-9ba7-41fa-9d79-24d669aa3273\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"http://hl7.at/fhir/HL7ATCoreProfiles/5.0.0/2.0.0/StructureDefinition-at-core-patient.html\">HL7® AT Core Patient Profile</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Max Mustermann  Male, DoB: 1900-01-01 ( Social Security number: 1234010100)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Other Ids (see the one above)\">Other Ids:</td><td colspan=\"3\"><ul><li>National unique individual identifier/GH:oeLdSEb0l+8kSdJWjOYyYmnYki0=</li><li>Patient internal identifier/0815</li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li><a href=\"mailto:office@hl7.at\">office@hl7.at</a></li><li><a href=\"tel:+436501234567890\">+436501234567890</a></li><li>Landstrasse 1 Stock 9 Tür 42 Linz Oberösterreich 4020 AUT (home)</li></ul></td></tr></table></div>"
        },
        "identifier" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "SS",
                  "display" : "Social Security number"
                }
              ]
            },
            "system" : "urn:oid:1.2.40.0.10.1.4.3.1",
            "value" : "1234010100",
            "assigner" : {
              "display" : "Dachverband der österreichischen Sozialversicherungsträger"
            }
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "NI",
                  "display" : "National unique individual identifier"
                }
              ]
            },
            "system" : "urn:oid:1.2.40.0.10.2.1.1.149",
            "value" : "GH:oeLdSEb0l+8kSdJWjOYyYmnYki0=",
            "assigner" : {
              "display" : "Bundesministerium für Inneres"
            }
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "PI",
                  "display" : "Patient internal identifier"
                }
              ]
            },
            "system" : "urn:oid:1.2.3.4.5",
            "value" : "0815",
            "assigner" : {
              "display" : "Ein GDA in Österreich"
            }
          }
        ],
        "name" : [
          {
            "family" : "Mustermann",
            "given" : ["Max"],
            "prefix" : ["DI"]
          }
        ],
        "telecom" : [
          {
            "system" : "email",
            "value" : "office@hl7.at",
            "use" : "work"
          },
          {
            "system" : "phone",
            "value" : "+436501234567890",
            "use" : "home"
          }
        ],
        "gender" : "male",
        "birthDate" : "1900-01-01",
        "address" : [
          {
            "use" : "home",
            "type" : "both",
            "line" : ["Landstrasse 1 Stock 9 Tür 42"],
            "_line" : [
              {
                "extension" : [
                  {
                    "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
                    "valueString" : "Landstrasse"
                  },
                  {
                    "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
                    "valueString" : "1"
                  },
                  {
                    "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-additionalLocator",
                    "valueString" : "Stock 9 Tür 42"
                  },
                  {
                    "url" : "http://hl7.at/fhir/HL7ATCoreProfiles/5.0.0/StructureDefinition/at-core-ext-address-additionalInformation",
                    "valueString" : "Lift vorhanden"
                  }
                ]
              }
            ],
            "city" : "Linz",
            "state" : "Oberösterreich",
            "postalCode" : "4020",
            "country" : "AUT"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:2d8fedd6-3ccf-4725-97b0-fa9e19cbd8fc",
      "resource" : {
        "resourceType" : "Practitioner",
        "id" : "2d8fedd6-3ccf-4725-97b0-fa9e19cbd8fc",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_2d8fedd6-3ccf-4725-97b0-fa9e19cbd8fc\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner 2d8fedd6-3ccf-4725-97b0-fa9e19cbd8fc</b></p><a name=\"2d8fedd6-3ccf-4725-97b0-fa9e19cbd8fc\"> </a><a name=\"hc2d8fedd6-3ccf-4725-97b0-fa9e19cbd8fc\"> </a><p><b>name</b>: Hannah Huber </p></div>"
        },
        "name" : [
          {
            "family" : "Huber",
            "given" : ["Hannah"],
            "prefix" : ["Dr. med."]
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:b024548e-7baa-44e7-8862-0246bd96cf4b",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "b024548e-7baa-44e7-8862-0246bd96cf4b",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_b024548e-7baa-44e7-8862-0246bd96cf4b\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization b024548e-7baa-44e7-8862-0246bd96cf4b</b></p><a name=\"b024548e-7baa-44e7-8862-0246bd96cf4b\"> </a><a name=\"hcb024548e-7baa-44e7-8862-0246bd96cf4b\"> </a><p><b>type</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/organization-type prov}\">Healthcare Provider</span></p><p><b>name</b>: Speziallabor Wien und sonstwo GmbH</p></div>"
        },
        "type" : [
          {
            "coding" : [
              {
                "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
                "code" : "prov"
              }
            ]
          }
        ],
        "name" : "Speziallabor Wien und sonstwo GmbH"
      }
    }
  ]
}

```
