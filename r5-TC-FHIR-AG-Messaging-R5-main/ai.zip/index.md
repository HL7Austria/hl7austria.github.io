# Home - HL7® Austria TC FHIR® Messaging v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://fhir.hl7.at/fhir/ATMessaging/0.1.0/ImplementationGuide/hl7.at.fhir.messaging.r5 | *Version*:0.1.0 |
| Draft as of 2026-01-28 | *Computable Name*:ATMessaging |

# ATMessaging

Feel free to modify this index page with your own awesome content!

