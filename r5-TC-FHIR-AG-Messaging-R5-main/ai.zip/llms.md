# hl7.at.fhir.messaging.r5#0.1.0: HL7® Austria TC FHIR® Messaging

## Pages

* [HL7.AT.FHIR.MESSAGING.R5\Home - FHIR® v5.0.0](index.md)
* [HL7.AT.FHIR.MESSAGING.R5\Artifacts Summary - FHIR® v5.0.0](artifacts.md)

## Resources

### CodeSystems

* [AT Messaging Endpoint Type](CodeSystem-at-messaging-endpoint-type.md)
* [AT Messaging Event Type](CodeSystem-at-messaging-event-type.md)

### ValueSets

* [AT Messaging Endpoint Type ValueSet](ValueSet-at-messaging-endpoint-type-vs.md)
* [AT Message Event Type ValueSet](ValueSet-at-messaging-event-type-vs.md)

### Complex-type Profiles

* [AT Messaging Communication Attachment](StructureDefinition-at-messaging-communication-attachment.md)

### Resource Profiles

* [AT Messaging Message Bundle](StructureDefinition-at-messaging-bundle.md)
* [AT Messaging CommunicationRequest](StructureDefinition-at-messaging-communication-request.md)
* [AT Messaging Communication](StructureDefinition-at-messaging-communication.md)
* [AT Messaging Endpoint](StructureDefinition-at-messaging-endpoint.md)
* [AT Messaging Message Header](StructureDefinition-at-messaging-message-header.md)
* [AT Messaging Task](StructureDefinition-at-messaging-task.md)

### ImplementationGuides

* [HL7® Austria TC FHIR® Messaging](index.md)

### MessageDefinitions

* [Communication over directed messaging.](MessageDefinition-at-messaging-communication-message.md)
* [Communication request over directed messaging.](MessageDefinition-at-messaging-communicationrequest-message.md)
* [Document transfer over directed messaging.](MessageDefinition-at-messaging-document-message.md)
* [Service status update over directed messaging.](MessageDefinition-at-messaging-service-status-message.md)
* [Service request over directed messaging.](MessageDefinition-at-messaging-servicerequest-message.md)

### Examples

* [269f4c84-7762-47aa-b872-c4f927301485 (Bundle)](Bundle-269f4c84-7762-47aa-b872-c4f927301485.md)
* [63874621-5550-410a-b893-ca890614cf6e (Bundle)](Bundle-63874621-5550-410a-b893-ca890614cf6e.md)
* [6df9d997-d34a-448b-944e-8721c49e0939 (Bundle)](Bundle-6df9d997-d34a-448b-944e-8721c49e0939.md)
* [96beaf3e-6e2f-40f4-b1d3-02b19c984fb1 (Bundle)](Bundle-96beaf3e-6e2f-40f4-b1d3-02b19c984fb1.md)
* [ab66186f-9d91-44b9-8459-bdee4e850bac (Bundle)](Bundle-ab66186f-9d91-44b9-8459-bdee4e850bac.md)
* [08327a3a-1f52-4ec0-9b90-ac17fd6e06b2 (Communication)](Communication-08327a3a-1f52-4ec0-9b90-ac17fd6e06b2.md)
* [c7090292-dc27-4d90-a500-7e4110217947 (CommunicationRequest)](CommunicationRequest-c7090292-dc27-4d90-a500-7e4110217947.md)
* [89c89a84-bce7-4c5d-b6f6-49690eea5b06 (MessageHeader)](MessageHeader-89c89a84-bce7-4c5d-b6f6-49690eea5b06.md)
* [81fd7dbf-5207-4bc5-b7df-89e97dcbbb79 (ServiceRequest)](ServiceRequest-81fd7dbf-5207-4bc5-b7df-89e97dcbbb79.md)
