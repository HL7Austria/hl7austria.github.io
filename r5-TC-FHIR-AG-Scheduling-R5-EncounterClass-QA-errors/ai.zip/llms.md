# hl7.at.fhir.tc.wg.scheduling.r5#0.2.0: Austrian Appointment Scheduling (R5)

## Pages

* [HL7.AT.FHIR.TC.WG.SCHEDULING.R5\Home - FHIR® v5.0.0](index.md)
* [HL7.AT.FHIR.TC.WG.SCHEDULING.R5\Artifacts Summary - FHIR® v5.0.0](artifacts.md)
* [HL7.AT.FHIR.TC.WG.SCHEDULING.R5\Interactions - FHIR® v5.0.0](interactions.md)
* [HL7.AT.FHIR.TC.WG.SCHEDULING.R5\Actors - FHIR® v5.0.0](actors.md)
* [HL7.AT.FHIR.TC.WG.SCHEDULING.R5\Scenarios - FHIR® v5.0.0](scenarios.md)

## Resources

### ValueSets

* [AT Scheduling Service Type](ValueSet-AtSchedulingServiceType.md)

### Resource Profiles

* [HL7® AT Scheduling Appointment Profile](StructureDefinition-at-scheduling-appointment.md)
* [HL7® AT Scheduling HealthcareService Profile](StructureDefinition-at-scheduling-healthcareservice.md)
* [HL7® AT Scheduling Schedule Profile](StructureDefinition-at-scheduling-schedule.md)
* [HL7® AT Scheduling Slot Profile](StructureDefinition-at-scheduling-slot.md)

### Extensions

* [Appointment Booking URL](StructureDefinition-appointment-booking-url.md)
* [Appointment Postponement Reason](StructureDefinition-appointment-postponementReason.md)
* [The policy for a cancellation](StructureDefinition-at-scheduling-ext-cancellationPolicy.md)
* [Slot Encounter Class](StructureDefinition-slot-encounter-class.md)
* [VirtualServiceDetail](StructureDefinition-virtual-service-detail.md)

### ActorDefinitions

* [HL7® AT Scheduling Client ActorDefinition](ActorDefinition-at-scheduling-actor-scheduling-client.md)
* [HL7® AT Scheduling Server ActorDefinition](ActorDefinition-at-scheduling-actor-scheduling-server.md)

### ImplementationGuides

* [Austrian Appointment Scheduling (R5)](index.md)

### OperationDefinitions

* [Book_Appointment_Operation](OperationDefinition-appointment-book.md)
* [Find_HealthcareService_Provider](OperationDefinition-healthcareService-provider-find.md)
* [Hold_Slot_Operation](OperationDefinition-slot-hold.md)

### Examples

* [HL7ATSchedulingAppointmentExample01 (Appointment)](Appointment-HL7ATSchedulingAppointmentExample01.md)
* [Allgemeinmedizinische Versorgung (HealthcareService)](HealthcareService-HL7ATSchedulingHealthcareServiceExample01.md)
* [HL7ATCorePatientExample01 (Patient)](Patient-HL7ATCorePatientExample01.md)
* [HL7ATSchedulingScheduleExample01 (Schedule)](Schedule-HL7ATSchedulingScheduleExample01.md)
* [HL7ATSchedulingScheduleExample02 (Schedule)](Schedule-HL7ATSchedulingScheduleExample02.md)
* [HL7ATSchedulingScheduleExample03 (Schedule)](Schedule-HL7ATSchedulingScheduleExample03.md)
* [HL7ATSchedulingSlotExample01-free (Slot)](Slot-HL7ATSchedulingSlotExample01-free.md)
* [HL7ATSchedulingSlotExample02-VirtualVisit (Slot)](Slot-HL7ATSchedulingSlotExample02-VirtualVisit.md)
* [HL7ATSchedulingSlotExample03-selectable-encounterClass (Slot)](Slot-HL7ATSchedulingSlotExample03-selectable-encounterClass.md)
* [HL7ATSchedulingSlotExample04-external-booking-URL (Slot)](Slot-HL7ATSchedulingSlotExample04-external-booking-URL.md)
