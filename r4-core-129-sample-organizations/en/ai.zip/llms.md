# hl7.at.fhir.core.r4#2.1.0: HL7® Austria FHIR® Core Implementation Guide(en)

## Pages

* [Home](index.md)
* [Tests](tests.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [CodeSystem for Austrian Funktionscodes Excerpt](CodeSystem-at-core-funktionscode.md)

### ValueSets

* [HL7AT Core vbPK](ValueSet-at-core-vbpk.md)
* [ValueSet for Austrian Funktionscodes Excerpt](ValueSet-at-funktionscode-vs.md)

### Complex-type Profiles

* [HL7® AT Core Address Profile](StructureDefinition-at-core-address.md)

### Resource Profiles

* [HL7® AT Core HealthcareService Profile](StructureDefinition-at-core-HealthcareService.md)
* [HL7® AT Core Location Profile](StructureDefinition-at-core-location.md)
* [HL7® AT Core Organization Profile](StructureDefinition-at-core-organization.md)
* [HL7® AT Core Patient Profile](StructureDefinition-at-core-patient.md)
* [HL7® AT Core Practitioner Profile](StructureDefinition-at-core-practitioner.md)
* [HL7® AT Core PractitionerRole Profile](StructureDefinition-at-core-practitionerRole.md)
* [HL7® AT Core RelatedPerson Profile](StructureDefinition-at-core-related-person.md)
* [HL7® AT Core ValueSet Profile](StructureDefinition-at-core-valueset.md)

### Extensions

* [Address Additional Information](StructureDefinition-at-core-ext-address-additionalInformation.md)
* [Address Municipality Code (Gemeindecode)](StructureDefinition-at-core-ext-address-municipalityCode.md)
* [Address Municipality Key (Gemeindekennziffer)](StructureDefinition-at-core-ext-address-municipalityKey.md)
* [Composition Terminology Date](StructureDefinition-at-core-ext-composition-terminologyDate.md)
* [Administrative Gender Addition](StructureDefinition-at-core-ext-gender-administrativeGenderAddition.md)
* [Patient Religion](StructureDefinition-at-core-ext-patient-religion.md)
* [System OID](StructureDefinition-at-core-ext-valueset-systemoid.md)

### ImplementationGuides

* [HL7® Austria FHIR® Core Implementation Guide](ImplementationGuide-hl7.at.fhir.core.r4.md)

### TestScripts

* [HL7® AT Core TestScript - Patient Create](TestScript-testscript-patient-create-at-core.md)
* [HL7® AT Core TestScript - Patient Update](TestScript-testscript-patient-update-at-core.md)

### Examples

* [Rheumatology Service (HealthcareService)](HealthcareService-HealthcareServiceRheumatologyExample.md)
* [Campus Graz (Location)](Location-HL7ATCoreLocationGraz.md)
* [Campus Linz (Location)](Location-HL7ATCoreLocationLinz.md)
* [Bildungsverein Perspektiva (Organization)](Organization-HL7ATCoreOrganizationBildungsvereinPerspektiva.md)
* [Amadeus Spital (Organization)](Organization-HL7ATCoreOrganizationExample01.md)
* [Landeskrankenhaus Hall in Tirol (Organization)](Organization-HL7ATCoreOrganizationExample02-MultipleVPNR.md)
* [AlpenData Solutions GmbH (Organization)](Organization-OrganizationAlpenDataSolutionsGmbH.md)
* [Alpenländische Gesundheitskasse (Organization)](Organization-OrganizationAlpenlaendischeGesundheitskasse.md)
* [Gemeindeamt Sonnenfeld (Organization)](Organization-OrganizationStadtgemeindeSonnenfeld.md)
* [HL7ATCorePatientCreateTestExample (Patient)](Patient-HL7ATCorePatientCreateTestExample.md)
* [HL7ATCorePatientExample01 (Patient)](Patient-HL7ATCorePatientExample01.md)
* [HL7ATCorePatientExample02-deceasedTime (Patient)](Patient-HL7ATCorePatientExample02-deceasedTime.md)
* [HL7ATCorePatientExample03-deceasedBoolean (Patient)](Patient-HL7ATCorePatientExample03-deceasedBoolean.md)
* [HL7ATCorePatientExample04-Full (Patient)](Patient-HL7ATCorePatientExample04-Full.md)
* [HL7ATCorePatientExample05-FullElga (Patient)](Patient-HL7ATCorePatientExample05-FullElga.md)
* [HL7ATCorePatientExample06-GenderExtension (Patient)](Patient-HL7ATCorePatientExample06-GenderExtension.md)
* [HL7ATCorePatientExample07-MunicipalityCode (Patient)](Patient-HL7ATCorePatientExample07-MunicipalityCode.md)
* [HL7ATCorePatientUpdateTestExample (Patient)](Patient-HL7ATCorePatientUpdateTestExample.md)
* [PatientFelixGruber (Patient)](Patient-PatientFelixGruber.md)
* [HL7ATCorePractitionerExample01 (Practitioner)](Practitioner-HL7ATCorePractitionerExample01.md)
* [HL7ATCorePractitionerRoleExample01 (PractitionerRole)](PractitionerRole-HL7ATCorePractitionerRoleExample01.md)
* [RelatedPersonMartinGruber (RelatedPerson)](RelatedPerson-RelatedPersonMartinGruber.md)
