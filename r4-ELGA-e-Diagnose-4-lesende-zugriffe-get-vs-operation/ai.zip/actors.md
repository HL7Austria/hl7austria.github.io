# HL7.AT.FHIR.ELGA.EDIAG.R4\Akteure - FHIR® v4.0.1

* [**Table of Contents**](toc.md)
* **Akteure**

## Akteure

Dieses Kapitel beschreibt die an der e-Diagnose beteiligten Akteure, deren Berechtigungen sowie die vorgesehenen Zugriffswege.

### Rollen und Berechtigungen

An der e-Diagnose sind insbesondere ELGA-Teilnehmer sowie Gesundheitsdiensteanbieter (GDA) beteiligt. Die detaillierten Berechtigungen der einzelnen ELGA-Rollen sind in der Architektur beschrieben.

| | |
| :--- | :--- |
| **ELGA-Teilnehmer** | 🟢**Lesen**· 🟠**Schreiben**↳ Schreiben umfasst in diesem Zusammenhang das Löschen einzelner Einträge bzw. Summary-Listenversionen. |
| **GDA** | 🟢**Lesen**· 🟢**Schreiben**· 🟠**Stornieren** |

