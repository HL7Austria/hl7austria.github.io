# ELGA-E-MEDIKATION-R5.ELGA.HL7.AT\1 ELGA e-Medication Prescription with multiple MedicationRequests (eMedPrescriptionAsRequestOrchestration) - Testing - FHIR® v5.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **1 ELGA e-Medication Prescription with multiple MedicationRequests (eMedPrescriptionAsRequestOrchestration)**

ELGA e-Medikation FHIR R5 Implementierungsleitfaden - Local Development build (v0.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://fhir.hl7.at/elga-e-medikation-R5/history.html)

*  [Content](StructureDefinition-eMed-prescription-with-multiple-eMed-requests.md) 
*  [Detailed Descriptions](StructureDefinition-eMed-prescription-with-multiple-eMed-requests-definitions.md) 
*  [Mappings](StructureDefinition-eMed-prescription-with-multiple-eMed-requests-mappings.md) 
*  [Examples](StructureDefinition-eMed-prescription-with-multiple-eMed-requests-examples.md) 
*  [XML](StructureDefinition-eMed-prescription-with-multiple-eMed-requests.profile.xml.md) 
*  [JSON](StructureDefinition-eMed-prescription-with-multiple-eMed-requests.profile.json.md) 
*  [TTL](StructureDefinition-eMed-prescription-with-multiple-eMed-requests.profile.ttl.md) 

## Resource Profile: eMedPrescriptionAsRequestOrchestration - Testing

| |
| :--- |
| Draft as of 2025-10-07 |

### Test Plans

**No test plans are currently available for the Profile.**

### Test Scripts

**No test scripts are currently available for the Profile.**

 IG © 2024+ [ELGA GmbH](https://www.elga.gv.at/). Package elga-e-medikation-R5.elga.hl7.at#0.0.0 based on [FHIR® 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md)  

