# ELGA-E-MEDIKATION-R5.ELGA.HL7.AT\Support & Impressum (de) - FHIR® v5.0.0

* [**Table of Contents**](toc.md)
* **Support & Impressum (de)**

ELGA e-Medikation FHIR R5 Implementierungsleitfaden - Local Development build (v0.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://fhir.hl7.at/elga-e-medikation-R5/history.html)

## Support & Impressum (de)

* [Technische Angelegenheiten](#technische-angelegenheiten)
* [Terminologien](#terminologien)
* [ELGA](#elga)
* [Impressum](#impressum)
* [Datenschutzerklärung](#datenschutzerklärung)

> **For the english version please click[here](support_en.md).**

Bitte wählen Sie je nach dem Thema der angeforderten Unterstützung einen der folgenden Kanäle.

### Technische Angelegenheiten

Verbesserungsvorschläge oder Fehlermeldungen, die bei der Anwendung des **ELGA FHIR e-Medikations Implementierungsleitfadens in R5** erkannt wurden, können über das GitHub-Ticketsystem unter **[https://github.com/HL7Austria/ELGA-FHIR-e-Medikation-R5/issues/new](https://github.com/HL7Austria/ELGA-FHIR-e-Medikation-R5/issues/new)** eingemeldet werden.

### Terminologien

Fragen zu **Terminologien** können wahrscheinlich unter **[https://termgit.elga.gv.at/](https://termgit.elga.gv.at/)** beantwortet werden.

### ELGA

Bei Fragen zu Ihrem ELGA und ELGA-Portal wenden Sie sich bitte an **[info@elga-serviceline.at](mailto:info@elga-serviceline.at)** oder **[+43 (0)50 124 4411](tel:+43501244411)** (werktags von 7.00 - 19.00 Uhr).

### Impressum

Es gilt das Impressum von **[elga.gv.at/impressum-kontakt](https://www.elga.gv.at/impressum-kontakt/)**.

### Datenschutzerklärung

Es gilt die Datenschutzerklärung von **[elga.gv.at/datenschutzerklaerung](https://www.elga.gv.at/datenschutzerklaerung/)**.

 IG © 2024+ [ELGA GmbH](https://www.elga.gv.at/). Package elga-e-medikation-R5.elga.hl7.at#0.0.0 based on [FHIR® 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md)  

