# ELGA-E-MEDIKATION-R5.ELGA.HL7.AT\1 ELGA e-Medication Prescription with multiple MedicationRequests (eMedPrescriptionAsRequestOrchestration) - FHIR® v5.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **1 ELGA e-Medication Prescription with multiple MedicationRequests (eMedPrescriptionAsRequestOrchestration)**

ELGA e-Medikation FHIR R5 Implementierungsleitfaden - Local Development build (v0.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://fhir.hl7.at/elga-e-medikation-R5/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-eMed-prescription-with-multiple-eMed-requests-definitions.md) 
*  [Mappings](StructureDefinition-eMed-prescription-with-multiple-eMed-requests-mappings.md) 
*  [Examples](StructureDefinition-eMed-prescription-with-multiple-eMed-requests-examples.md) 
*  [XML](StructureDefinition-eMed-prescription-with-multiple-eMed-requests.profile.xml.md) 
*  [JSON](StructureDefinition-eMed-prescription-with-multiple-eMed-requests.profile.json.md) 
*  [TTL](StructureDefinition-eMed-prescription-with-multiple-eMed-requests.profile.ttl.md) 

## Resource Profile: 1 ELGA e-Medication Prescription with multiple MedicationRequests (eMedPrescriptionAsRequestOrchestration) 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://fhir.hl7.at/elga-e-medikation-R5/StructureDefinition/eMed-prescription-with-multiple-eMed-requests | *Version*:0.0.0 | |
| Draft as of 2025-10-07 | *Responsible:*[ELGA GmbH](https://www.elga.gv.at/) | *Computable Name*:eMedPrescriptionAsRequestOrchestration |

 
**Description:**In the course of treatment, the doctor determines that the ELGA participant must be prescribed one or more medicines. A MedicationRequest always consists of exactly one medication (= one medicine). The e-Medication prescription can consist of several MedicationRequests and thus forms a grouping over them. The prescription and it's MedicationRequests are labelled with one unique, common eMED ID. The doctor is responsible for checking the medicines, e.g. for potential interactions, contraindications, dosages, etc. and this is not part of e-Medication. Storing requests without assigning a prescription is not valid. The prescription is considered to have been checked if the associated prescription is saved in e-Medication. 
**Beschreibung:**Im Zuge der Behandlung stellt der Arzt fest, dass dem ELGA Teilnehmer ein oder mehrere Arzneimittel verordnet werden müssen. Eine Verordnung besteht immer nur aus genau einer Medikation (= ein Arzneimittel). Das Rezept kann aus mehreren Verordnungen/MedicationRequests bestehen und bildet somit die Klammer über die Verordnungen/MedicationRequests. Das Rezept und seine Verordnungen/MedicationRequests werden mit einer eindeutigen, gemeinsamen eMED-ID versehen. Die Prüfungen der Arzneimittel z.B. auf potentielle Wechselwirkungen, Kontraindikationen, Dosierungen, etc. erfolgt in der Eigenverantwortung des Arztes und ist nicht Gegenstand der e-Medikation. Eine Speicherung von Verordnungen/MedicationRequests ohne Zuordnung eines Rezeptes ist nicht gültig. Die Verordnung/MedicationRequest wird als geprüft angesehen, wenn die zugeordnete Verordnung in e-Medikation gespeichert ist. 

**Usages:**

* Examples for this Profile: [RequestOrchestration/WYE82A2G8EE1](RequestOrchestration-WYE82A2G8EE1.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/elga-e-medikation-R5.elga.hl7.at|current/StructureDefinition/eMed-prescription-with-multiple-eMed-requests)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [RequestOrchestration](http://hl7.org/fhir/R5/requestorchestration.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [RequestOrchestration](http://hl7.org/fhir/R5/requestorchestration.html) 

**Summary**

Mandatory: 6 elements

**Structures**

This structure refers to these other structures:

* [2 ELGA e-Medication MedicationRequest (eMedRequest)(http://fhir.hl7.at/elga-e-medikation-R5/StructureDefinition/eMed-request)](StructureDefinition-eMed-request.md)
* [HL7® AT Core Patient Profile(http://hl7.at/fhir/HL7ATCoreProfiles/5.0.0/StructureDefinition/at-core-patient)](http://hl7.at/fhir/HL7ATCoreProfiles/5.0.0/2.0.0/StructureDefinition-at-core-patient.html)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [RequestOrchestration](http://hl7.org/fhir/R5/requestorchestration.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [RequestOrchestration](http://hl7.org/fhir/R5/requestorchestration.html) 

**Summary**

Mandatory: 6 elements

**Structures**

This structure refers to these other structures:

* [2 ELGA e-Medication MedicationRequest (eMedRequest)(http://fhir.hl7.at/elga-e-medikation-R5/StructureDefinition/eMed-request)](StructureDefinition-eMed-request.md)
* [HL7® AT Core Patient Profile(http://hl7.at/fhir/HL7ATCoreProfiles/5.0.0/StructureDefinition/at-core-patient)](http://hl7.at/fhir/HL7ATCoreProfiles/5.0.0/2.0.0/StructureDefinition-at-core-patient.html)

 

Other representations of profile: [CSV](StructureDefinition-eMed-prescription-with-multiple-eMed-requests.csv), [Excel](StructureDefinition-eMed-prescription-with-multiple-eMed-requests.xlsx), [Schematron](StructureDefinition-eMed-prescription-with-multiple-eMed-requests.sch) 

 IG © 2024+ [ELGA GmbH](https://www.elga.gv.at/). Package elga-e-medikation-R5.elga.hl7.at#0.0.0 based on [FHIR® 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md)  

