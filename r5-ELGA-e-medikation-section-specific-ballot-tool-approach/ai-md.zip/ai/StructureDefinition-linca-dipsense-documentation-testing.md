# ELGA-E-MEDIKATION-R5.ELGA.HL7.AT\LINCA Dispense (LINCAMedicationDispense) - Testing - FHIR® v5.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **LINCA Dispense (LINCAMedicationDispense)**

ELGA e-Medikation FHIR R5 Implementierungsleitfaden - Local Development build (v0.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://fhir.hl7.at/elga-e-medikation-R5/history.html)

*  [Content](StructureDefinition-linca-dipsense-documentation.md) 
*  [Detailed Descriptions](StructureDefinition-linca-dipsense-documentation-definitions.md) 
*  [Mappings](StructureDefinition-linca-dipsense-documentation-mappings.md) 
*  [XML](StructureDefinition-linca-dipsense-documentation.profile.xml.md) 
*  [JSON](StructureDefinition-linca-dipsense-documentation.profile.json.md) 
*  [TTL](StructureDefinition-linca-dipsense-documentation.profile.ttl.md) 

## Resource Profile: LINCAMedicationDispense - Testing

| |
| :--- |
| Draft as of 2025-10-07 |

### Test Plans

**No test plans are currently available for the Profile.**

### Test Scripts

**No test scripts are currently available for the Profile.**

 IG © 2024+ [ELGA GmbH](https://www.elga.gv.at/). Package elga-e-medikation-R5.elga.hl7.at#0.0.0 based on [FHIR® 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md)  

