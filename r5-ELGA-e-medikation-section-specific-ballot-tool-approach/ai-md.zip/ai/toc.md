# ELGA-E-MEDIKATION-R5.ELGA.HL7.AT\Table of Contents - FHIR® v5.0.0

* **Table of Contents**

ELGA e-Medikation FHIR R5 Implementierungsleitfaden - Local Development build (v0.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://fhir.hl7.at/elga-e-medikation-R5/history.html)

## Table of Contents

| |
| :--- |
| [0 Table of Contents](toc.md) |
| [1 Home - Informationen über diesen Leitfaden (de)](index.md) |
| [2 Einleitung & Abgrenzung (de)](intro_de.md) |
| [3 Anwendungsfälle (de)](usecase_de.md) |
| [4 Support & Impressum (de)](support_de.md) |
| [5 Home - Information about this implementation guide (en)](index_en.md) |
| [6 Intro & Differentiation (en)](intro_en.md) |
| [7 Use Cases (en)](usecase_en.md) |
| [8 Support & Imprint (en)](support_en.md) |
| [9 Artifacts Summary](artifacts.md) |
| [9.1 1 ELGA e-Medication Prescription with multiple MedicationRequests (eMedPrescriptionAsRequestOrchestration)](StructureDefinition-eMed-prescription-with-multiple-eMed-requests.md) |
| [9.2 2 ELGA e-Medication MedicationRequest (eMedRequest)](StructureDefinition-eMed-request.md) |
| [9.3 LINCA Dispense (LINCAMedicationDispense)](StructureDefinition-linca-dipsense-documentation.md) |
| [9.4 Example-eMedPrescriptionAsRequestOrchestration](RequestOrchestration-WYE82A2G8EE1.md) |
| [9.5 Example-eMedRequest](MedicationRequest-Example-eMedRequest.md) |

 IG © 2024+ [ELGA GmbH](https://www.elga.gv.at/). Package elga-e-medikation-R5.elga.hl7.at#0.0.0 based on [FHIR® 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md)  

