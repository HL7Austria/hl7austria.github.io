# ELGA-E-MEDIKATION-R5.ELGA.HL7.AT\Support & Imprint (en) - FHIR® v5.0.0

* [**Table of Contents**](toc.md)
* **Support & Imprint (en)**

ELGA e-Medikation FHIR R5 Implementierungsleitfaden - Local Development build (v0.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://fhir.hl7.at/elga-e-medikation-R5/history.html)

## Support & Imprint (en)

* [Technical issues](#technical-issues)
* [Issues regarding terminologies](#issues-regarding-terminologies)
* [ELGA](#elga)
* [Imprint](#imprint)
* [Privacy Policy](#privacy-policy)

> **Für die deutsche Version bitte[hier](support_de.md)klicken.**

Depending on the subject of support requested, please, choose one of the following channels.

### Technical issues

Suggestions for improvements or error messages detected during the use of **TerminoloGit** can be reported via the GitHub ticket system at **[https://github.com/HL7Austria/ELGA-FHIR-e-Medikation-R5/issues/new](https://github.com/HL7Austria/ELGA-FHIR-e-Medikation-R5/issues/new)**.

### Issues regarding terminologies

Questions regarding **terminologies** can probably be answered with **[https://termgit.elga.gv.at/](https://termgit.elga.gv.at/)**.

### ELGA

Questions regarding your ELGA and ELGA-Portal please contact **[info@elga-serviceline.at](mailto:info@elga-serviceline.at)** or **[+43 (0)50 124 4411](tel:+43501244411)** (working days from 7am to 7pm).

### Imprint

The imprint of **[elga.gv.at/en/imprint](https://www.elga.gv.at/en/imprint/)** applies.

### Privacy Policy

The only in german available **[elga.gv.at/datenschutzerklaerung](https://www.elga.gv.at/datenschutzerklaerung/)** applies.

 IG © 2024+ [ELGA GmbH](https://www.elga.gv.at/). Package elga-e-medikation-R5.elga.hl7.at#0.0.0 based on [FHIR® 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md)  

