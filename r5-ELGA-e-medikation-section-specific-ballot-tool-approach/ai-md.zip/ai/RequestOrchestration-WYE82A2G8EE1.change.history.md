# ELGA-E-MEDIKATION-R5.ELGA.HL7.AT\ - FHIR® v5.0.0

ELGA e-Medikation FHIR R5 Implementierungsleitfaden - Local Development build (v0.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://fhir.hl7.at/elga-e-medikation-R5/history.html)

*  [Narrative Content](RequestOrchestration-WYE82A2G8EE1.md) 
*  [XML](RequestOrchestration-WYE82A2G8EE1.xml.md) 
*  [JSON](RequestOrchestration-WYE82A2G8EE1.json.md) 
*  [TTL](RequestOrchestration-WYE82A2G8EE1.ttl.md) 

## : RequestOrchestration/WYE82A2G8EE1 - Change History

History of changes for WYE82A2G8EE1 .

 IG © 2024+ [ELGA GmbH](https://www.elga.gv.at/). Package elga-e-medikation-R5.elga.hl7.at#0.0.0 based on [FHIR® 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md)  

