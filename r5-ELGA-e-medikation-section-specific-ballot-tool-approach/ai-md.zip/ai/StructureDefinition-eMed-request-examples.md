# ELGA-E-MEDIKATION-R5.ELGA.HL7.AT\2 ELGA e-Medication MedicationRequest (eMedRequest) - Examples - FHIR® v5.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **2 ELGA e-Medication MedicationRequest (eMedRequest)**

ELGA e-Medikation FHIR R5 Implementierungsleitfaden - Local Development build (v0.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://fhir.hl7.at/elga-e-medikation-R5/history.html)

*  [Content](StructureDefinition-eMed-request.md) 
*  [Detailed Descriptions](StructureDefinition-eMed-request-definitions.md) 
*  [Mappings](StructureDefinition-eMed-request-mappings.md) 
*  [Examples](#) 
*  [XML](StructureDefinition-eMed-request.profile.xml.md) 
*  [JSON](StructureDefinition-eMed-request.profile.json.md) 
*  [TTL](StructureDefinition-eMed-request.profile.ttl.md) 

## Resource Profile: eMedRequest - Examples

| |
| :--- |
| Draft as of 2025-10-07 |

Examples for the eMed-request Profile.

| |
| :--- |
| [Example-eMedRequest](MedicationRequest-Example-eMedRequest.md) |

 IG © 2024+ [ELGA GmbH](https://www.elga.gv.at/). Package elga-e-medikation-R5.elga.hl7.at#0.0.0 based on [FHIR® 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md)  

