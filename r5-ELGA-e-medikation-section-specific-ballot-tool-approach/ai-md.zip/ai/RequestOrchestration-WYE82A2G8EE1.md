# ELGA-E-MEDIKATION-R5.ELGA.HL7.AT\Example-eMedPrescriptionAsRequestOrchestration - FHIR® v5.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example-eMedPrescriptionAsRequestOrchestration**

ELGA e-Medikation FHIR R5 Implementierungsleitfaden - Local Development build (v0.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://fhir.hl7.at/elga-e-medikation-R5/history.html)

*  [Narrative Content](#) 
*  [XML](RequestOrchestration-WYE82A2G8EE1.xml.md) 
*  [JSON](RequestOrchestration-WYE82A2G8EE1.json.md) 
*  [TTL](RequestOrchestration-WYE82A2G8EE1.ttl.md) 

## Example RequestOrchestration: Example-eMedPrescriptionAsRequestOrchestration

Profile: [1 ELGA e-Medication Prescription with multiple MedicationRequests (eMedPrescriptionAsRequestOrchestration)](StructureDefinition-eMed-prescription-with-multiple-eMed-requests.md)

**status**: Completed

**intent**: Order

**code**: Kassenrezept

**subject**: [https://fhir.hl7.at/r5-core-main/Patient-HL7ATCorePatientExample05-FullElga](https://fhir.hl7.at/r5-core-main/Patient-HL7ATCorePatientExample05-FullElga)

**authoredOn**: 2013-03-24 08:20:15+0100

**author**: [https://fhir.hl7.at/r5-core-main/Practitioner-HL7ATCorePractitionerExample01](https://fhir.hl7.at/r5-core-main/Practitioner-HL7ATCorePractitionerExample01)

-------

> **Generated Narrative: MedicationRequest #Example-eMedRequest**

Profile: [2 ELGA e-Medication MedicationRequest (eMedRequest)](StructureDefinition-eMed-request.md)

**identifier**: WYE82A2G8EEW-4711**groupIdentifier**: WYE82A2G8EE1**status**: Completed**intent**: Order

### Medications

| | |
| :--- | :--- |
| - | **Concept** |
| * | CIPROXIN FTBL 500MG |

**subject**:[https://fhir.hl7.at/r5-core-main/Patient-HL7ATCorePatientExample05-FullElga](https://fhir.hl7.at/r5-core-main/Patient-HL7ATCorePatientExample05-FullElga)**requester**:[https://fhir.hl7.at/r5-core-main/Practitioner-HL7ATCorePractitionerExample01](https://fhir.hl7.at/r5-core-main/Practitioner-HL7ATCorePractitionerExample01)**note**:
> 

Dosierung genau einhalten!


**effectiveDosePeriod**: 2013-03-25 --> 2013-04-08

### DosageInstructions

| | | |
| :--- | :--- | :--- |
| - | **PatientInstruction** | **Timing** |
| * | Alternativ Tablette in Wasser auflösen | Morning, 2 |
| * | Alternativ Tablette in Wasser auflösen | Evening, Once |

### DispenseRequests

| | |
| :--- | :--- |
| - | **NumberOfRepeatsAllowed** |
| * | 0 |


 IG © 2024+ [ELGA GmbH](https://www.elga.gv.at/). Package elga-e-medikation-R5.elga.hl7.at#0.0.0 based on [FHIR® 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md)  

