# ELGA-E-MEDIKATION-R5.ELGA.HL7.AT\Intro & Differentiation (en) - FHIR® v5.0.0

* [**Table of Contents**](toc.md)
* **Intro & Differentiation (en)**

ELGA e-Medikation FHIR R5 Implementierungsleitfaden - Local Development build (v0.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://fhir.hl7.at/elga-e-medikation-R5/history.html)

## Intro & Differentiation (en)

> **Für die deutsche Version bitte[hier](intro_de.md)klicken.**

 IG © 2024+ [ELGA GmbH](https://www.elga.gv.at/). Package elga-e-medikation-R5.elga.hl7.at#0.0.0 based on [FHIR® 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md)  

