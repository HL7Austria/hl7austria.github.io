# ELGA-E-MEDIKATION-R5.ELGA.HL7.AT\Example-eMedRequest - XML Representation - FHIR® v5.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example-eMedRequest**

ELGA e-Medikation FHIR R5 Implementierungsleitfaden - Local Development build (v0.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://fhir.hl7.at/elga-e-medikation-R5/history.html)

*  [Narrative Content](MedicationRequest-Example-eMedRequest.md) 
*  [XML](#) 
*  [JSON](MedicationRequest-Example-eMedRequest.json.md) 
*  [TTL](MedicationRequest-Example-eMedRequest.ttl.md) 

## : Example-eMedRequest - XML Representation

[Raw xml](MedicationRequest-Example-eMedRequest.xml) | [Download](MedicationRequest-Example-eMedRequest.xml)

 IG © 2024+ [ELGA GmbH](https://www.elga.gv.at/). Package elga-e-medikation-R5.elga.hl7.at#0.0.0 based on [FHIR® 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md)  

