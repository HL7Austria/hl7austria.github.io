# ELGA-E-MEDIKATION-R5.ELGA.HL7.AT\LINCA Dispense (LINCAMedicationDispense) - FHIR® v5.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **LINCA Dispense (LINCAMedicationDispense)**

ELGA e-Medikation FHIR R5 Implementierungsleitfaden - Local Development build (v0.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://fhir.hl7.at/elga-e-medikation-R5/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-linca-dipsense-documentation-definitions.md) 
*  [Mappings](StructureDefinition-linca-dipsense-documentation-mappings.md) 
*  [XML](StructureDefinition-linca-dipsense-documentation.profile.xml.md) 
*  [JSON](StructureDefinition-linca-dipsense-documentation.profile.json.md) 
*  [TTL](StructureDefinition-linca-dipsense-documentation.profile.ttl.md) 

## Resource Profile: LINCA Dispense (LINCAMedicationDispense) 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://fhir.hl7.at/elga-e-medikation-R5/StructureDefinition/linca-dipsense-documentation | *Version*:0.0.0 | |
| Draft as of 2025-10-07 | *Responsible:*[ELGA GmbH](https://www.elga.gv.at/) | *Computable Name*:LINCAMedicationDispense |

 
Linked Care Profile for dispense documentation. The dispense must be documented by the dispensing pharmacist and specify if an order was fulfilled completly or partially. The LINCA Dispense must have an LINCA Prescription as authorizingPrescription. 

**Usages:**

* This Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/elga-e-medikation-R5.elga.hl7.at|current/StructureDefinition/linca-dipsense-documentation)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [MedicationDispense](http://hl7.org/fhir/R5/medicationdispense.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [MedicationDispense](http://hl7.org/fhir/R5/medicationdispense.html) 

**Summary**

Mandatory: 2 elements
 Prohibited: 1 element

**Structures**

This structure refers to these other structures:

* [HL7® AT Core Patient Profile(http://hl7.at/fhir/HL7ATCoreProfiles/5.0.0/StructureDefinition/at-core-patient)](http://hl7.at/fhir/HL7ATCoreProfiles/5.0.0/2.0.0/StructureDefinition-at-core-patient.html)
* [2 ELGA e-Medication MedicationRequest (eMedRequest)(http://fhir.hl7.at/elga-e-medikation-R5/StructureDefinition/eMed-request)](StructureDefinition-eMed-request.md)
* [SimpleQuantity(http://hl7.org/fhir/StructureDefinition/SimpleQuantity)](http://hl7.org/fhir/R5/datatypes.html#SimpleQuantity)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R5/profiling.html#slices):

* The element 1 is sliced based on the value of MedicationDispense.dosageInstruction.doseAndRate.dose[x]

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [MedicationDispense](http://hl7.org/fhir/R5/medicationdispense.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [MedicationDispense](http://hl7.org/fhir/R5/medicationdispense.html) 

**Summary**

Mandatory: 2 elements
 Prohibited: 1 element

**Structures**

This structure refers to these other structures:

* [HL7® AT Core Patient Profile(http://hl7.at/fhir/HL7ATCoreProfiles/5.0.0/StructureDefinition/at-core-patient)](http://hl7.at/fhir/HL7ATCoreProfiles/5.0.0/2.0.0/StructureDefinition-at-core-patient.html)
* [2 ELGA e-Medication MedicationRequest (eMedRequest)(http://fhir.hl7.at/elga-e-medikation-R5/StructureDefinition/eMed-request)](StructureDefinition-eMed-request.md)
* [SimpleQuantity(http://hl7.org/fhir/StructureDefinition/SimpleQuantity)](http://hl7.org/fhir/R5/datatypes.html#SimpleQuantity)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R5/profiling.html#slices):

* The element 1 is sliced based on the value of MedicationDispense.dosageInstruction.doseAndRate.dose[x]

 

Other representations of profile: [CSV](StructureDefinition-linca-dipsense-documentation.csv), [Excel](StructureDefinition-linca-dipsense-documentation.xlsx), [Schematron](StructureDefinition-linca-dipsense-documentation.sch) 

 IG © 2024+ [ELGA GmbH](https://www.elga.gv.at/). Package elga-e-medikation-R5.elga.hl7.at#0.0.0 based on [FHIR® 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
  Links: [Table of Contents](toc.md) | [QA Report](qa.md)  

