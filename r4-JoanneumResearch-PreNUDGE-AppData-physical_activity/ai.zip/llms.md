# hl7.at.fhir.prenudge.appdata.r4#0.1.0: PreNUDGE FHIR® IG for Data Provider / Data from Apps (R4)

## Pages

* [HL7.AT.FHIR.PRENUDGE.APPDATA.R4\Home - FHIR® v4.0.1](index.md)
* [HL7.AT.FHIR.PRENUDGE.APPDATA.R4\About - FHIR® v4.0.1](about.md)
* [HL7.AT.FHIR.PRENUDGE.APPDATA.R4\Workflow - FHIR® v4.0.1](workflow.md)
* [HL7.AT.FHIR.PRENUDGE.APPDATA.R4\Downloads - FHIR® v4.0.1](downloads.md)
* [HL7.AT.FHIR.PRENUDGE.APPDATA.R4\Background - FHIR® v4.0.1](background.md)
* [HL7.AT.FHIR.PRENUDGE.APPDATA.R4\Artifacts Summary - FHIR® v4.0.1](artifacts.md)

## Resources

### CodeSystems

* [AT PreNUDGE Physical Activity Classification Method CodeSystem](CodeSystem-at-prenudge-physical-activity-classification-method-cs.md)
* [AT PreNUDGE EHIS-PAQ Answer Set](CodeSystem-at-prenudge-physicalactivity-codesystem-ehispaq.md)
* [ATHIS – Antwortmöglichkeiten](CodeSystem-athis-answers.md)
* [AT PreNUDGE WHOQOL-BREF Answer Scales](CodeSystem-whoqol-bref-scale.md)

### ValueSets

* [AT PreNUDGE Alcohol Use Frequency](ValueSet-prenudge-alcoholuse-frequency.md)
* [AT PreNUDGE Blood Glucose Meal Context](ValueSet-prenudge-bloodglucose-mealcontext.md)
* [AT PreNUDGE Observation Methods](ValueSet-prenudge-observation-method.md)
* [AT PreNUDGE Other Observations Codes](ValueSet-prenudge-other-observations-codes.md)
* [AT PreNUDGE Other Observations Units](ValueSet-prenudge-other-observations-units.md)
* [AT PreNUDGE Physical Activity Classification Method ValueSet](ValueSet-prenudge-physical-activity-classification-method-vs.md)
* [AT PreNUDGE WHOQOL-BREF Score Type ValueSet](ValueSet-prenudge-whoqol-bref-score-type.md)

### Resource Profiles

* [AT PreNUDGE Observation Alcohol Use](StructureDefinition-at-prenudge-alcoholuse-observation.md)
* [AT PreNUDGE Observation Blood Glucose (only in mg/dL)](StructureDefinition-at-prenudge-bloodglucose-observation.md)
* [AT PreNUDGE Observation Muscle Strengthening Sessions](StructureDefinition-at-prenudge-muscle-strengthening-observation.md)
* [AT PreNUDGE Observation Other not Quantities](StructureDefinition-at-prenudge-observation-other-not-quantities.md)
* [AT PreNUDGE Observation Other Quantities](StructureDefinition-at-prenudge-observation-other-quantities.md)
* [AT PreNUDGE Observation](StructureDefinition-at-prenudge-observation.md)
* [AT PreNUDGE Observation Physical Activity Minutes](StructureDefinition-at-prenudge-physical-activity-minutes-observation.md)
* [AT PreNUDGE Questionnaire](StructureDefinition-at-prenudge-questionnaire.md)
* [AT PreNUDGE Questionnaire Response](StructureDefinition-at-prenudge-questionnaireresponse.md)
* [AT PreNUDGE Observation Sitting Hours](StructureDefinition-at-prenudge-sitting-hours-observation.md)
* [AT PreNUDGE Observation Sleep Duration](StructureDefinition-at-prenudge-sleep-duration-observation.md)
* [AT PreNUDGE Observation Sleep Quality](StructureDefinition-at-prenudge-sleep-quality-observation.md)
* [AT PreNUDGE Observation Step Count](StructureDefinition-at-prenudge-stepcount-observation.md)
* [AT PreNUDGE Observation WHOQOL-BREF Score](StructureDefinition-at-prenudge-whoqol-bref-score-observation.md)

### ConceptMaps

* [AT PreNUDGE Code-to-Unit Mapping](ConceptMap-AtPrenudgeCodeUnitMap.md)

### ImplementationGuides

* [PreNUDGE FHIR® IG for Data Provider / Data from Apps (R4)](index.md)

### Questionnaires

* [Alkoholkonsum im letzten Jahr](Questionnaire-AlcoholUseQuestionnaire.md)
* [Blutzucker bei der letzten Messung](Questionnaire-BloodGlucoseQuestionnaire.md)
* [EHIS-PAQ Q8 / ATHIS PE8: Muskelkräftigungsübungen](Questionnaire-EhisPaqMuscleStrengtheningQuestionnaire.md)
* [EHIS-PAQ/ATHIS: Körperliche Aktivität](Questionnaire-EhisPaqPhysicalActivityQuestionnaire.md)
* [EHIS-PAQ Q9 / ATHIS PE9: Sitzen und Ruhen](Questionnaire-EhisPaqSittingHoursQuestionnaire.md)
* [Muskelkräftigungs-Trainingseinheiten pro Woche (numerisch)](Questionnaire-MuscleStrengtheningQuantityQuestionnaire.md)
* [Durchschnittliche Schlafdauer pro Nacht](Questionnaire-SleepDurationQuestionnaire.md)
* [Schlafqualität – Selbsteinschätzung (WHOQOL-BREF Q16)](Questionnaire-SleepQualityQuestionnaire.md)
* [EHIS-PAQ/ATHIS: Zu-Fuß-Gehen](Questionnaire-StepCountEhisPaqQuestionnaire.md)
* [Schrittzahl am heutigen Tag](Questionnaire-StepCountQuantityQuestionnaire.md)
* [WHOQOL-BREF Lebensstil Selbsteinschätzung](Questionnaire-WhoQolBrefQuestionnaire.md)

### StructureMaps

* [Alcohol Use Q mapping frequency to O drinks per day](StructureMap-AlcoholQuestionnaireResponseToObservation.md)
* [Blood Glucose Q to O](StructureMap-BloodGlucoseQuestionnaireResponseToObservation.md)
* [Muscle Strengthening EHIS-PAQ Q8 / ATHIS PE8 to O](StructureMap-MuscleStrengtheningEhisPaqQuestionnaireResponseToObservation.md)
* [Muscle Strengthening Sessions Q to O](StructureMap-MuscleStrengtheningQuestionnaireResponseToObservation.md)
* [Physical Activity Minutes Q to O](StructureMap-PhysicalActivityMinutesQtoO.md)
* [Shared base for Q to O](StructureMap-QuestionnaireResponseToObservationBase.md)
* [Sitting Hours Q to O](StructureMap-SittingHoursQuestionnaireResponseToObservation.md)
* [Sleep Duration Q to O](StructureMap-SleepDurationQuestionnaireResponseToObservation.md)
* [Sleep Quality Base (WHOQOL-BREF scale to LOINC)](StructureMap-SleepQualityBase.md)
* [Step Count Q to O](StructureMap-StepCountQuestionnaireResponseToObservation.md)
* [WHOQOL-BREF Q score to O score](StructureMap-WHOQOLBrefQuestionnaireResponseToObservation.md)

### Examples

* [device-wearable-example (Device)](Device-device-wearable-example.md)
* [alcoholuse-moderate-example (Observation)](Observation-alcoholuse-moderate-example.md)
* [alcoholuse-never-example (Observation)](Observation-alcoholuse-never-example.md)
* [alcoholuse-occasional-example (Observation)](Observation-alcoholuse-occasional-example.md)
* [bloodglucose-elevated-example (Observation)](Observation-bloodglucose-elevated-example.md)
* [bloodglucose-low-example (Observation)](Observation-bloodglucose-low-example.md)
* [bloodglucose-normal-example (Observation)](Observation-bloodglucose-normal-example.md)
* [muscle-strengthening-ehis-paq-derived-example (Observation)](Observation-muscle-strengthening-ehis-paq-derived-example.md)
* [muscle-strengthening-questionnaire-derived-example (Observation)](Observation-muscle-strengthening-questionnaire-derived-example.md)
* [muscle-strengthening-wearable-derived-example (Observation)](Observation-muscle-strengthening-wearable-derived-example.md)
* [physical-activity-minutes-aggregate-only-example (Observation)](Observation-physical-activity-minutes-aggregate-only-example.md)
* [physical-activity-minutes-all-components-example (Observation)](Observation-physical-activity-minutes-all-components-example.md)
* [physical-activity-minutes-ehispaq-q7-mapped-example (Observation)](Observation-physical-activity-minutes-ehispaq-q7-mapped-example.md)
* [physical-activity-minutes-moderate-aggregate-example (Observation)](Observation-physical-activity-minutes-moderate-aggregate-example.md)
* [physical-activity-minutes-moderate-only-example (Observation)](Observation-physical-activity-minutes-moderate-only-example.md)
* [physical-activity-minutes-vigorous-aggregate-example (Observation)](Observation-physical-activity-minutes-vigorous-aggregate-example.md)
* [sitting-hours-questionnaire-derived-example (Observation)](Observation-sitting-hours-questionnaire-derived-example.md)
* [sitting-hours-wearable-example (Observation)](Observation-sitting-hours-wearable-example.md)
* [sleep-duration-normal-automated-example (Observation)](Observation-sleep-duration-normal-automated-example.md)
* [sleep-duration-normal-manual-example (Observation)](Observation-sleep-duration-normal-manual-example.md)
* [sleep-duration-short-automated-example (Observation)](Observation-sleep-duration-short-automated-example.md)
* [sleep-quality-dissatisfied-example (Observation)](Observation-sleep-quality-dissatisfied-example.md)
* [sleep-quality-satisfied-example (Observation)](Observation-sleep-quality-satisfied-example.md)
* [stepcount-high-example (Observation)](Observation-stepcount-high-example.md)
* [stepcount-normal-example (Observation)](Observation-stepcount-normal-example.md)
* [stepcount-sedentary-example (Observation)](Observation-stepcount-sedentary-example.md)
* [whoqol-bref-score-example (Observation)](Observation-whoqol-bref-score-example.md)
* [example (Patient)](Patient-example.md)
* [AlcoholResponseDaily (QuestionnaireResponse)](QuestionnaireResponse-AlcoholResponseDaily.md)
* [AlcoholResponseNever (QuestionnaireResponse)](QuestionnaireResponse-AlcoholResponseNever.md)
* [bloodglucose-response-elevated-example (QuestionnaireResponse)](QuestionnaireResponse-bloodglucose-response-elevated-example.md)
* [bloodglucose-response-normal-example (QuestionnaireResponse)](QuestionnaireResponse-bloodglucose-response-normal-example.md)
* [muscle-strengthening-ehis-paq-response-example (QuestionnaireResponse)](QuestionnaireResponse-muscle-strengthening-ehis-paq-response-example.md)
* [muscle-strengthening-quantity-response-example (QuestionnaireResponse)](QuestionnaireResponse-muscle-strengthening-quantity-response-example.md)
* [physical-activity-ehispaq-response-example (QuestionnaireResponse)](QuestionnaireResponse-physical-activity-ehispaq-response-example.md)
* [sitting-hours-ehis-paq-response-example (QuestionnaireResponse)](QuestionnaireResponse-sitting-hours-ehis-paq-response-example.md)
* [sleep-duration-response-normal-example (QuestionnaireResponse)](QuestionnaireResponse-sleep-duration-response-normal-example.md)
* [sleep-duration-response-short-example (QuestionnaireResponse)](QuestionnaireResponse-sleep-duration-response-short-example.md)
* [sleep-quality-response-dissatisfied-example (QuestionnaireResponse)](QuestionnaireResponse-sleep-quality-response-dissatisfied-example.md)
* [sleep-quality-response-satisfied-example (QuestionnaireResponse)](QuestionnaireResponse-sleep-quality-response-satisfied-example.md)
* [stepcount-ehispaq-high (QuestionnaireResponse)](QuestionnaireResponse-stepcount-ehispaq-high.md)
* [stepcount-ehispaq-normal (QuestionnaireResponse)](QuestionnaireResponse-stepcount-ehispaq-normal.md)
* [stepcount-quantity-response-high-example (QuestionnaireResponse)](QuestionnaireResponse-stepcount-quantity-response-high-example.md)
* [stepcount-quantity-response-normal-example (QuestionnaireResponse)](QuestionnaireResponse-stepcount-quantity-response-normal-example.md)
* [whoqol-bref-response-example (QuestionnaireResponse)](QuestionnaireResponse-whoqol-bref-response-example.md)
