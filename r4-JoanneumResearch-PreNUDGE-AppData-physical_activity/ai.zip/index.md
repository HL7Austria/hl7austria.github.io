# HL7.AT.FHIR.PRENUDGE.APPDATA.R4\Home - FHIR® v4.0.1

* [**Table of Contents**](toc.md)
* **Home**

## Home

PreNUDGE is an Austrian research project designed to strengthen citizens' personal responsibility for their health. The project aims to increase the number of **healthy life years** through the **digitalization of self-reported health data**.

The core concept is to create a **modular platform** that collects and structures health data from various sources. **Qualified health apps** serve as the interface between citizens and the platform. The project combines nudging strategies with evidence-based health promotion to subtly motivate people to live healthier lives.

PreNUDGE focuses on the **prevention of four diseases**: diabetes, colorectal cancer, depression, and COPD, targeting specific groups such as children, adolescents, and working adults. The FHIR Implementation Guide (IG) is called “PreNUDGE”, which is the agreed English spelling, while the project’s German name is “PräNUDGE.”

For more, see [Background](background.md).

### PreNUDGE FHIR® IG for Data Provider / Data from Apps

This Implementation Guide (IG) explains how application providers can use the **PreNUDGE FHIR API** to deliver **health indicators**.

We focus on narrow standardization of **four PreNUDGE measurements**:

* **Physical Activity**: 
* ⏳Minutes of moderate and vigorous/intense physical activity (per week) (from [**EHIS-PAQ Q4–Q7 / ATHIS PE4–PE7 questionnaire**](Questionnaire-EhisPaqPhysicalActivityQuestionnaire.md) and (from a wearable device) as an [**observation**](StructureDefinition-at-prenudge-physical-activity-minutes-observation.md))
* Daily activity as Steps per day (from a [**EHIS-PAQ Q2–Q3 / ATHIS PE2–PE3 questionnaire**](Questionnaire-StepCountEhisPaqQuestionnaire.md), [**quantity questionnaire**](Questionnaire-StepCountQuantityQuestionnaire.md) and (from a wearable device) as an [**observation**](StructureDefinition-at-prenudge-stepcount-observation.md))
* ⏳Number of muscle-strengthening exercise sessions (per week) (from [**EHIS-PAQ Q8 / ATHIS PE8 questionnaire**](Questionnaire-EhisPaqMuscleStrengtheningQuestionnaire.md), [**quantity questionnaire**](Questionnaire-MuscleStrengtheningQuantityQuestionnaire.md) and (from a wearable device) as an [**observation**](StructureDefinition-at-prenudge-muscle-strengthening-observation.md))
* ⏳Sitting hours (per day) (from [**EHIS-PAQ Q9 / ATHIS PE9 questionnaire**](Questionnaire-EhisPaqSittingHoursQuestionnaire.md) and (from wearable device) as an [**observation**](StructureDefinition-at-prenudge-sitting-hours-observation.md))
 
* **Alcohol consumption** as number of drinks (from a [**questionnaire**](Questionnaire-AlcoholUseQuestionnaire.md) and from an [**observation**](StructureDefinition-at-prenudge-alcoholuse-observation.md))
* **Quality of life** (from a [**questionnaire**](Questionnaire-WhoQolBrefQuestionnaire.md) with a calculated [**score as an observation**](StructureDefinition-at-prenudge-whoqol-bref-score-observation.md))
* **Smoking**: Current smoking/tobacco use status (from a [**questionnaire**](Questionnaire-SmokingStatusQuestionnaire.md) and from an [**observation IPS style**](StructureDefinition-at-prenudge-smokingstatus-observation.md))
* **Sleep** duration and quality 
* Duration - from [**questionnaire**](Questionnaire-SleepDurationQuestionnaire.md) or as an [**observation**](StructureDefinition-at-prenudge-sleep-duration-observation.md)
* Quality - question 16 from the [**WHOQOL-BRE questionnaire**](Questionnaire-WhoQolBrefQuestionnaire.md) or same question 16 from a [**single quesion questionnaire**](Questionnaire-SleepQualityQuestionnaire.md) or as an [**observation**](StructureDefinition-at-prenudge-sleep-quality-observation.md)
 
* For Demo Purposes: **Blood glucose** in mg/dL (from a [**questionnaire**](Questionnaire-BloodGlucoseQuestionnaire.md) and from a [**device as an observation**](StructureDefinition-at-prenudge-bloodglucose-observation.md))

For viewing the full questionnaires use tools like [lhcforms](https://lhcfhirtools.nlm.nih.gov/lhcforms).

Each **questionnaire variant** maps **one-way** to its corresponding **observation variant**. The mappings can be found at [StructureMaps](artifacts.md#terminology-structure-maps) and can be executed with [MaLaC-HD](https://gitlab.com/cdehealth/malac-hd). These transformations will be performed on the server side.

Additional PreNUDGE measurements, also narrow standardized, will be specified analogously to these four, based on feedback from the informative ballot. The following are to be specified:

* Smoking: Current status (from a questionnaire and from an observation IPS style)
* Nutrition: Portions of fruit and vegetables (per day) (from a questionnaire)
* Nutrition: Consumption frequency of sugary and salty foods (per week) (from a questionnaire)
* Sociodemographic Data: Age (from a questionnaire)
* Sociodemographic Data: Gender (from a questionnaire)
* Sociodemographic Data: Highest completed education (ISCED level) (from a questionnaire)
* Psychosocial Factors: Self reported emotional burden (from a questionnaire)
* Psychosocial Factors: Self reported stress (from a questionnaire with a calculated score as an observation)
* Anthropometry: Body Mass Index (kg/m²) (from a questionnaire and from a wearable device as an observation)
* Workability (score per category) (from a questionnaire with a calculated score as an observation)

Besides these narrow standardized measurements, **broad standardized measurements** called [**other quantities observations**](StructureDefinition-at-prenudge-observation-other-quantities.md) and [**other not quantities observations**](StructureDefinition-at-prenudge-observation-other-not-quantities.md) are also supported. Please be aware that such broad standardized measurements do not have a corresponding questionnaire.

