# hl7.at.fhir.brz.providerdirectory.r4#0.1.0: null

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [BRZPDPractitioner](StructureDefinition-BRZPDPractitioner.md)

### ImplementationGuides

* [ProviderDirectory](index.md)

### Examples

* [PractitionerExample (Practitioner)](Practitioner-PractitionerExample.md)
