# HL7® AT Core Location Profile - HL7® Austria FHIR® Core Implementation Guide v2.1.0

## Resource Profile: HL7® AT Core Location Profile 

**Usages:**

* Refer to this Profile: [HL7® AT Core HealthcareService Profile](StructureDefinition-at-core-HealthcareService.md) and [HL7® AT Core Location Profile](StructureDefinition-at-core-location.md)
* Examples for this Profile: [Campus Graz](Location-HL7ATCoreLocationGraz.md) and [Campus Linz](Location-HL7ATCoreLocationLinz.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/hl7.at.fhir.core.r5|current/StructureDefinition/StructureDefinition-at-core-location.json)

### Formal Views of Profile Content

 [Description Differentials, Snapshots, and other representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-at-core-location.csv), [Excel](../StructureDefinition-at-core-location.xlsx), [Schematron](../StructureDefinition-at-core-location.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "at-core-location",
  "url" : "https://fhir.hl7.at/core/r5/StructureDefinition/at-core-location",
  "version" : "2.1.0",
  "name" : "HL7ATCoreLocation",
  "title" : "HL7® AT Core Location Profile",
  "status" : "active",
  "date" : "2026-10-16T07:03:17+00:00",
  "publisher" : "HL7® Austria, TC FHIR®",
  "contact" : [{
    "name" : "HL7® Austria, TC FHIR®",
    "telecom" : [{
      "system" : "url",
      "value" : "https://hl7.at/technische-komitees/tc-fhir/"
    }]
  },
  {
    "name" : "Technical Committee for FHIR® at HL7® Austria",
    "telecom" : [{
      "system" : "email",
      "value" : "mailto:tc-fhir@hl7.at"
    }]
  }],
  "description" : "HL7® Austria FHIR® Core Profile for location data in Austria.",
  "fhirVersion" : "5.0.0",
  "mapping" : [{
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "interface",
    "uri" : "http://hl7.org/fhir/interface",
    "name" : "Interface Pattern"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Location",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Location",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Location",
      "path" : "Location"
    },
    {
      "id" : "Location.identifier",
      "path" : "Location.identifier",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "system"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "Location.identifier:KANR",
      "path" : "Location.identifier",
      "sliceName" : "KANR",
      "min" : 0,
      "max" : "1",
      "constraint" : [{
        "key" : "inv-kanr-6char",
        "severity" : "error",
        "human" : "KA-Nr (KANR) must follow the 6-character pattern: 'K' + 3 digits + '.' + 1 digit (e.g., K460.1).",
        "expression" : "value.matches('^K[0-9]{3}[.][0-9]$')",
        "source" : "https://fhir.hl7.at/core/r5/StructureDefinition/at-core-location"
      }]
    },
    {
      "id" : "Location.identifier:KANR.system",
      "path" : "Location.identifier.system",
      "short" : "OID for the Krankenanstaltennummer (KA-Nr) in Austria",
      "min" : 1,
      "patternUri" : "urn:oid:1.2.40.0.34.4.10"
    },
    {
      "id" : "Location.identifier:KANR.value",
      "path" : "Location.identifier.value",
      "short" : "Krankenanstaltennummer (hospital identification number) in the more fine-grained 6-character format, used to represent a hospital site. The 4-character hospital identification number remains an identifier on the Organization resource only. The first 4 characters of the Location KANR SHALL match the Organization KANR.“",
      "min" : 1
    },
    {
      "id" : "Location.identifier:KANR.assigner.display",
      "path" : "Location.identifier.assigner.display",
      "patternString" : "Österreichisches Bundesministerium für Gesundheit"
    },
    {
      "id" : "Location.contact",
      "path" : "Location.contact",
      "type" : [{
        "code" : "ExtendedContactDetail",
        "profile" : ["https://fhir.hl7.at/core/r5/StructureDefinition/at-core-extendedContactDetail"]
      }]
    },
    {
      "id" : "Location.address",
      "path" : "Location.address",
      "type" : [{
        "code" : "Address",
        "profile" : ["https://fhir.hl7.at/core/r5/StructureDefinition/at-core-address"]
      }]
    },
    {
      "id" : "Location.managingOrganization",
      "path" : "Location.managingOrganization",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir.hl7.at/core/r5/StructureDefinition/at-core-organization"]
      }]
    },
    {
      "id" : "Location.partOf",
      "path" : "Location.partOf",
      "type" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-hierarchy",
          "valueBoolean" : true
        }],
        "code" : "Reference",
        "targetProfile" : ["https://fhir.hl7.at/core/r5/StructureDefinition/at-core-location"]
      }]
    }]
  }
}

```
