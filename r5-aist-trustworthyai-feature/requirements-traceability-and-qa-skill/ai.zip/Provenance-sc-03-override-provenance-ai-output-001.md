# Provenance: AI Output Generation (3) - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Provenance: AI Output Generation (3)**

## Example Provenance: Provenance: AI Output Generation (3)

Profile: [Trust AI Provenance](StructureDefinition-trust-ai-provenance.md)

Provenance for [Observation ](Observation-sc-03-override-ai-observation-risk-001.md)

Summary

| | |
| :--- | :--- |
| Occurrence | 2026-03-01 10:15:00+0000 --> 2026-03-01 10:15:03+0000 |
| Recorded | 2026-03-01 10:15:04+0000 |
| Activity | ai-output-generation |

**Agents**

* **who**: [Device: extension = ,->DocumentReference: extension = Not Clinically Validated,,,; status = current; type = AI Model Card; date = 2026-03-01 10:00:00+0000; description = Synthetic model card for a deterministic AI-output simulation component used in the PoC.,->DocumentReference: status = current; identifier = Trust AI Registration Number; status = active; manufacturer = ExampleMed AI GmbH; note = Synthetic maintenance information for PoC purposes.,AI-assisted early warning risk assessment based on synthetic NEWS2-inspired vital parameters.](Device-device-riskassist-ai.md)



## Resource Content

```json
{
  "resourceType" : "Provenance",
  "id" : "sc-03-override-provenance-ai-output-001",
  "meta" : {
    "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-provenance"]
  },
  "extension" : [{
    "url" : "http://example.org/fhir/trust-ai-transparency/StructureDefinition/usage-category",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://example.org/fhir/trust-ai-transparency/CodeSystem/usage-category-cs",
        "code" : "primary-use",
        "display" : "Primary Use"
      }]
    }
  },
  {
    "url" : "http://example.org/fhir/trust-ai-transparency/StructureDefinition/case-specific-indication",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://example.org/fhir/trust-ai-transparency/CodeSystem/trust-ai-case-specific-indication-cs",
        "code" : "prognosis",
        "display" : "Prognostic Prediction"
      }]
    }
  },
  {
    "url" : "http://example.org/fhir/trust-ai-transparency/StructureDefinition/automated-decision-flag",
    "valueBoolean" : false
  }],
  "target" : [{
    "reference" : "Observation/sc-03-override-ai-observation-risk-001"
  }],
  "occurredPeriod" : {
    "start" : "2026-03-01T10:15:00Z",
    "end" : "2026-03-01T10:15:03Z"
  },
  "recorded" : "2026-03-01T10:15:04Z",
  "authorization" : [{
    "concept" : {
      "coding" : [{
        "system" : "http://example.org/fhir/trust-ai-transparency/CodeSystem/gdpr-art6-codesystem",
        "code" : "gdpr-art-6-1-d"
      }]
    }
  },
  {
    "concept" : {
      "coding" : [{
        "system" : "http://example.org/fhir/trust-ai-transparency/CodeSystem/gdpr-art9-codesystem",
        "code" : "gdpr-art-9-2-h"
      }]
    }
  }],
  "activity" : {
    "text" : "ai-output-generation"
  },
  "patient" : {
    "reference" : "Patient/patient-001"
  },
  "encounter" : {
    "reference" : "Encounter/encounter-001"
  },
  "agent" : [{
    "who" : {
      "reference" : "Device/device-riskassist-ai"
    }
  }],
  "entity" : [{
    "role" : "source",
    "what" : {
      "reference" : "Observation/sc-03-override-observation-temperature-001"
    }
  },
  {
    "role" : "source",
    "what" : {
      "reference" : "Observation/sc-03-override-observation-heart-rate-001"
    }
  },
  {
    "role" : "source",
    "what" : {
      "reference" : "Observation/sc-03-override-observation-respiratory-rate-001"
    }
  },
  {
    "role" : "source",
    "what" : {
      "reference" : "Observation/sc-03-override-observation-blood-pressure-001"
    }
  },
  {
    "role" : "source",
    "what" : {
      "reference" : "Observation/sc-03-override-observation-oxygen-saturation-001"
    }
  },
  {
    "role" : "source",
    "what" : {
      "reference" : "Observation/sc-03-override-observation-consciousness-status-001"
    }
  }]
}

```
