# Trust AI Human Oversight Assessment - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Trust AI Human Oversight Assessment**

## Resource Profile: Trust AI Human Oversight Assessment 

| | |
| :--- | :--- |
| *Official URL*:http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-human-oversight | *Version*:0.1.0 |
| Draft as of 2026-10-02 | *Computable Name*:Trust_AIHumanOversightAssessment |

 
An ArtifactAssessment profile documenting professional review of an AI-generated output, including whether the result was accepted, corrected, modified, or overridden. 

### Regulatory Requirements

This profile is part of the **Clinical Decision Context (Human-in-the-Loop)** layer. It implements the following documentation requirements from the [Requirements Traceability](requirements.md) analysis.

| | | | |
| :--- | :--- | :--- | :--- |
| [HL-01](requirements.md#req-hl-01) | AI Act Art. 14(1) | Responsible Actor (User) | Dynamic |
| [HL-03](requirements.md#req-hl-03) | AI Act Art. 14(4) | Type of Intervention | Dynamic |
| [HL-05](requirements.md#req-hl-05) | AI Act Art. 14(4)(c) | Specific Evidence Shown | Dynamic |

#### Element Mapping

| | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- |
| [HL-01](requirements.md#hl-01) | Actor Reference | 1..* | [`ArtifactAssessment.content.author`](StructureDefinition-trust-ai-human-oversight-definitions.md#ArtifactAssessment.content.author) | ✅ Covered | Also:[Trust_AIPractitionerRole](StructureDefinition-trust-ai-practitionerrole.md). |
| [HL-03.1](requirements.md#hl-031) | Intervention Action Code | 1..1 | [`ArtifactAssessment.content.classifier`](StructureDefinition-trust-ai-human-oversight-definitions.md#ArtifactAssessment.content.classifier) | ✅ Covered | TrustAIHumanOversightActionVS. |
| [HL-03.2](requirements.md#hl-032) | Intervention Rationale | 0..1* | [`ArtifactAssessment.content.summary`](StructureDefinition-trust-ai-human-oversight-definitions.md#ArtifactAssessment.content.summary) | ⚠️ Partial | The conditional 1..1 (for override) is not yet enforced by an invariant. |
| [HL-05](requirements.md#hl-05) | Specific Evidence Shown | 0..* | [`ArtifactAssessment.content.relatedArtifact`](StructureDefinition-trust-ai-human-oversight-definitions.md#ArtifactAssessment.content.relatedArtifact) | ✅ Covered |   |

**Usages:**

* Examples for this Profile: [ArtifactAssessment/dr-human-assessment](ArtifactAssessment-dr-human-assessment.md), [ArtifactAssessment/sc-02-validation-human-oversight-001](ArtifactAssessment-sc-02-validation-human-oversight-001.md), [ArtifactAssessment/sc-03-override-human-oversight-001](ArtifactAssessment-sc-03-override-human-oversight-001.md) and [ArtifactAssessment/sc-04-correction-exp-human-oversight-001](ArtifactAssessment-sc-04-correction-exp-human-oversight-001.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/fhir.ig.trust.aitransparency|current/StructureDefinition/StructureDefinition-trust-ai-human-oversight.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-trust-ai-human-oversight.csv), [Excel](StructureDefinition-trust-ai-human-oversight.xlsx), [Schematron](StructureDefinition-trust-ai-human-oversight.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "trust-ai-human-oversight",
  "url" : "http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-human-oversight",
  "version" : "0.1.0",
  "name" : "Trust_AIHumanOversightAssessment",
  "title" : "Trust AI Human Oversight Assessment",
  "status" : "draft",
  "date" : "2026-10-02T06:03:15+00:00",
  "publisher" : "Selina Adlberger",
  "description" : "An ArtifactAssessment profile documenting professional review of an AI-generated output, including whether the result was accepted, corrected, modified, or overridden.",
  "fhirVersion" : "5.0.0",
  "mapping" : [{
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "objimpl",
    "uri" : "http://hl7.org/fhir/object-implementation",
    "name" : "Object Implementation Information"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "ArtifactAssessment",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/ArtifactAssessment",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "ArtifactAssessment",
      "path" : "ArtifactAssessment"
    },
    {
      "id" : "ArtifactAssessment.date",
      "path" : "ArtifactAssessment.date",
      "short" : "Date and time of human oversight assessment",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "ArtifactAssessment.artifact[x]",
      "path" : "ArtifactAssessment.artifact[x]",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "$this"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "short" : "Reference to the AI-generated"
    },
    {
      "id" : "ArtifactAssessment.artifact[x]:artifactReference",
      "path" : "ArtifactAssessment.artifact[x]",
      "sliceName" : "artifactReference",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Resource"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "ArtifactAssessment.content.summary",
      "path" : "ArtifactAssessment.content.summary",
      "short" : "Clinical or technical rationale for the assessment",
      "mustSupport" : true
    },
    {
      "id" : "ArtifactAssessment.content.classifier",
      "path" : "ArtifactAssessment.content.classifier",
      "short" : "Human oversight action",
      "requirements" : "AI Act Art. 14 | Type of Intervention",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true,
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "http://example.org/fhir/trust-ai-transparency/ValueSet/trust-ai-human-oversight-action-vs"
      }
    },
    {
      "id" : "ArtifactAssessment.content.author",
      "path" : "ArtifactAssessment.content.author",
      "short" : "Reference to the qualified human overseer",
      "requirements" : "AI Act Art. 14 | Qualification of Actor",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-practitionerrole"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "ArtifactAssessment.content.relatedArtifact",
      "path" : "ArtifactAssessment.content.relatedArtifact",
      "short" : "Supporting documentation or explainability evidence",
      "requirements" : "AI Act Art. 14 | Case-Specific Interpretability Information"
    }]
  }
}

```
