# Home - v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://example.org/fhir/trust-ai-transparency/ImplementationGuide/fhir.ig.trust.aitransparency | *Version*:0.1.0 |
| Draft as of 2026-10-02 | *Computable Name*:TrustAITransparencyIG |

# Trust AI Transparency Implementation Guide

## Scope

The IG covers selected metadata areas relevant to AI-supported processing in healthcare:

* AI system identification and system-level metadata
* Organizational accountability and contact information
* Model-card and technical-documentation metadata
* Training-data and data-quality context
* Privacy and data-use metadata
* AI-generated clinical outputs
* Execution traceability and audit metadata
* Provenance and legal-context documentation
* Human oversight actions
* Patient-facing information and explanation documentation

The IG does not replace clinical validation, conformity assessment, data protection assessment, national legal review, or organization-specific governance processes.

## Purpose

AI-supported healthcare workflows require technical documentation that is understandable, traceable, and interoperable across systems. Relevant information may include the identity of the AI system, its intended purpose, technical documentation, training-data context, privacy metadata, legal processing context, generated outputs, execution traces, human oversight, and patient-facing information.

This IG provides a FHIR-based representation of these concepts by defining reusable profiles and extensions. The goal is to make selected AI-related metadata explicit, structured, and linkable within healthcare IT environments.



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "fhir.ig.trust.aitransparency",
  "language" : "en",
  "url" : "http://example.org/fhir/trust-ai-transparency/ImplementationGuide/fhir.ig.trust.aitransparency",
  "version" : "0.1.0",
  "name" : "TrustAITransparencyIG",
  "status" : "draft",
  "date" : "2026-10-02T06:03:15+00:00",
  "publisher" : "Selina Adlberger",
  "packageId" : "fhir.ig.trust.aitransparency",
  "license" : "CC0-1.0",
  "fhirVersion" : ["5.0.0"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r5",
    "version" : "7.4.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r5",
    "version" : "5.3.0"
  }],
  "definition" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r5#1.1.2"
    }],
    "grouping" : [{
      "id" : "generalized",
      "name" : "Generalized AI Output Scenario",
      "description" : "Example of how the IG can be used for AI outputs without a dedicated profile, using the generalized AI output pattern."
    },
    {
      "id" : "spezialized",
      "name" : "Specialized AI Output Scenario",
      "description" : "Example of how a specialized AI output profile such as Trust_AIObservation can be used."
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ai-clinical-validation-status.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ai-clinical-validation-status"
      },
      "name" : "AI Clinical Validation Status",
      "description" : "Records the documented validation status of the AI system, such as clinically validated, under clinical validation, technically validated only, or not clinically validated.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-dr-ai-diagnostic-report.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/dr-ai-diagnostic-report"
      },
      "name" : "AI Output: Diagnostic Report",
      "description" : "The diagnostic report generated by the AI system from the patient's input observation.",
      "isExample" : true,
      "groupingId" : "generalized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-01-ai-only-ai-observation-risk-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-01-ai-only-ai-observation-risk-001"
      },
      "name" : "AI Output: Early Warning Risk Assessment (1)",
      "description" : "Synthetic AI-generated high-risk output derived from NEWS2-inspired input parameters.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-observation"],
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-02-validation-ai-observation-risk-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-02-validation-ai-observation-risk-001"
      },
      "name" : "AI Output: Early Warning Risk Assessment (2)",
      "description" : "Synthetic AI-generated high-risk output derived from NEWS2-inspired input parameters.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-observation"],
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-03-override-ai-observation-risk-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-03-override-ai-observation-risk-001"
      },
      "name" : "AI Output: Early Warning Risk Assessment (3)",
      "description" : "Synthetic AI-generated low-risk output derived from NEWS2-inspired input parameters.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-observation"],
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-04-correction-exp-ai-observation-risk-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-04-correction-exp-ai-observation-risk-001"
      },
      "name" : "AI Output: Early Warning Risk Assessment (4)",
      "description" : "Synthetic AI-generated low-risk output derived from NEWS2-inspired input parameters.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-observation"],
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ai-performance-metrics.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ai-performance-metrics"
      },
      "name" : "AI Performance Metrics",
      "description" : "Documents quantitative performance measures and optional disclosures concerning bias, subgroup performance, or limitations of the evaluation.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ai-retention-information.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ai-retention-information"
      },
      "name" : "AI Retention Information",
      "description" : "Documents the stated retention duration for AI-related data, outputs, logs, or documentation.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ai-system-training-status.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ai-system-training-status"
      },
      "name" : "AI System-Specific Training Status",
      "description" : "Records whether the practitioner acting in the documented role has completed training specific to the relevant AI system.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ai-training-data.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ai-training-data"
      },
      "name" : "AI Training Data Metadata",
      "description" : "Documents the origin, relevant EHDS-related classifications, applicable permit identifiers, secondary-use purposes, and reported quality characteristics of data used to train or develop the AI system.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ArtifactAssessment"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ArtifactAssessment-dr-human-assessment.html"
      }],
      "reference" : {
        "reference" : "ArtifactAssessment/dr-human-assessment"
      },
      "name" : "ArtifactAssessment: Human Validation",
      "description" : "The human oversight assessment recording the clinician's review and validation of the AI-generated diagnostic report.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-human-oversight"],
      "groupingId" : "generalized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ArtifactAssessment"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ArtifactAssessment-sc-04-correction-exp-human-oversight-001.html"
      }],
      "reference" : {
        "reference" : "ArtifactAssessment/sc-04-correction-exp-human-oversight-001"
      },
      "name" : "Assessment: Human Correction of AI Output (4)",
      "description" : "Synthetic human oversight assessment documenting the clinician's review of the AI output.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-human-oversight"],
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ArtifactAssessment"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ArtifactAssessment-sc-03-override-human-oversight-001.html"
      }],
      "reference" : {
        "reference" : "ArtifactAssessment/sc-03-override-human-oversight-001"
      },
      "name" : "Assessment: Human Override of AI Output (3)",
      "description" : "Synthetic human oversight assessment documenting the clinician's review of the AI output.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-human-oversight"],
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ArtifactAssessment"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ArtifactAssessment-sc-02-validation-human-oversight-001.html"
      }],
      "reference" : {
        "reference" : "ArtifactAssessment/sc-02-validation-human-oversight-001"
      },
      "name" : "Assessment: Human Validation of AI Output (2)",
      "description" : "Synthetic human oversight assessment documenting the clinician's review of the AI output.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-human-oversight"],
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AuditEvent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "AuditEvent-sc-01-ai-only-audit-event-ai-execution-001.html"
      }],
      "reference" : {
        "reference" : "AuditEvent/sc-01-ai-only-audit-event-ai-execution-001"
      },
      "name" : "Audit Log: AI Execution Trace (1)",
      "description" : "Synthetic audit event documenting the AI execution for PoC traceability.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-machine-execution-audit-event"],
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AuditEvent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "AuditEvent-sc-02-validation-audit-event-ai-execution-001.html"
      }],
      "reference" : {
        "reference" : "AuditEvent/sc-02-validation-audit-event-ai-execution-001"
      },
      "name" : "Audit Log: AI Execution Trace (2)",
      "description" : "Synthetic audit event documenting the AI execution for PoC traceability.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-machine-execution-audit-event"],
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AuditEvent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "AuditEvent-sc-03-override-audit-event-ai-execution-001.html"
      }],
      "reference" : {
        "reference" : "AuditEvent/sc-03-override-audit-event-ai-execution-001"
      },
      "name" : "Audit Log: AI Execution Trace (3)",
      "description" : "Synthetic audit event documenting the AI execution for PoC traceability.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-machine-execution-audit-event"],
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AuditEvent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "AuditEvent-sc-04-correction-exp-audit-event-ai-execution-001.html"
      }],
      "reference" : {
        "reference" : "AuditEvent/sc-04-correction-exp-audit-event-ai-execution-001"
      },
      "name" : "Audit Log: AI Execution Trace (4)",
      "description" : "Synthetic audit event documenting the AI execution for PoC traceability.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-machine-execution-audit-event"],
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AuditEvent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "AuditEvent-dr-ai-audit-event.html"
      }],
      "reference" : {
        "reference" : "AuditEvent/dr-ai-audit-event"
      },
      "name" : "AuditEvent: AI Diagnostic Report Generation",
      "description" : "The audit trail entry recording the AI system's generation of the diagnostic report.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-machine-execution-audit-event"],
      "groupingId" : "generalized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-automated-decision-flag.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/automated-decision-flag"
      },
      "name" : "Automated Decision-Making Flag",
      "description" : "Indicates whether the documented AI-supported processing resulted in a decision made solely by automated means.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-case-specific-indication.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/case-specific-indication"
      },
      "name" : "Case-Specific Indication",
      "description" : "Records the clinical indication or case-specific reason for applying the AI system in the documented patient context.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Communication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Communication-dr-patient-communication.html"
      }],
      "reference" : {
        "reference" : "Communication/dr-patient-communication"
      },
      "name" : "Communication: Patient Explanation",
      "description" : "The communication informing the patient about the AI's involvement in generating the diagnostic report and its subsequent human review.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-patient-explanation"],
      "groupingId" : "generalized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Communication"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Communication-sc-04-correction-exp-patient-explanation-001.html"
      }],
      "reference" : {
        "reference" : "Communication/sc-04-correction-exp-patient-explanation-001"
      },
      "name" : "Communication: Patient-Facing AI Explanation (4)",
      "description" : "Synthetic patient-facing explanation about AI-supported processing and human review.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-patient-explanation"],
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-04-correction-exp-corrected-clinical-observation-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-04-correction-exp-corrected-clinical-observation-001"
      },
      "name" : "Corrected Clinical Observation: Early Warning Risk Assessment (4)",
      "description" : "Human-corrected clinical result preserving traceability to the original AI-generated output.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-data-category-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/data-category-cs"
      },
      "name" : "Data Category Code System",
      "description" : "Codes representing categories of electronic health data that may be made available for secondary use under the EHDS.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-data-category-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/data-category-vs"
      },
      "name" : "Data Category Value Set",
      "description" : "Categories of electronic health data that may be documented for secondary-use and AI-development contexts.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-data-permit.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/data-permit"
      },
      "name" : "Data Permit",
      "description" : "Records the identifier of an EHDS data permit associated with the documented secondary use, where applicable.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-dr-ai-device.html"
      }],
      "reference" : {
        "reference" : "Device/dr-ai-device"
      },
      "name" : "Device: DiagnosticAssist AI",
      "description" : "The AI system that generates the diagnostic report from the patient's clinical findings.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-device"],
      "groupingId" : "generalized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Device"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Device-device-riskassist-ai.html"
      }],
      "reference" : {
        "reference" : "Device/device-riskassist-ai"
      },
      "name" : "Device: RiskAssist AI",
      "description" : "Synthetic AI system for NEWS2-inspired early-warning risk assessment.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-device"],
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-encounter-001.html"
      }],
      "reference" : {
        "reference" : "Encounter/encounter-001"
      },
      "name" : "Encounter: Acute Care Assessment",
      "description" : "Synthetic encounter for suspected infection and early-warning risk assessment.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-eu-conformity-declaration-2.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/eu-conformity-declaration-2"
      },
      "name" : "EU Conformity Declaration",
      "description" : "The conformity declaration document for the AI device used in this diagnostic report scenario.",
      "isExample" : true,
      "groupingId" : "generalized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-eu-conformity-declaration.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/eu-conformity-declaration"
      },
      "name" : "EU Conformity Declaration",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-trust-ai-conformity-reference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/trust-ai-conformity-reference"
      },
      "name" : "EU Conformity Declaration Reference",
      "description" : "The EU declaration of conformity shall identify the high-risk AI system.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-gdpr-art6-codesystem.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/gdpr-art6-codesystem"
      },
      "name" : "GDPR Article 6 Legal Basis Code System",
      "description" : "Codes representing the legal bases listed in Article 6(1) GDPR for processing personal data.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-gdpr-art6-legal-basis-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/gdpr-art6-legal-basis-vs"
      },
      "name" : "GDPR Article 6 Legal Basis Value Set",
      "description" : "Legal bases listed in Article 6(1) GDPR for documenting the asserted lawful basis for processing personal data.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-gdpr-art9-codesystem.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/gdpr-art9-codesystem"
      },
      "name" : "GDPR Article 9 Condition Code System",
      "description" : "Codes representing selected conditions in Article 9(2) GDPR under which special categories of personal data may be processed.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-gdpr-art9-condition-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/gdpr-art9-condition-vs"
      },
      "name" : "GDPR Article 9 Condition Value Set",
      "description" : "Selected Article 9(2) GDPR conditions relevant to processing health data and other special categories of personal data in this implementation guide.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-01-ai-only-observation-blood-pressure-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-01-ai-only-observation-blood-pressure-001"
      },
      "name" : "Input Observation: Blood Pressure (1)",
      "description" : "Synthetic NEWS2-inspired input parameter.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-02-validation-observation-blood-pressure-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-02-validation-observation-blood-pressure-001"
      },
      "name" : "Input Observation: Blood Pressure (2)",
      "description" : "Synthetic NEWS2-inspired input parameter.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-03-override-observation-blood-pressure-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-03-override-observation-blood-pressure-001"
      },
      "name" : "Input Observation: Blood Pressure (3)",
      "description" : "Synthetic NEWS2-inspired input parameter.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-04-correction-exp-observation-blood-pressure-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-04-correction-exp-observation-blood-pressure-001"
      },
      "name" : "Input Observation: Blood Pressure (4)",
      "description" : "Synthetic NEWS2-inspired input parameter.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-01-ai-only-observation-temperature-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-01-ai-only-observation-temperature-001"
      },
      "name" : "Input Observation: Body Temperature (1)",
      "description" : "Synthetic NEWS2-inspired input parameter.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-02-validation-observation-temperature-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-02-validation-observation-temperature-001"
      },
      "name" : "Input Observation: Body Temperature (2)",
      "description" : "Synthetic NEWS2-inspired input parameter.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-03-override-observation-temperature-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-03-override-observation-temperature-001"
      },
      "name" : "Input Observation: Body Temperature (3)",
      "description" : "Synthetic NEWS2-inspired input parameter.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-04-correction-exp-observation-temperature-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-04-correction-exp-observation-temperature-001"
      },
      "name" : "Input Observation: Body Temperature (4)",
      "description" : "Synthetic NEWS2-inspired input parameter.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-dr-input-observation.html"
      }],
      "reference" : {
        "reference" : "Observation/dr-input-observation"
      },
      "name" : "Input Observation: C-Reactive Protein",
      "description" : "The clinical finding used as input to the AI system when generating the diagnostic report.",
      "isExample" : true,
      "groupingId" : "generalized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-01-ai-only-observation-consciousness-status-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-01-ai-only-observation-consciousness-status-001"
      },
      "name" : "Input Observation: Consciousness Status (1)",
      "description" : "Synthetic NEWS2-inspired input parameter.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-02-validation-observation-consciousness-status-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-02-validation-observation-consciousness-status-001"
      },
      "name" : "Input Observation: Consciousness Status (2)",
      "description" : "Synthetic NEWS2-inspired input parameter.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-03-override-observation-consciousness-status-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-03-override-observation-consciousness-status-001"
      },
      "name" : "Input Observation: Consciousness Status (3)",
      "description" : "Synthetic NEWS2-inspired input parameter.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-04-correction-exp-observation-consciousness-status-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-04-correction-exp-observation-consciousness-status-001"
      },
      "name" : "Input Observation: Consciousness Status (4)",
      "description" : "Synthetic NEWS2-inspired input parameter.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-01-ai-only-observation-heart-rate-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-01-ai-only-observation-heart-rate-001"
      },
      "name" : "Input Observation: Heart Rate (1)",
      "description" : "Synthetic NEWS2-inspired input parameter.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-02-validation-observation-heart-rate-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-02-validation-observation-heart-rate-001"
      },
      "name" : "Input Observation: Heart Rate (2)",
      "description" : "Synthetic NEWS2-inspired input parameter.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-03-override-observation-heart-rate-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-03-override-observation-heart-rate-001"
      },
      "name" : "Input Observation: Heart Rate (3)",
      "description" : "Synthetic NEWS2-inspired input parameter.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-04-correction-exp-observation-heart-rate-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-04-correction-exp-observation-heart-rate-001"
      },
      "name" : "Input Observation: Heart Rate (4)",
      "description" : "Synthetic NEWS2-inspired input parameter.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-01-ai-only-observation-oxygen-saturation-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-01-ai-only-observation-oxygen-saturation-001"
      },
      "name" : "Input Observation: Oxygen Saturation (1)",
      "description" : "Synthetic NEWS2-inspired input parameter.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-02-validation-observation-oxygen-saturation-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-02-validation-observation-oxygen-saturation-001"
      },
      "name" : "Input Observation: Oxygen Saturation (2)",
      "description" : "Synthetic NEWS2-inspired input parameter.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-03-override-observation-oxygen-saturation-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-03-override-observation-oxygen-saturation-001"
      },
      "name" : "Input Observation: Oxygen Saturation (3)",
      "description" : "Synthetic NEWS2-inspired input parameter.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-04-correction-exp-observation-oxygen-saturation-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-04-correction-exp-observation-oxygen-saturation-001"
      },
      "name" : "Input Observation: Oxygen Saturation (4)",
      "description" : "Synthetic NEWS2-inspired input parameter.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-01-ai-only-observation-respiratory-rate-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-01-ai-only-observation-respiratory-rate-001"
      },
      "name" : "Input Observation: Respiratory Rate (1)",
      "description" : "Synthetic NEWS2-inspired input parameter.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-02-validation-observation-respiratory-rate-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-02-validation-observation-respiratory-rate-001"
      },
      "name" : "Input Observation: Respiratory Rate (2)",
      "description" : "Synthetic NEWS2-inspired input parameter.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-03-override-observation-respiratory-rate-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-03-override-observation-respiratory-rate-001"
      },
      "name" : "Input Observation: Respiratory Rate (3)",
      "description" : "Synthetic NEWS2-inspired input parameter.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-sc-04-correction-exp-observation-respiratory-rate-001.html"
      }],
      "reference" : {
        "reference" : "Observation/sc-04-correction-exp-observation-respiratory-rate-001"
      },
      "name" : "Input Observation: Respiratory Rate (4)",
      "description" : "Synthetic NEWS2-inspired input parameter.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-organization-examplemed.html"
      }],
      "reference" : {
        "reference" : "Organization/organization-examplemed"
      },
      "name" : "Manufacturer Organization: ExampleMed AI GmbH",
      "description" : "The fictional manufacturer/provider of the RiskAssist AI system.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-organization"],
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ext-model-card.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ext-model-card"
      },
      "name" : "Model Card Reference",
      "description" : "References the model card that documents the AI system's intended purpose, limitations, performance, risks, and other relevant technical information.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-dr-model-card.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/dr-model-card"
      },
      "name" : "Model Card: DiagnosticAssist AI",
      "description" : "The model card describing the AI system's performance, training data, and privacy characteristics.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-model-card"],
      "groupingId" : "generalized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-modelcard-riskassist-ai.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/modelcard-riskassist-ai"
      },
      "name" : "Model Card: RiskAssist AI v1.0.0",
      "description" : "Synthetic model card for the deterministic AI-output simulation component used in the PoC.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-model-card"],
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-organization-examplehospital.html"
      }],
      "reference" : {
        "reference" : "Organization/organization-examplehospital"
      },
      "name" : "Operator Organization: Example Hospital",
      "description" : "The fictional healthcare organization operating the AI system.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-organization"],
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-dr-organization.html"
      }],
      "reference" : {
        "reference" : "Organization/dr-organization"
      },
      "name" : "Organization: Example Diagnostic Center",
      "description" : "The diagnostic center that owns and operates the AI system used to generate the diagnostic report.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-organization"],
      "groupingId" : "generalized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-patient-ai-info-provided-flag.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/patient-ai-info-provided-flag"
      },
      "name" : "Patient AI Info Provided Flag",
      "description" : "This flag represents whether the patient has been informed about the AI-related processing activity",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-dr-patient.html"
      }],
      "reference" : {
        "reference" : "Patient/dr-patient"
      },
      "name" : "Patient: Diagnostic Report Scenario",
      "description" : "The patient who is the subject of the AI-generated diagnostic report.",
      "isExample" : true,
      "groupingId" : "generalized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-patient-001.html"
      }],
      "reference" : {
        "reference" : "Patient/patient-001"
      },
      "name" : "Patient: Synthetic Patient 001",
      "description" : "A fictional female patient used in the NEWS2-inspired PoC scenarios.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-dr-practitioner.html"
      }],
      "reference" : {
        "reference" : "Practitioner/dr-practitioner"
      },
      "name" : "Practitioner: Diagnostic Reviewer",
      "description" : "The clinician who performs human oversight and validates the AI-generated diagnostic report.",
      "isExample" : true,
      "groupingId" : "generalized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-practitioner-001.html"
      }],
      "reference" : {
        "reference" : "Practitioner/practitioner-001"
      },
      "name" : "Practitioner: Human Reviewer",
      "description" : "The fictional clinician responsible for reviewing the AI-generated output.",
      "isExample" : true,
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-dr-practitioner-role.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/dr-practitioner-role"
      },
      "name" : "PractitionerRole: Diagnostic Reviewer",
      "description" : "The role held by the practitioner when reviewing AI-generated diagnostic reports at the organization.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-practitionerrole"],
      "groupingId" : "generalized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-practitionerrole-reviewer-001.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/practitionerrole-reviewer-001"
      },
      "name" : "PractitionerRole: Human Reviewer",
      "description" : "Synthetic practitioner role representing a trained internal medicine reviewer.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-practitionerrole"],
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Provenance"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Provenance-dr-ai-provenance.html"
      }],
      "reference" : {
        "reference" : "Provenance/dr-ai-provenance"
      },
      "name" : "Provenance: AI Diagnostic Report",
      "description" : "The provenance record describing how and under what legal basis the AI-generated diagnostic report was produced.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-provenance"],
      "groupingId" : "generalized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Provenance"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Provenance-sc-01-ai-only-provenance-ai-output-001.html"
      }],
      "reference" : {
        "reference" : "Provenance/sc-01-ai-only-provenance-ai-output-001"
      },
      "name" : "Provenance: AI Output Generation (1)",
      "description" : "Synthetic provenance resource linking the AI output to the AI system, input data, and legal processing context.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-provenance"],
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Provenance"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Provenance-sc-02-validation-provenance-ai-output-001.html"
      }],
      "reference" : {
        "reference" : "Provenance/sc-02-validation-provenance-ai-output-001"
      },
      "name" : "Provenance: AI Output Generation (2)",
      "description" : "Synthetic provenance resource linking the AI output to the AI system, input data, and legal processing context.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-provenance"],
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Provenance"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Provenance-sc-03-override-provenance-ai-output-001.html"
      }],
      "reference" : {
        "reference" : "Provenance/sc-03-override-provenance-ai-output-001"
      },
      "name" : "Provenance: AI Output Generation (3)",
      "description" : "Synthetic provenance resource linking the AI output to the AI system, input data, and legal processing context.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-provenance"],
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Provenance"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Provenance-sc-04-correction-exp-provenance-ai-output-001.html"
      }],
      "reference" : {
        "reference" : "Provenance/sc-04-correction-exp-provenance-ai-output-001"
      },
      "name" : "Provenance: AI Output Generation (4)",
      "description" : "Synthetic provenance resource linking the AI output to the AI system, input data, and legal processing context.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-provenance"],
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Provenance"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Provenance-example-secondary-use-provenance.html"
      }],
      "reference" : {
        "reference" : "Provenance/example-secondary-use-provenance"
      },
      "name" : "Provenance: Secondary Use Example",
      "description" : "Example showing EHDS secondary use purpose and data permit.",
      "isExample" : true,
      "profile" : ["http://example.org/fhir/trust-ai-transparency/StructureDefinition/trust-ai-provenance"],
      "groupingId" : "spezialized"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-secondary-use-purpose.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/secondary-use-purpose"
      },
      "name" : "Secondary Use Purpose",
      "description" : "Records the documented purpose for secondary use of electronic health data in the EHDS context.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-secondary-use-purpose-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/secondary-use-purpose-cs"
      },
      "name" : "Secondary-Use Purpose Code System",
      "description" : "Codes representing permitted categories of purpose for the secondary use of electronic health data under the EHDS.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-secondary-use-purpose-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/secondary-use-purpose-vs"
      },
      "name" : "Secondary-Use Purpose Value Set",
      "description" : "Purpose categories used to document the secondary use of electronic health data under the EHDS.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-third-country-data-transfer.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/third-country-data-transfer"
      },
      "name" : "Third-Country Data Transfer",
      "description" : "Documents whether use of the AI system involves a transfer of personal data to a third country or an international organisation and identifies the destination country or countries where applicable.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-trust-ai-artifact-type-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/trust-ai-artifact-type-cs"
      },
      "name" : "Trust AI Artifact Type Code System",
      "description" : "Codes identifying AI-related documentation artifacts represented by this implementation guide.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-trust-ai-audit-entity-role.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/trust-ai-audit-entity-role"
      },
      "name" : "Trust AI Audit Entity Role Code System",
      "description" : "Roles used to distinguish entities involved in an AI execution audit event.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-trust-ai-audit-entity-role-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/trust-ai-audit-entity-role-vs"
      },
      "name" : "Trust AI Audit Entity Role Value Set",
      "description" : "Roles of entities involved in an AI execution audit event.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-trust-ai-case-specific-indication-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/trust-ai-case-specific-indication-cs"
      },
      "name" : "Trust AI Case-Specific Indication Code System",
      "description" : "Codes describing the clinical purpose for which an AI system was applied in an individual case.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-trust-ai-case-specific-indication-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/trust-ai-case-specific-indication-vs"
      },
      "name" : "Trust AI Case-Specific Indication Value Set",
      "description" : "Clinical purposes for applying an AI system in an individual care context.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-trust-ai-clinical-validation-status-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/trust-ai-clinical-validation-status-cs"
      },
      "name" : "Trust AI Clinical Validation Status Code System",
      "description" : "Codes indicating the documented clinical validation status of an AI system for its intended clinical use.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-trust-ai-clinical-validation-status-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/trust-ai-clinical-validation-status-vs"
      },
      "name" : "Trust AI Clinical Validation Status Value Set",
      "description" : "Clinical validation statuses applicable to an AI system and its documented intended use.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-trust-ai-contact-purpose-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/trust-ai-contact-purpose-cs"
      },
      "name" : "Trust AI Contact Purpose Code System",
      "description" : "Codes identifying organizational contact responsibilities relevant to data protection and AI-system governance.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-trust-ai-data.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/trust-ai-data"
      },
      "name" : "Trust AI Data",
      "description" : "A resource-independent profile indicating that an AI system was\ninvolved in generating, reporting, assisting with, or asserting\nthe content of a FHIR resource.\n\nThis profile is intended as a common validation and documentation\npattern across different FHIR resource types.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-trust-ai-data-quality-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/trust-ai-data-quality-cs"
      },
      "name" : "Trust AI Data Quality Code System",
      "description" : "Codes describing assessed data-quality characteristics relevant to the development, validation, testing, or evaluation of an AI system.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-trust-ai-data-quality-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/trust-ai-data-quality-vs"
      },
      "name" : "Trust AI Data Quality Value Set",
      "description" : "Assessed data-quality characteristics relevant to AI-system development, validation, testing, or evaluation.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-trust-ai-dpia-reference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/trust-ai-dpia-reference"
      },
      "name" : "Trust AI DPIA Reference",
      "description" : "Privacy risk management, GDPR accountability",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-trust-ai-machine-execution-audit-event.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/trust-ai-machine-execution-audit-event"
      },
      "name" : "Trust AI Execution Audit Event",
      "description" : "An AuditEvent profile documenting execution-related metadata of an AI-supported processing event to support retrospective reconstruction and auditability.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-trust-ai-observation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/trust-ai-observation"
      },
      "name" : "Trust AI Generated Observation",
      "description" : "An Observation profile representing a clinical output generated by an AI system, including AI-related transparency metadata and links to the relevant patient, encounter, and AI system.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-trust-ai-human-oversight-action-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/trust-ai-human-oversight-action-vs"
      },
      "name" : "Trust AI Human Oversight Action Value Set",
      "description" : "Human oversight actions that may be documented in relation to an AI-generated output or recommendation.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-trust-ai-human-oversight.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/trust-ai-human-oversight"
      },
      "name" : "Trust AI Human Oversight Assessment",
      "description" : "An ArtifactAssessment profile documenting professional review of an AI-generated output, including whether the result was accepted, corrected, modified, or overridden.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-trust-ai-human-oversight-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/trust-ai-human-oversight-cs"
      },
      "name" : "Trust AI Human Oversight Code System",
      "description" : "Codes describing actions taken by a human reviewer in response to an AI-generated output or recommendation.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-trust-ai-identifier-type-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/trust-ai-identifier-type-cs"
      },
      "name" : "Trust AI Identifier Type Code System",
      "description" : "Codes identifying regulatory identifier types associated with an AI system.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-trust-ai-involvement-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/trust-ai-involvement-cs"
      },
      "name" : "Trust AI Involvement Code System",
      "description" : "Codes indicating the manner in which an AI system contributed to the content represented by a FHIR resource.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-trust-ai-involvement-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/trust-ai-involvement-vs"
      },
      "name" : "Trust AI Involvement Value Set",
      "description" : "Codes used to classify how an AI system contributed to the content of a FHIR resource.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-trust-ai-log-integrity.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/trust-ai-log-integrity"
      },
      "name" : "Trust AI Log Integrity Signature",
      "description" : "Provides a digital signature and associated metadata to support verification of the integrity and origin of the AI execution audit record.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-trust-ai-model-card.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/trust-ai-model-card"
      },
      "name" : "Trust AI Model Card",
      "description" : "A DocumentReference profile representing technical documentation about an AI system, such as intended use, limitations, risk-related information, performance-related information, and model documentation.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-trust-ai-patient-explanation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/trust-ai-patient-explanation"
      },
      "name" : "Trust AI Patient Explanation Communication",
      "description" : "A Communication profile documenting that an explanation regarding an AI-supported clinical decision was provided to a patient. The explanation may describe the role of the AI system, the related human oversight, and the key elements of the resulting clinical decision in accordance with Article 86 of the EU AI Act.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-trust-ai-performance-metric-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/trust-ai-performance-metric-cs"
      },
      "name" : "Trust AI Performance Metric Code System",
      "description" : "Codes identifying performance characteristics used to document the evaluation of an AI system.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-trust-ai-performance-metric-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/trust-ai-performance-metric-vs"
      },
      "name" : "Trust AI Performance Metric Value Set",
      "description" : "Performance characteristics that may be documented for an AI system.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-trust-ai-practitionerrole.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/trust-ai-practitionerrole"
      },
      "name" : "Trust AI Practitioner Role",
      "description" : "A PractitionerRole profile representing the role, qualification context, specialty, and AI-related training information of the human reviewer involved in oversight of an AI-supported workflow.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-trust-ai-provenance.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/trust-ai-provenance"
      },
      "name" : "Trust AI Provenance",
      "description" : "A Provenance profile linking an AI-generated output to the contributing AI system, source data, and relevant processing or governance context.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-trust-ai-organization.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/trust-ai-organization"
      },
      "name" : "Trust AI Responsible Organization",
      "description" : "An Organization profile representing an organization involved in manufacturing, providing, deploying, or operating an AI system, including relevant accountability and contact information.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-trust-ai-device.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/trust-ai-device"
      },
      "name" : "Trust AI System Device",
      "description" : "A Device profile representing an AI system or software component, including system identification, versioning, intended purpose, and selected regulatory documentation metadata.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-trust-ai-system-property-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/trust-ai-system-property-cs"
      },
      "name" : "Trust AI System Property Code System",
      "description" : "Codes identifying structured properties used to describe regulatory and operational characteristics of an AI system in Device.property.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-usage-category.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/usage-category"
      },
      "name" : "Usage Category",
      "description" : "Classifies the documented use of electronic health data as primary use or secondary use in the EHDS context.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-usage-category-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/usage-category-cs"
      },
      "name" : "Usage Category Code System",
      "description" : "Codes distinguishing primary use from secondary use of electronic health data in the context of the European Health Data Space.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-usage-category-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/usage-category-vs"
      },
      "name" : "Usage Category Value Set",
      "description" : "Categories distinguishing primary and secondary use of electronic health data in the EHDS context.",
      "isExample" : false
    }],
    "page" : {
      "sourceUrl" : "toc.html",
      "name" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "sourceUrl" : "index.html",
        "name" : "index.html",
        "title" : "Home",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "introduction.html",
        "name" : "introduction.html",
        "title" : "Introduction",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "use_case_overview.html",
        "name" : "use_case_overview.html",
        "title" : "Use Cases & Examples",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "use_case1.html",
        "name" : "use_case1.html",
        "title" : "Use Case 1 - AI-supported Risk evaluation",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "use_case2.html",
        "name" : "use_case2.html",
        "title" : "Use Case 2 - AI-generated Diagnostic Report",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "requirements.html",
        "name" : "requirements.html",
        "title" : "Requirements Traceability",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "profiles.html",
        "name" : "profiles.html",
        "title" : "Profiles",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "extensions.html",
        "name" : "extensions.html",
        "title" : "Extensions",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "terminology.html",
        "name" : "terminology.html",
        "title" : "Terminology",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "authors.html",
        "name" : "authors.html",
        "title" : "Authors and Contributors",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "dependencies.html",
        "name" : "dependencies.html",
        "title" : "Dependencies",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "ip-statements.html",
        "name" : "ip-statements.html",
        "title" : "Intellectual Property",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "copyrightyear"
      },
      "value" : "2026+"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "releaselabel"
      },
      "value" : "ci-build"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "autoload-resources"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/capabilities"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/examples"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/extensions"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/models"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/operations"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/profiles"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/resources"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/vocabulary"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/maps"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/testing"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/history"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "fsh-generated/resources"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-pages"
      },
      "value" : "template/config"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-pages"
      },
      "value" : "input/images"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-liquid"
      },
      "value" : "template/liquid"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-liquid"
      },
      "value" : "input/liquid"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-qa"
      },
      "value" : "temp/qa"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-temp"
      },
      "value" : "temp/pages"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-output"
      },
      "value" : "output"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-tx-cache"
      },
      "value" : "input-cache/txcache"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-suppressed-warnings"
      },
      "value" : "input/ignoreWarnings.txt"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-history"
      },
      "value" : "http://example.org/fhir/trust-ai-transparency/history.html"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "template-html"
      },
      "value" : "template-page.html"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "template-md"
      },
      "value" : "template-page-md.html"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-contact"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-context"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-copyright"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-jurisdiction"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-license"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-publisher"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-version"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-wg"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "active-tables"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "fmm-definition"
      },
      "value" : "http://hl7.org/fhir/versions.html#maturity"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "propagate-status"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "excludelogbinaryformat"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "tabbed-snapshots"
      },
      "value" : "true"
    }]
  }
}

```
