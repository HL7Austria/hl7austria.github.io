# GDPR Article 6 Legal Basis Code System - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **GDPR Article 6 Legal Basis Code System**

## CodeSystem: GDPR Article 6 Legal Basis Code System 

| | |
| :--- | :--- |
| *Official URL*:http://example.org/fhir/eu-ai-transparency/CodeSystem/gdpr-art6-codesystem | *Version*:0.1.0 |
| Active as of 2026-09-07 | *Computable Name*:GDPRArt6CodeSystem |

 
Codes representing the legal bases listed in Article 6(1) GDPR for processing personal data. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [GDPR Article 6 Legal Basis Value Set](ValueSet-gdpr-art6-legal-basis-vs.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "gdpr-art6-codesystem",
  "url" : "http://example.org/fhir/eu-ai-transparency/CodeSystem/gdpr-art6-codesystem",
  "version" : "0.1.0",
  "name" : "GDPRArt6CodeSystem",
  "title" : "GDPR Article 6 Legal Basis Code System",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-09-07T08:26:58+00:00",
  "publisher" : "Selina Adlberger",
  "description" : "Codes representing the legal bases listed in Article 6(1) GDPR for processing personal data.",
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 6,
  "concept" : [{
    "code" : "gdpr-art-6-1-a",
    "display" : "Consent (Art. 6(1)(a))",
    "definition" : "The data subject has given consent to the processing of personal data for one or more specific purposes."
  },
  {
    "code" : "gdpr-art-6-1-b",
    "display" : "Contract (Art. 6(1)(b))",
    "definition" : "Processing is necessary for the performance of a contract with the data subject or for pre-contractual measures requested by the data subject."
  },
  {
    "code" : "gdpr-art-6-1-c",
    "display" : "Legal Obligation (Art. 6(1)(c))",
    "definition" : "Processing is necessary for compliance with a legal obligation to which the controller is subject."
  },
  {
    "code" : "gdpr-art-6-1-d",
    "display" : "Vital Interests (Art. 6(1)(d))",
    "definition" : "Processing is necessary to protect the vital interests of the data subject or another natural person."
  },
  {
    "code" : "gdpr-art-6-1-e",
    "display" : "Public Interest or Official Authority (Art. 6(1)(e))",
    "definition" : "Processing is necessary for a task carried out in the public interest or in the exercise of official authority vested in the controller."
  },
  {
    "code" : "gdpr-art-6-1-f",
    "display" : "Legitimate Interests (Art. 6(1)(f))",
    "definition" : "Processing is necessary for legitimate interests pursued by the controller or a third party, subject to the conditions and limitations of Article 6(1)(f) GDPR."
  }]
}

```
