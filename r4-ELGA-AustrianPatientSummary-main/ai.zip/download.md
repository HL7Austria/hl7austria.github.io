# Download - Austrian Patient Summary (R4) v1.1.0

* [**Table of Contents**](toc.md)
* **Download**

## Download

### Full IG

Download the entire implementation guide [here](full-ig.zip).

### NPM Package and Definitions

The following file contains all the value sets, profiles, extensions, list of pages and urls in the IG, etc. defined as part of this Implementation Guide:

* [NPM Package](package.tgz)

In addition there are format specific definition files:

* [XML](definitions.xml.zip)
* [JSON](definitions.json.zip)
* [TTL](definitions.ttl.zip)

These files should be the first choice whenever generating any implementation artifacts since they contain all of the rules about what makes these profiles valid. Implementers will still need to be familiar with the content of the specification and profiles that apply in order to make a conformant implementation. See the overview on [validating FHIR profiles and resources](http://hl7.org/fhir/R4/validation.html).

### Examples

All of the examples that are used in this Implementation Guide are available for download:

* [XML](examples.xml.zip)
* [JSON](examples.json.zip)

