# ELGA.MOPED\Valueset für die Art der Geburtenanzahl - FHIR® v5.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Valueset für die Art der Geburtenanzahl**

## ValueSet: Valueset für die Art der Geburtenanzahl 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://elga.moped.at/ValueSet/GeburtenanzahlVS | *Version*:0.1.0 | |
| Draft as of 2026-06-09 | *Responsible:*[ELGA GmbH](https://elga.gv.at) | *Computable Name*:GeburtenanzahlVS |

 
Valueset für die Art der Geburtenanzahl in MOPED 

 **References** 

* [AT MOPED Observation Geburtenanzahl Basis Profil](StructureDefinition-at-moped-observation-geburtenanzahl-basis.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R5/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "GeburtenanzahlVS",
  "url" : "https://elga.moped.at/ValueSet/GeburtenanzahlVS",
  "version" : "0.1.0",
  "name" : "GeburtenanzahlVS",
  "title" : "Valueset für die Art der Geburtenanzahl",
  "status" : "draft",
  "date" : "2026-06-09T11:53:00+00:00",
  "publisher" : "ELGA GmbH",
  "contact" : [{
    "name" : "ELGA GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://elga.gv.at"
    }]
  }],
  "description" : "Valueset für die Art der Geburtenanzahl in MOPED",
  "compose" : {
    "include" : [{
      "system" : "http://loinc.org",
      "concept" : [{
        "code" : "11636-8",
        "display" : "[#] Births.live"
      },
      {
        "code" : "57062-2",
        "display" : "[#] Births.stillborn"
      }]
    }]
  }
}

```
